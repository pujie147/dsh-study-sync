# 第 6 章 复制写与懒分配：cow lab

## 来源清单
1. Lab: copy-on-write (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.1810/2025/labs/cow.html — 官方 cow lab 页任务判据段（cowtest + usertests -q）— 访问 2026-10-23（经 research 通道取到官方段落）
2. Lab: copy-on-write (6.1810 Fall 2026) — https://pdos.csail.mit.edu/6.1810/2026/labs/cow.html — 官方最新 cow 页同题正文（「cowtest runs variou…」句头）— 访问 2026-10-23（同上）
3. Lab cow: Copy-on-Write Fork（Aniya 博客解题笔记）— https://www.irenewhite.ren/archives/lab-cow-copy-on-write-fork — 中文社区解题实录，复述官方任务全文与实现要点 — 访问 2026-10-23（检索摘要级）
4. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方时序：cow lab 随 LEC 9「Transparent super pages」发放（10/1），LEC 10「Virtual memory for applications」(附 mmap.c 例程) 与 hw xv6-pgfault 围绕页故障展开 — 访问 2026-10-23
5. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 概念挂载：Ch.21 Swapping mechanisms、Ch.23 Complete VM Systems（CoW 专节）— 访问 2026-10-23

## 摘录与要点
- （来源 1/2）官方判据原文：「**Implement copy-on-write fork** — Your task is to implement copy-on-write fork in the xv6 kernel. You are done if your modified kernel executes both the **cowtest** and **'usertests -q'** programs successfully. To help you test your implementation, we've provided an xv6 program called cowtest (source in user/cowtest.c).」——验收=专卷 cowtest + 全量回归，无中间问答（answers 已不在本版）。
- （来源 1/2 段落级）cowtest 官方说明句头「cowtest runs variou[s tests]…」——测试覆盖多种 CoW 情形；讲义实现前先读本地 user/cowtest.c 源码反推判据（草案「并发拷打是试金石」由此而来，逐用例解释在讲义落实）。
- （来源 3）中文解题笔记复述官方任务全文一致（cowtest + usertests），其实现叙述（页引用计数 + fork 时标只读 + 缺页复制）与 xv6 主线做法同型——可作学习者第二参考；引用其结论前先与官方页与主线代码交叉核对。
- （来源 4）官方时序把 CoW 放在页故障理论正后：hw xv6-pgfault（「内核处理用户页故障的机制设计」问答）与 LEC 10 应用级 VM（l-uservm.txt + mmap.c）构成 cow→mmap 连续铺垫——印证本章「复用第 4 章 fault 骨架 + 预告第 10 章」的定位。
- （来源 5）概念挂载：CoW 正是 OSTEP Ch.23「Complete VM Systems」中 Swapper/CoW/mmap 三部曲之第二件——书中 `PageCopy`/PTE 置保护位的伪代码与 xv6 实现可逐行对照；「fork 拷页表不拷物理页、写故障复制单页」的账目 $T_{fork}=O(\text{页表})\ \text{vs}\ O(\text{内存})$ 用 LaTeX 呈现。
- （要点·工程前提，来源 1/2 佐证 + 主线代码待读）lab 分支上主线 CoW 实现被剥掉、需重建——**此说法来自草案 gap_notes，本次资料页仅证实任务本身**；讲义「与主线参考 diff 对照」环节落地时以本地 `git diff riscv..cow`（或 upstream 分支对比）实证，不引二手。
- （要点·RISC-V 特有）主线用 PTE 保留位打「COW_PTE」式私有标记、RISC-V 无 dirty 位靠写权限位触发——此机制描述需在本地读 kernel/vm.c 后写入讲义（本次源码页抓取失败，标未核验，见缺口）。

## 本章仍缺的缺口
- cow 官方页**整页**未抓到：hints 小节（如「给物理页加引用计数」「fork 时注意已写过的页」等具体提示）与 lazy 分配相关段落未取，落地前补抓 https://pdos.csail.mit.edu/6.1810/2025/labs/cow.html。
- COW_PTE 软件位占哪一 bit、主线 copy_range/ref_count 结构的确切代码——kernel/vm.c 源码页本次未抓取（raw 通道 403），讲义按本地 clone 读源码。
- 「剥码分支」的历史沿革（2021 起主线已含 CoW）无本次可引页面，作背景叙述时标注年份存疑待核。
