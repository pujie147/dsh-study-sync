# 第 10 章 横切合拢与收官交付：mmap lab + 实现报告

## 来源清单
1. Lab: mmap (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/mmap.html — 官方 mmap lab 全文：API 子集约定、懒缺页强制要求、VMA 建议、写回与 fork 语义、mmaptest 判据清单、五个选做挑战 — 访问 2026-10-23
2. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方时序：mmap lab 随 LEC 19「File system performance and fast crash recovery」发放（11/19，全课程最后一个 lab，12/5 截止）；LEC 20 RCU、LEC 21 Containers/Virtual Machines、LEC 23 Meltdown 构成收官延伸；期末范围=「Lectures 13–23, labs net through mmap」 — 访问 2026-10-23
3. Lab: system calls (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/syscall.html — 官方页内「Attack xv6」的懒分配残留漏洞叙事——mmap 懒缺页复用的正是这条 fault 通路 — 访问 2026-10-23
4. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 概念挂载：Ch.14 Memory API、Ch.23 Complete VM Systems（书中 mmap 专节：匿名映射/文件映射/shared-private 语义）、Ch.40 文件系统实现（buffer cache） — 访问 2026-10-23
5. Lab guidance (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/guidance.html — 收官报告的官方过程锚点：每 lab 的 time.txt/answers 习惯与验证节奏 — 访问 2026-10-23

## 摘录与要点
- （来源 1）官方语义边界（逐字）：mmap 参数约定——addr 恒 0（内核选址）、prot ∈ {PROT_READ, PROT_WRITE, 或皆}、flags ∈ {MAP_SHARED, MAP_PRIVATE}、offset 恒 0；返回地址或 `0xffffffffffffffff`；**「It's OK if processes that map the same MAP_SHARED file do not share physical pages」**（共享物理页是选做挑战，主线不必）。
- （来源 1）官方强制的懒实现：「Your implementation should fill in the page table **lazily**, in response to page faults. That is, do that in page fault handling code in (or called by) **usertrap**, **as in the copy-on-write lab**. The reason…mmap of a large file is fast, and mmap of a file **larger than physical memory** is possible.」——mmap/CoW 同一骨架的官方原话，本章横切定位（第 4/6 章 fault 通路复用）由此实证。
- （来源 1）官方实现路线图（hints 全链）：①先接 syscall 号让 mmaptest 编译起来、返回错误；②**VMA 表**——仿「virtual memory for applications」讲义自建结构（addr/length/prot/file…），「xv6 内核没有可变大小分配器，**声明定长数组 16 项足够**」；③mmap：找用户地址空间空闲段 + VMA 登记 + 存 struct file 指针并**引用计数+1（hint 指名 filedup）**；④缺页：分配物理页、**用 readi（带 offset 参数）读入对应 4096 字节**（注意 inode 加解锁），按 prot 设权限；⑤munmap：找 VMA、`uvmunmap`；**MAP_SHARED 且有脏页先写回文件（hint 指名 filewrite）**，unmap 干净 VMA 才给 file 引用计数-1；D 脏位可偷懒（mmaptest 不检查非脏页不写回）；⑥exit=按 munmap 清全部映射；⑦**fork：拷 VMA、file 引用+1；子进程缺页允许另配新页（共享更酷但要多干活）**。
- （来源 1）判据（官方样例输出）：`mmaptest` 十项全 OK——basic/private/read-only/read-write/dirty/not-mapped unmap/**lazy access**/two files/**fork**/munmap-prevents-access（预期 `scause 0xd`）/writes-to-readonly（预期 `scause 0xf`）+ `usertests -q` ALL TESTS PASSED。
- （来源 1）五个选做挑战（官方逐字）：共享物理页（需物理页引用计数）；**消灭 mmap 与 buffer cache 双缓存**——复用缓存页需把 BSIZE 改 4096、把块 pin 进缓存、管引用计数，官方点明**副作用是让 read/write 与 mmap 语义一致**；缺页懒分配与 mmap 填充去冗余（给 lazy 区也建 VMA）；exec 用 VMA 做按需换页可执行文件；page-out/page-in 换页到磁盘。双缓存题=本章「工程权衡与选边」题眼。
- （来源 2）官方收官视野：mmap lab 发放于 ext3 快速恢复专讲周；期末考范围恰为 net→mmap——「实现报告」按此把九个 lab 收拢为一条「机制/策略 × 三大件」主线（挂图素材即草案总框架）。
- （来源 4/5）概念挂载与交付形态：OSTEP Ch.23 书中 mmap 讨论（匿名/文件映射、shared/private、`mmap.c` 例程）是本章理论母本，Ch.14 给 API 视角；报告无官方模板，自学以 **make grade 输出 + time.txt + answers-\* 为证据链**，骨架=问题定位→机制总图（mermaid）→每 lab 设计决策/bug 修复记录→与主线 diff 对照→遗留清单（草案设定，资料页确认官方仅有 grade/zipball 验收流程可借用）。

## 本章仍缺的缺口
- 社区 mmap 参考实现分歧大、无权威 VMA 骨架官方样例——讲义按 hints 链自拟数据结构与测试矩阵（草案预设，检索未见可靠「标准答案」页，符合红线要求的不引二手原则）。
- unified buffer cache 论文 PDF（官方页所链 USENIX 2000 文献）本次未抓取，仅作选做延伸阅读标注。
- l-uservm.txt（VMA 概念出处的官方讲义 txt）正文未抓取（403 时段），讲义引用前补抓 https://pdos.csail.mit.edu/6.828/2025/lec/l-uservm.txt。
