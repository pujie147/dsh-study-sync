# 第 4 章 异常与陷阱：traps lab（用户级 fault handler）

## 来源清单
1. Lab: traps (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/traps.html — 官方当年 traps lab 页（stack 热身 + Alarm + 用户级故障处理）— 访问 2026-10-23（经 research 通道取到官方段落；整页直抓在 403 窗口内未成）
2. Lab: traps (6.1810 Fall 2026) — https://pdos.csail.mit.edu/6.1810/2026/labs/traps.html — 官方最新 traps lab 全文（同一任务族，细节最完整：backtrace、alarm、sigreturn 协作）— 访问 2026-10-23（经 research 通道取到正文段落）
3. Lab: system calls (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/syscall.html — 官方页给出的 RISC-V 案发现场三件套实证与特权手册链接 — 访问 2026-10-23
4. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方时序：traps lab 随 LEC 7「System call interposition」发放；LEC 8「Page faults」(hw xv6-pgfault) 紧接其后 — 访问 2026-10-23
5. 6.1810 Lab - Traps（Glucoco 中文笔记）— https://glucoco.com/2025-06-18/61810-lab-traps/ — 中文解题叙述（时钟中断→内核判定→切用户态跑 handler→恢复中断前上下文）— 访问 2026-10-23（检索摘要级）

## 摘录与要点
- （来源 1/2）官方定位原句：「This lab explores how system calls are implemented using traps. You will first do a warm-up exercise with stacks and then you will implement an example of **user-level trap handling**.」任务族：栈热身 + Alarm + 用户级陷阱处理——与草案定位一致。
- （来源 1）Alarm 问官方动机（正文）：给吃 CPU 的进程周期性自我提醒；「更一般地，你在实现一种原始形式的**用户级中断/故障处理器**——同样的做法可在应用内处理 page fault」——这句是本章作为 CoW/mmap 地基的官方背书。
- （来源 2）Alarm 实现路径官方要点（2026 页正文，机制与 2025 同）：改 `usertrap()`，进程 alarm 间隔到期时让**用户进程执行注册的 handler**；关键问答「RISC-V trap 返回用户态时由什么决定续跑地址」（sepc）；失败特征：alarmtest 打印 alarm! 后崩在 test0/test1——修复三条件：**handler 结束后回到被定时器打断的那条指令**、**恢复中断时刻的寄存器现场**、**每次触发后重新装载计数（re-arm）**；官方替学习者定的设计决定：**用户 handler 必须以 `sigreturn` 系统调用收尾**（alarmtest.c 的 periodic 示例），usertrap 与 sys_sigreturn 两处协作即可。——完整给出「改写 trapframe 控制用户去向」的全部约束。
- （来源 2）栈热身官方要点：backtrace——「寄存器 **s0 指向当前栈帧**（保存的返回地址位置 +8），沿 frame pointer 逐帧上溯打印各帧保存的返回地址」。2025 版另有寄存器传参观察题（用户函数参数 a0–a7 的取用）——讲义按 2025 页逐条核对措辞。
- （来源 3）案发现场三件套官方实证：空指针非法读触发内核态 page fault 时 xv6 打印 `scause=0xd sepc=<PC> stval=<地址>`；mmap 判据输出亦打印 `unexpected scause 0xd` 与 `scause 0xf`（store fault）——**13=load fault、15=store fault 已被两处官方输出直接印证**；12=instruction fault 与 8=定时器中断的规范出处为 RISC-V 特权手册 Priv-v1.12（syscall 页给出的官方链接），本会话未抓取正文——讲义速查表这两格标「引手册待核」。
- （来源 4）官方时序佐证教学顺序：trap 机制（LEC 6 entry/exit、LEC 7 interposition）先行，**页故障原理（LEC 8 + hw xv6-pgfault）紧随 traps lab**——第 4 章结尾预告 CoW 正合官方节奏。
- （来源 5）中文笔记与官方判据一致（handler 在用户态执行、内核负责切换与恢复现场），可作第二参考。

## 本章仍缺的缺口
- 2025 版 traps 页**整页**未抓到：是否另含 invalid-load 独立小问（早期版本有「用户进程非法 load 打印后 kill」变体）未能逐条核实——讲义以当年页为准（草案 gap_notes 预设的版本漂移风险成立）。
- scause=8（S 定时器中断）的规范页原文、stvec/sscratch 装配细节：特权手册与 kernel/trap.c/trapasm.S 源码页本次未抓取，讲义按本地 clone 补。
- sigreturn 的 POSIX 语义对照（真信号 vs lab 简化）无官方叙述，讲义给一段边界说明即可。
