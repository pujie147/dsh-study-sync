# 第 7 章 锁、调度与睡眠唤醒：lock lab

## 来源清单
1. Lab: locks (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/lock.html — 官方 lock lab 页正文（争用度量与 per-CPU freelists 任务）— 访问 2026-10-23（经 research 通道取到正文段落）
2. xv6 book「Locking」章 LaTeX 源码 — https://github.com/mit-pdos/xv6-riscv-book/blob/xv6-riscv/lock.tex — 官方教材锁章全文可在线读（比 PDF 友好）：spinlock/sleeplock 定义与实现叙述 — 访问 2026-10-23（经 research 通道检索到章内原句）
3. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方时序：lock lab 随 LEC 15「Networking」发放（11/3），但锁的理论主场在 LEC 12「Locking」(l-lockv2.txt + hw xv6-locks)、LEC 13「Thread switching」(hw xv6-threads)、LEC 14「Coordination」(hw xv6-coordination)；LEC 20 RCU 论文延伸 — 访问 2026-10-23
4. Locking Details in xv6（Williams CS432 讲义 PDF）— https://www.cs.williams.edu/~cs432/lectures/Lecture13.pdf — 大学讲义对 xv6 锁粒度（细粒度每变量一锁 vs 粗粒度整表一锁，pid_lock/p->lock 例）的对照总结 — 访问 2026-10-23（检索摘要级）
5. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 概念挂载：Ch.7–10 调度、Ch.26–33 并发全家（锁 Ch.28–29、条件变量 Ch.30、信号量 Ch.31、Bug Ch.32）— 访问 2026-10-23
6. MIT 6.1810 csdiy 课程条目 — https://csdiy.wiki/en/%E6%93%8D%E4%BD%9C%E7%B3%BB%E7%BB%9F/MIT6.S081 — 中文社区对课程/lab 结构的导览页 — 访问 2026-10-23（检索摘要级）

## 摘录与要点
- （来源 1）官方定位原文：「In this lab you'll gain experience in **re-designing code to increase parallelism**. A common symptom of poor parallelism on multi-core machines is high lock contention. Improving parallelism often involves changing both data structures and locking strategies in order to reduce contention. **You'll do this for the xv6 memory allocator and block cache.**」——**2025 版 lock lab 的两半=分配器与块缓存**；前置阅读 xv6 book Ch.7「Locking」及对应代码。
- （来源 1）分配器一问的工程方法（正文）：官方把度量做进了内核——「acquire maintains, for each lock, the count of calls to acquire … and **the number of times the loop in acquire tried but failed to set the lock**. kalloctest … prints those counts for the kmem locks … and for the **5 most contended locks**」；任务=「**implement per-CPU freelists, and stealing when a CPU's free list is empty**」，所有新锁 `initlock` 名字必须以 "kmem" 开头；验证=kalloctest 看争用下降 + `usertests sbrkmuch` 证明全内存仍可分配。**「先有争用度量，再谈锁改造」**是本章工程范式的官方出处。
- （来源 1）读者写者一问（正文头段）：「Read-write lock — **This half of the assignment is independent from the first half**; you can work on this half (and pass the tests) whether or not you have completed the first half. Consider xv6's [bcache…]」——两半可并行推进；rwlock 用于块缓存的读多写少场景（细节见缺口清单）。
- （来源 2）教材锁章可直读 tex：「Xv6 has two types of locks: spinlocks and sleep-locks…」——sleeplock（能睡眠的锁）与条件变量式协调（sleep/wakeup + **谓词锁**防丢唤醒）在书内有专节（含 pipe 的读者/写者例子）——草案「OSTEP 不讲 xv6 sleep/wakeup」的缺口由**官方教材**（而非 OSTEP）清偿，讲义标注出处=xv6 book 锁章/调度章。
- （来源 3）官方课程序：锁改造实验的**概念预备**分散在 LEC 12–14（Locking/Thread switching/Coordination 三天各配一道 xv6 问答作业）；scheduler.c 睡眠-切换的机制叙述在书 Ch.8（CPU）——本章串读 sched.c/sleeplock.c/pipe.c 的清单由此得官方背书；「调度」概念挂 OSTEP Ch.7–10 的指针是**课程自定**（OSTEP 只讲策略算法不讲 xv6 轮转调度器）。
- （来源 4）外部对照：锁粒度谱系（每共享变量一锁↔整结构一锁）与 xv6 的 BKL 历史折衷——Williams 讲义摘要级可引，正文以本地源码为准。
- （来源 5）概念挂载核对：丢唤醒＝OSTEP Ch.30 条件变量 `wait` 丢信号问题（mutex 版 while 检查条件）在 xv6 的对应实现（sleep 前解锁、wake 后重取谓词锁）；死锁四条件与锁序在 Ch.32——「rwlock 写者优先取舍 vs 读者饥饿」书无成文答案，讲义给权衡（草案 gap 确认）。

## 本章仍缺的缺口
- 2025 版 rwlock 一问的完整题面（cachetest 判据、是否要求给 sleeplock 上应用、可选 seqlock 挑战）未取到，仅获题头——落地前补抓 https://pdos.csail.mit.edu/6.828/2025/labs/lock.html 全文。
- 「关大内核锁」在近年版 lock lab 中已非必做（2025 页正文无 BKL 字样）；草案「从 BKL 重构为细粒度锁」表述需按当年页修正为「分配器 freelists + bcache rwlock」两半。
- per-CPU 区机制（pcpu.h/cpu_no 纪律）与 `kalloctest` 输出的示例数字未抓到官方样本——讲义以本地跑分自采。
- sleep/wakeup 丢唤醒的最小复现时序（谓词锁讲解）无官方单页，讲义按 lock.tex 章节自编图。
