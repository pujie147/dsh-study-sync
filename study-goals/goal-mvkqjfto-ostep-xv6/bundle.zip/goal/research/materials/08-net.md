# 第 8 章 设备与中断：net lab（e1000 驱动）

## 来源清单
1. Lab: networking (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.1810/2025/labs/net.html — 官方当年 net lab 页定位句（NIC 驱动 + eth/IP/UDP 接收半栈）— 访问 2026-10-23（经 research 通道取到官方段落；整页直抓在 403 窗口）
2. Lab: networking (6.828 2024) — https://pdos.csail.mit.edu/6.828/2024/labs/net.html — 同题干官方页全文段（文件清单、中断策略、livelock 收尾问）— 访问 2026-10-23（经 research 通道取到正文）
3. Lab: networking (6.828 2022) — https://pdos.csail.mit.edu/6.828/2022/labs/net.html — 早期官方判据句「complete e1000_transmit() and e1000_recv(), both in kernel/e1000.c」 — 访问 2026-10-23（检索摘要级）
4. Lab: Network Driver (6.828 2019) — https://pdos.csail.mit.edu/6.828/2019/labs/e1000.html — 官方 e1000 专页：「需要深度使用 Intel 手册」的原文说明 — 访问 2026-10-23（检索摘要级）
5. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方配套：LEC 11「Device drivers」(l-interrupt.txt + 16550 串口手册 PDF + hw xv6-interrupt)；net lab 随 LEC 15「Networking」发放（10/15），hw「receive livelock 论文」问答；LEC 16 Shenango（高性能网络与调度）延伸 — 访问 2026-10-23
6. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 概念挂载：Ch.36 I/O Devices（轮询/中断/DMA/驱动=寄存器手册编程）、Ch.37 磁盘 — 访问 2026-10-23

## 摘录与要点
- （来源 1/2）官方定位原句：「In this lab you will write an xv6 device driver for a network interface card (NIC), and then write the **receive half of an ethernet/IP/UDP protocol processing stack**.」——net lab 两件事：驱动 + 协议栈接收侧。
- （来源 2）官方文件地图（正文逐字级）：`kernel/e1000.c` 已含 E1000 初始化代码 + 待填的 transmit/receive 空函数；`kernel/e1000_dev.h` = E1000 寄存器与标志位定义，「described in the **Intel E1000 Software Developer's Manual**」（页内给出手册链接）；`kernel/net.c/net.h` = 已写好的 IP/UDP/ARP 简易协议栈。学习者边界：驱动↔硬件，net.c↔协议——「最小寄存器子集导读」应围绕 e1000_dev.h 实际定义展开。
- （来源 2）官方中断策略说明（正文）：「In this lab, the networking stack uses interrupts to handle **ingress** packet processing, but not **egress** packet processing.」并展开进阶方案：出站软件排队、限量交给 NIC、用 TX 中断补环，从而可**做出站流量优先级**——轮询 vs 中断的取舍以真实代码呈现（挂 OSTEP Ch.36 三件套之「中断」与「驱动查手册」）。
- （来源 2）livelock 收尾问（正文逐字）：「The networking stack in this lab is **susceptible to receive livelock**. Using the material in lecture and the reading assignment, devise and implement a solution to fix it.」——题眼=OSDI receive livelock 论文（Mogul & Ramakrishnan，hw 指定）的对策：给中断处理限流/让正常收包路径有机会推进；官方自评此问「hard to test」。
- （来源 3/4）跨年份稳定判据句可引：transmit/receive 都填完、「You are done when make grade says your solution passes all the tests」；2019 页「writing a driver requires knowing in depth the hardware…**you'll need to make extensive use of Intel's manual**」——草案「手册体量大」缺口的官方自供。
- （来源 5）官方机理前置：LEC 11 用 **16550 串口手册**做「设备=寄存器集合」精读（hw xv6-interrupt），net lab 发放周（LEC 15）的作业就是 livelock 论文问答；官方顺序=驱动机理→实战网络。
- （来源 6）概念挂载核对 v1.10：OSTEP Ch.36 讲「设备接口=寄存器、MMIO/PIO、轮询→中断→DMA、稳定设备抽象之难、驱动 bug 占内核 bug 大半」——net lab 是其唯一全重量实践；**xv6 book 讲 virtio（三环协议），lab 用 e1000——两套文档术语对照表（virtqueue↔descriptor ring、MMIO 门铃↔TDT/RDT 指针）讲义必须自编**（草案缺口确认，官方两页均不互相解释）。

## 本章仍缺的缺口
- 2025 版 net lab 整页未抓到：三段任务的确切验收（transmit 段的 ping 目标与 `ping 10.0.2.15` 之类样例、`usertests net` 吞吐测法与数字、nettests 命名）暂依 2024 同题干页——落地前补抓 https://pdos.csail.mit.edu/6.1810/2025/labs/net.html 全文。
- Intel 8254x 软件手册 PDF 本次未抓取（页数大/官方仅给外链），最小寄存器子集导读待按 e1000_dev.h 源码本地核对。
- qemu `-netdev user` 用户态网络在 WSL2 宿主上的差异与坑位：未检索到可靠官方页面，维持讲义排障卡方案（草案 gap 保留）。
