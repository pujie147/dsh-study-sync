# 第 1 章 出征与基线：WSL2 工具链 + xv6 源码地图 + lab 工程动线

## 来源清单
1. Tools Used in 6.1810 (Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/tools.html — 本课官方安装文档：Debian/Ubuntu 一行命令、Windows 走 WSL2 的官方姿势、QEMU/GCC 版本自检 — 访问 2026-10-23
2. Lab guidance (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/guidance.html — 官方实验方法论：难度分级、git 提交/checkpoint、gdb 工作流、kernel.asm/addr2line、qemu monitor — 访问 2026-10-23
3. Xv6, a simple Unix-like teaching operating system — https://pdos.csail.mit.edu/6.828/2025/xv6.html — xv6 官方信息页：源码与配套书的 clone 命令、xv6 与 V6/Lions 的渊源 — 访问 2026-10-23
4. GitHub - mit-pdos/xv6-riscv — https://github.com/mit-pdos/xv6-riscv — 主线仓库：fork/star 规模、riscv 主分支、pdos.csail.mit.edu/6.1810 指向 — 访问 2026-10-23
5. How to install Linux on Windows with WSL (Microsoft Learn) — https://learn.microsoft.com/en-us/windows/wsl/install — WSL 官方安装与版本核查文档（wsl --install / wsl -l -v / --set-version）— 访问 2026-10-23
6. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方课表：九个 lab 的发放/截止顺序与每讲指定阅读 — 访问 2026-10-23
7. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — OSTEP 官方免费书目录：三大件与各章 PDF 编号，作全课程概念挂图的权威索引 — 访问 2026-10-23

## 摘录与要点
- （来源 1）官方要求 RISC-V 版 QEMU 7.2+、GDB 8.3+、GCC、Binutils；Ubuntu 一行装：`sudo apt-get install git build-essential gdb-multiarch qemu-system-misc gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu`，并注明「likely need Ubuntu 24+ 才能 apt 装到够新的 qemu」。
- （来源 1）Windows 官方路线：装 WSL 2 + Microsoft Store 的 Ubuntu 24.04，推荐配合 Windows Terminal；`wsl -l -v` 确认是 WSL 2（「WSL 1 does not work with the 6.1810 labs」）；Windows 侧可从 `\\wsl$\Ubuntu-<ver>\home\<user>` 访问文件。macOS 走 xcode-select + Homebrew riscv/riscv tap + brew qemu；VirtualBox Linux VM 为备选。
- （来源 1）安装自检命令与期望输出：`qemu-system-riscv64 --version` 示例回 7.2.0；`riscv64-linux-gnu-gcc --version`（另列 riscv64-unknown-elf-gcc / riscv64-unknown-linux-gnu-gcc 三种可选前缀）。
- （来源 3）源码与配套书分别 clone：`git clone https://github.com/mit-pdos/xv6-riscv.git` 与 `git clone https://github.com/mit-pdos/xv6-riscv-book.git`；xv6 受 Unix V6 与 Lions《Commentary on UNIX 6th Edition》启发（Russ Cox / Frans Kaashoek / Robert Morris）。
- （来源 2）lab 通用工程法：题目按 Easy(<1h)/Moderate(1-2h)/Hard(>2h) 分级；「代码量几十到几百行但概念复杂、细节决定成败」；先在纸上想清楚再写，小步实现小步测；「别在截止前一晚开 lab」；partial 进度用 git commit 做 checkpoint。
- （来源 2）调试工具箱：`make qemu-gdb` 双窗 gdb（`b syscall` / `layout src` / `backtrace`）；内核 panic 会打印 sepc，可用 `kernel/kernel.asm` 搜索或 `addr2line -e kernel/kernel <pc>` 定位；hang 住时 gdb 里 Ctrl-C + `bt`；日志刷屏时用 `script` 包住 `make qemu` 落盘再搜；qemu monitor 用 Ctrl-a c 进入，`info mem` 直接看页表，单核可 `make CPUS=1 qemu`。`.gdbinit` auto-loading 被拒时按提示加 `add-auto-load-safe-path`。
- （来源 6）官方课表的 lab 发放顺序：util → syscall → pgtbl → traps → cow → net → lock → fs → mmap（net 在 lock 前发放；本课大纲按依赖采用 lock→net，讲义需说明与官方顺序的差异）；每讲配 xv6 book 章节阅读（如 LEC 18 崩溃恢复要求读 kernel/log.c + 书的 logging 节）。
- （来源 7）OSTEP v1.10 结构确认：Virtualization（Ch.4–11 CPU、Ch.13–24 内存）、Concurrency（Ch.26–34）、Persistence（Ch.36–46）、Distributed（Ch.48–51）、Security（Ch.53–57）＋附录 Virtual Machines 与 xv6 Labs（lab-projects-xv6.pdf）。
- （来源 5）WSL 基线补充：`wsl --install` 默认装 Ubuntu；`wsl --set-version <distro> 2` 可把已装发行版升级到 WSL 2；Windows 10 2004+/Windows 11 前提。

## 本章仍缺的缺口
- 主线 README 的 BUILDING AND RUNNING XV6 原文细节（本次打开 GitHub 仓库页时正文被截断，未取到构建说明段；可用来源 1/3 官方文档替代）。
- xv6 book（rev5）PDF 各章与「三大件→源码文件」映射的逐页核对（PDF 本次抓取被拒，仅拿到章节名层面信息；讲义需按书目录自行核对 Ch.2–10 与 proc.c/vm.c/log.c 的对应表述）。
- WSL2 上 qemu 串口按键（Ctrl-A x / Ctrl-A c）与 Windows Terminal 按键映射的实测差异，无官方文档条目，属讲义自写排障卡。
- 姊妹课提到的社区 Docker 镜像路线仍未核验到稳定官方仓库页，维持不列入主线。
