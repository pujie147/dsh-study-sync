# 第 5 章 页表与地址翻译：pgtbl lab

## 来源清单
1. Lab: page tables (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.1810/2025/labs/pgtbl.html — 官方 pgtbl lab 页正文（pgtbltest/USYSCALL/superpages 三任务判据）— 访问 2026-10-23（经 research 通道取到正文段落）
2. 6.1810 Lab - Page Tables（Glucoco 中文笔记）— https://glucoco.com/2025-04-28/61810-lab-pgtbl/ — 2025 版逐任务拆解：页表样本输出、mappages 片段、大页思路与实验结果 — 访问 2026-10-23
3. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方时序：pgtbl lab 随 LEC 5「Page tables」(l-vm.txt) 发放（9/17），hw xv6-pgtbl 同日；LEC 9 讲 superpages 论文 — 访问 2026-10-23
4. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 概念挂载：Ch.18 Introduction to Paging、Ch.19 TLBs、Ch.20 Advanced Page Tables（多级/大页）— 访问 2026-10-23
5. Lab guidance (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/guidance.html — qemu monitor `info mem` 直接看页表（本章手工核验翻译的官方工具）— 访问 2026-10-23

## 摘录与要点
- （来源 1）官方定位：「In this lab you will explore page tables and **modify them to implement common OS features**」。**2025 版三任务**（与草案假设的旧版「权限位测试程序三件套」不同，讲义按当年页校准）：
  ① `print_pgtbl` 观察——`pgtbltest` 用官方新加的 `pgpte` 系统调用打印本进程用户页表**前 10 与后 10 页**的 PTE；
  ② **USYSCALL 共享页提速 getpid**——「Run make qemu and run pgtbltest…When each process is created, map one read-only page at USYSCALL (a virtual address defined in memlayout.h). At the start of this page, store a struct usyscall…initialize it to store the PID…ugetpid() has been provided on the userspace side…full credit if the ugetpid test case passes」；
  ③ **superpages**——「if a user program calls sbrk() with a size of 2 megabytes or more, and the newly created address range includes one or more areas that are two-megabyte-aligned and at least two megabytes in size, the kernel should use a single superpage (instead of hundreds of ordinary pages)…full credit if the **superpg_fork** and **superpg_free** test cases pass」。
- （来源 2）2025 版任务清单中文复述与官方输出样本：任务①打印样本——`0xffffe000 … VRW-- Trapframe`、`0xfffff000 … VR-X- Trampoline`（权限位串 V/R/W/X/U 直读，正是讲义「逐一验证权限」想要的活表格）；任务②实现要点（贴官方推荐代码形）：`mappages(pagetable, USYSCALL, PGSIZE, (uint64)(p->usyscall), PTE_R | PTE_U)`，参照 proc.c 对 trapframe 页的处理，进程退出时同样回收；「免陷入读 pid」＝用一页共享内存换掉一次 trap 往返——受限执行的**性能税**案例。大页任务动机（官方原句）：「Use of superpages decreases the amount of physical memory used by the page table, and can decrease misses in the TLB cache」。
- （来源 2）任务③（官方原文段落）：对 vmprint 输出逐叶解释内容与权限、与 print_pgtbl 输出对照，「xv6 book 图 3.4 可参考但页面集合略有差异」——本章的源码阅读锚点即 xv6 book Ch.3（Page tables）与 kernel/vm.c。
- （来源 3）官方时序：页表讲（l-vm.txt）当天发 pgtbl lab；一个月后 LEC 9「Transparent super pages」（论文）与 cow lab 同周——superpage 一问在此有了呼应。
- （来源 5）手工核验通道：qemu monitor（Ctrl-a c）的 `info mem` 直接输出当前核页表——草案「至少一处 gdb 手工核验」的官方等价物，二者都进讲义验证点。
- （来源 4）概念挂载核对 v1.10：$VPN \to PTE \to PPN$ 与有效地址计算在 Ch.18；TLB 命中/缺失在 Ch.19；**多级表省空间在 Ch.20（Orthogonal/多级页表）**——superpages 一问对应 Ch.20 大页讨论；Sv39 三级拆分（9/9/9/12 位）书不讲，讲义自绘图（草案缺口确认）。

## 本章仍缺的缺口
- pgtbl 官方页**整页**未抓到（403 时段），hints 小节与 grade 测试全名单未取——落地前补抓 https://pdos.csail.mit.edu/6.1810/2025/labs/pgtbl.html 全文；旧版（kpgtbl 内核页表改造/answers-lab-pgtable）与 2025 版差异以当年页为准（草案预设的版本漂移风险成立）。
- Sv39 地址位分段与 PTE 格式的规范原文（特权手册 PDF 未抓取成功）——讲义表格需按 riscv-privileged-20211203.pdf 离线核对后标注出处页码。
- 大页（2MB）在 mappages 数据结构上的表达方式（叶级 LEVEL 1）官方未给模板——属设计自由度，讲义给权衡不给唯一解。
