# 第 2 章 进程与 IPC：util lab（pingpong / findpipe / runc）

## 来源清单
1. Lab: Xv6 and Unix utilities (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/util.html — 官方 util lab 当年任务页（含 boot xv6、make qemu 全流程、grade 命令）— 访问 2026-10-23
2. Lab: Xv6 and Unix utilities (6.828 2024) — https://pdos.csail.mit.edu/6.828/2024/labs/util.html — 大纲所指 pingpong/findpipe/runc 版 util lab 的官方页 — 访问 2026-10-23（经 research 检索通道取到 pingpong 段落，全文页当时抓取失败）
3. Lab guidance (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/guidance.html — 官方 lab 方法：难度分级、C 指针惯用法、git 提交 checkpoint — 访问 2026-10-23
4. Operating Systems: Three Easy Pieces 目录页 (v1.10) — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 概念挂载权威索引：进程 Ch.4–6、调度 Ch.7–10、并发 Ch.26–34 — 访问 2026-10-23
5. zhaoyw1999/xv6-labs-2024 — https://github.com/zhaoyw1999/xv6-labs-2024 — 维护良好的 2024 版全 lab 解答仓库（含博客讲解链接），可作 util 三问的对照参考 — 访问 2026-10-23（检索摘要级）

## 摘录与要点
- （来源 1）2025 版 util lab 官方发放方式：`git clone git://g.csail.mit.edu/xv6-labs-2025`，每 lab 一个分支（`origin/util` 等），`git checkout util && make clean` 起步；`git diff origin/util` 查看自己的改动。
- （来源 1）boot 全流程原文可作第 1 章「运行闭环」实证：`make qemu` 依次编译内核/用户程序、`mkfs` 造 fs.img（输出 `nmeta 46 ... blocks 954 total 1000`），启动命令为 `qemu-system-riscv64 -machine virt -bios none -kernel kernel/kernel -m 128M -smp 3 -nographic -drive file=fs.img,...virtio-blk-device`；登录 shell 后 `ls` 列出 init/sh/usertests 等；**xv6 没有 ps，Ctrl-p 让内核打印每个进程信息**；退出 qemu 是 **Ctrl-a x**。
- （来源 1）2025 版任务清单为 sleep（用户态 sleep 用 `pause` 系统调用，sys_pause 在 kernel/sysproc.c，存根链 user/usys.S←usys.pl）、sixfive（open/read 文本处理）、memdump（K&R 指针练习 i/p/h/c/s/S 格式符）、find（递归目录树匹配名字，参考 user/ls.c，勿入 "." ".."）、exec（find -cmd 用 fork+exec+wait 执行外部命令，MAXARG 在 kernel/param.h）。验收 `make grade` / 单测 `./grade-lab-util sleep`。
- （来源 2）大纲三问在 2024 版官方页：pingpong 原文——「用一对管道在两个进程间乒乓一个字节；父发子收、打印 `<pid>: received ping`、把字节写回；子进程从父进程那继承多余 fd 会导致写不结束」——正是「关闭不用的管道 fd」这一头号坑的官方表述。
- （来源 1）工程习惯官方原话：新程序加进 Makefile 的 UPROGS 才会被编进 fs.img；`make qemu` 每次重建 fs.img 并备份旧的为 fs.img.bk，想保留上次文件系统用 `make qemu-fs`；命令行参数转整数用 user/ulib.c 的 atoi。
- （来源 3）官方提醒先弄懂 C 指针惯用法再写 lab：`(int)p+1` 与 `(int)(p+1)` 的区别、`p[i]==*(p+i)`、`&p[i]==(p+i)`——os 代码常做指针/整数互转。
- （来源 4）概念挂载核对：OSTEP v1.10 目录中进程部分为 Ch.4 Processes / Ch.5 Process API / Ch.6 Direct Execution（另有 Ch.7–10 调度）；**v1.10 目录页已无独立的 IPC/pipes 件**（早期版本的 Process Communication/Pipes 章不在当前免费目录内），util 章的「管道」概念挂载应改走 xv6 book 的 pipe 章 + OSTEP Ch.5 fork/exec/wait API 章；本发现直接修正课程草案中「Ch.10–12 = IPC」的映射表述（v1.10 中 Ch.10 = Multi-CPU Scheduling）。
- （来源 5）第三方 2024 全 lab 解答仓库存在且可访问，README 声明逐 lab 方案与博客文章，可作批改对照（使用前与官方 grade 脚本交叉验证）。

## 本章仍缺的缺口
- findpipe / runc 的官方任务全文未抓到（2024 页仅取得 pingpong 段；findpipe 的 `ps` 读 `/proc` 语义、runc 重实现 sh 的精确判据待后续补抓或按 2025 版 find/exec 重写本章实操题）。
- 2025 版 sleep 系统调用为何改名 pause：主线 kernel/syscall.h 是否同步改名，需对照 xv6-riscv 源码确认（本次 raw.githubusercontent 抓取失败）。
- pingpong 死锁的最小复现时序图（mermaid 时序 + fd 引用计数解释）须讲义自绘——官方页只有文字判据。
- OSTEP v1.10 是否彻底删除 IPC 件（或移至别册）：目录页未见，未在正文核实，讲义引用时按「v1.10 目录为准」表述。
