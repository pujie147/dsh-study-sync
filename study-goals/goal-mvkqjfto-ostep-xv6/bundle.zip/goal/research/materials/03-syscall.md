# 第 3 章 系统调用全链路：syscall lab

## 来源清单
1. Lab: system calls (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/syscall.html — 官方 syscall lab 全文：gdb 走查问答、sandbox（interpose）两问、Attack xv6（内存残留信息泄漏）— 访问 2026-10-23
2. Lab guidance (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/guidance.html — gdb 双窗工作流与 panic 定位法（本章「全链路走查」的方法论出处）— 访问 2026-10-23
3. 6.1810 Fall 2025 Schedule — https://pdos.csail.mit.edu/6.828/2025/schedule.html — 官方配套：LEC 6「System call entry/exit」(l-internal.txt) 与 hw trampoline、LEC 7 interposition (Janus 论文) 随 traps 发放 — 访问 2026-10-23
4. Lab: Xv6 and Unix utilities (6.1810 Fall 2025) — https://pdos.csail.mit.edu/6.828/2025/labs/util.html — 官方页给出的 usys.pl→usys.S→sys_ 实现的入口线索（sleep→pause、sys_pause 三处定位）— 访问 2026-10-23

## 摘录与要点
- （来源 1）**关键版本事实：2025 官方 syscall lab 主题不是 sysinfo**，而是：①gdb 走查问答 ②新增 `interpose` 系统调用做沙箱（两小问）③Attack xv6。草案按 sysinfo 写的知识点仍有效（全链路机制相同），但讲义应以 2025 任务为主线并说明历年主题漂移（date→sysinfo→sandbox）。
- （来源 1）官方文件清单（原句）：用户存根 `user/usys.S`（make 时由 `user/usys.pl` 生成）、声明 `user/user.h`；内核路由 `kernel/syscall.c` + `kernel/syscall.h`；进程侧 `kernel/proc.h/proc.c`。前置阅读：xv6 book Ch.2「System call organization」§4.3–4.4。
- （来源 1）gdb 走查链（answers-syscall.txt 的题源，逐条可作讲义实操）：`b syscall`→backtrace 问「谁调用了 syscall」；`p /x *p` 看 proc 结构；**问 `p->trapframe->a7` 的值与含义**（提示对照 user/init.c 与其 init.asm——a7=系统调用号）；`p /x $sstatus` 问 CPU 前一模式（SPP 位）；把 `num = p->trapframe->a7` 换成 `num = *(int*)0` 人为造 kernel page fault → `scause=0xd sepc=0x80001bfe stval=0x0 panic: kerneltrap`→在 kernel/kernel.asm 搜 sepc、`addr2line -e kernel/kernel`、`b *0x80001bfe`+`layout asm` 复核；`p p->name` 找肇事进程。官方还链接 RISC-V 特权手册（Priv-v1.12，riscv-privileged-20211203.pdf）解释 scause。
- （来源 1）任务「Sandbox a command」原文要点：新增 `interpose(mask, path)`——mask 位=要拒绝的系统调用号（`1<<SYS_open`，号在 kernel/syscall.h）；实现链：user/user.h 原型 + user/usys.pl 存根 + kernel/syscall.h 编号 + `sys_interpose()`（建议放 kernel/sysproc.c，用 argint/argstr 取参）+ syscalls[] 表登记 + **kfork() 复制 mask 使子进程继承限制** + syscall() 主循环检查拒绝。判据 `./grade-lab-syscall sandbox_mask`（另有 sandbox_fork/path/most/minus 共 5 测）。
- （来源 1）任务「Sandbox with allowed pathnames」：第二参 path 允许名单，open/exec 被 mask 但路径匹配则放行；proc 结构加 MAXPATH 缓冲存路径。**注意：这就是「内核校验用户给的字符串」的工程课——argstr/fetch 的边界条件在此上岗**。
- （来源 1）任务「Attack xv6」：lab 分支用 `#ifndef LAB_SYSCALL` 摘掉 vm.c `uvmalloc()` 与 kalloc.c 的 3 行 memset——新分配页不清零、空闲页变垃圾——于是 `sbrk` 拿到的旧页残留前一进程 `secret.c` 的秘密；给 attack.c 加几行扫出来即胜（判据 `./grade-lab-syscall attack`）。官方借 Linux 漏洞库与 kernel 安全流程文档收尾：**未影响正确性的 bug 也能破坏隔离**——受限执行（OSTEP Ch.5/6）的反面教材，讲义必保留。
- （来源 2）gdb 工作流官方叙述（make qemu-gdb 双窗、bt、panic 断点等）可直接进讲义「调试卡」。
- （来源 4）与 util 章衔接：2025 版用户态 sleep 程序调的是 **`pause()` 系统调用（sys_pause）**——主线把老的 `sleep` 系统调用改名了；讲义「fork/exec/wait/exit」对账单里 sleep→pause 的名称映射需按当年源码核（草案 focus_points 写 sleep 处应加注）。

## 本章仍缺的缺口
- l-internal.txt（System call entry/exit 讲义 txt）正文未抓取成功（403 时段），trap 入口逐指令讲解需补抓 https://pdos.csail.mit.edu/6.828/2025/lec/l-internal.txt 或以 xv6 book Ch.4 替代。
- 特权手册中 sstatus.SPP/scause 编码表的规范原文本次未取（PDF 抓取被拒），速查表数值以第 4 章资料页所列「已印证项+待核对项」为准。
- sysinfo 版 syscall lab（2023/2024）的 struct status 布局题全文未抓取——讲义若保留「设计采集点」练习需另找年份页或自编。
