# 计时器：考场节奏自检脚本（选做，需 Python）

用法：`python timer.py 120` —— 倒计时 120 分钟，模拟综合知识科目用时上限。
无 Python 环境可用手机秒表/任意番茄钟替代，本脚本仅为顺手工具。

```python
import sys, time
minutes = int(sys.argv[1]) if len(sys.argv) > 1 else 120
deadline = time.time() + minutes * 60
try:
    while True:
        left = deadline - time.time()
        if left <= 0:
            print("时间到！")
            break
        m, s = divmod(int(left), 60)
        print(f"\r剩余 {m:02d}:{s:02d}", end="", flush=True)
        time.sleep(1)
except KeyboardInterrupt:
    print("\n提前交卷。")
```
