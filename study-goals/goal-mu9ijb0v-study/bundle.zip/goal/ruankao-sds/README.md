# ruankao-sds —— 软件设计师备考知识库（全课程工程基线）

主分支 `main` = 全课程基线。**每章从合并点开 `chapter/NN-topic` 分支开发，章末验证后合并回 main，禁止直接在 main 上提交。**

## 目录骨架

| 目录 | 用途 |
|------|------|
| outline/ | 大纲、分值地图、学习计划 |
| notes/NN-章名/ | 各章笔记与讲义批注 |
| drills/ | 每日刷题记录（模板 `_template.md`） |
| pastpapers/ | 真题 PDF 与自评（清单 `checklist.md`） |
| mistakes/ | 错题本，按考点归类（模板 `_template.md`） |
| tools/ | 辅助脚本（计时器等） |
