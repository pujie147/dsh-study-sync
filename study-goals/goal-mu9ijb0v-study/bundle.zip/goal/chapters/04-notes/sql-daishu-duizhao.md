# SQL 指令与关系代数运算逐一对应

> 补充日期：2026-02-05 · 来源：课堂问答「σ/Π/⋈ 对应哪些 SQL 指令」

## 0. 核心误区先行：SQL 关键字 `SELECT` ≠ 代数"选择"

这是命名上的历史错位，考试双向翻译题的第一陷阱：

| 关系代数 | 直观含义 | SQL 真正对应的位置 |
|---|---|---|
| $\sigma$ 选择（水平切**行**） | 挑满足条件的记录 | **`WHERE` 子句** |
| $\Pi$ 投影（垂直切**列**） | 挑要保留的属性 | **`SELECT` 后面的列清单** |

即：SQL 的关键字 `SELECT` 干的是投影 $\Pi$ 的活；"选择"反而藏在 `WHERE` 里。讲义 4.5 骨架 `SELECT 投影 FROM 源 WHERE 选择 ...` 正是此意。

## 1. 逐运算完整对照

设 $S$=Student、$SC$=选课表、$Course$=课程表。

### 1.1 $\sigma$ 选择 → `WHERE`

$$\sigma_{Sage>20}(S) \quad\Leftrightarrow\quad \texttt{SELECT * FROM Student WHERE Sage > 20;}$$

`*` 表示暂不投影、全列保留。

### 1.2 $\Pi$ 投影 → `SELECT 列清单` + `DISTINCT`

$$\Pi_{Sname,Sage}(S) \quad\Leftrightarrow\quad \texttt{SELECT DISTINCT Sname, Sage FROM Student;}$$

⚠️ **暗坑升级**：关系代数的 $\Pi$ 在集合语义下**天然自动去重**；SQL 默认**不去重**，必须显式写 `DISTINCT` 才与代数等价。考试问"这条 SQL 的结果与该代数式是否一致"时，缺 `DISTINCT` 就是差异点——这正是讲义 4.3.3 "投影去重暗坑"的另一面。

### 1.3 $\times$ 笛卡尔积 → `CROSS JOIN`（或无条件的逗号连接）

$$S \times SC \quad\Leftrightarrow\quad \texttt{SELECT * FROM Student CROSS JOIN SC;}$$

老写法 `FROM Student, SC` 不带连接条件即笛卡尔积。

### 1.4 $\bowtie$ 连接家族 → `JOIN ... ON`

- **$\theta$ 连接**：$S \bowtie_{S.Sno=SC.Sno} SC$ ⇔ `SELECT * FROM Student JOIN SC ON Student.Sno = SC.Sno;`
- **自然连接** $S \bowtie SC$（同名属性等值 + **消去重复列**）：标准 SQL 有 `NATURAL JOIN`，但各 DBMS 支持不一；实战用 `JOIN ... ON` + 在列清单里只列一次公共列来模拟"消重列"。
- **外连接**：`LEFT / RIGHT / FULL OUTER JOIN`，缺配补 NULL，对应讲义 4.5.3。

### 1.5 并 $\cup$、差 $-$、交 $\cap$ → 集合指令

| 代数 | SQL | 备注 |
|---|---|---|
| $R \cup S$ | `UNION` | 默认去重；`UNION ALL` 保留重复 |
| $R - S$ | `EXCEPT` | MySQL 早期版本不支持，用 `NOT IN` / `LEFT JOIN ... IS NULL` 变通 |
| $R \cap S$ | `INTERSECT` | MySQL 8 之前不支持，用 `IN` 变通 |

三者均要求参与查询**同目且对应列同源**（呼应讲义 4.3.3 并/差前提）。

### 1.6 $\div$ 除运算 → 无直接指令，靠 `NOT EXISTS` 双重否定

求"选修了全部课程的学生学号"：$\Pi_{Sno}(SC) \div \Pi_{Cno}(Course)$

```sql
SELECT Sno FROM Student S
WHERE NOT EXISTS (
    SELECT Cno FROM Course            -- 存在一门课……
    WHERE NOT EXISTS (
        SELECT * FROM SC
        WHERE SC.Sno = S.Sno AND SC.Cno = Course.Cno   -- ……是该生没选的
    )
);
```

逻辑："不存在一门课是该生没选的" = "该生选了所有课"。识别信号仍是题干"全部/所有"字样。

## 2. 骨架映射总图

```mermaid
flowchart LR
    subgraph ALG["关系代数"]
        A1["σ 选择"]
        A2["Π 投影"]
        A3["⋈ 连接"]
        A4["∪ − ∩ 集合"]
        A5["÷ 除"]
    end
    subgraph SQLS["SQL 子句或指令"]
        B1["WHERE"]
        B2["SELECT 列清单 + DISTINCT"]
        B3["JOIN ON"]
        B4["UNION EXCEPT INTERSECT"]
        B5["NOT EXISTS 双重否定"]
    end
    A1 --> B1
    A2 --> B2
    A3 --> B3
    A4 --> B4
    A5 --> B5
```

## 3. 书写顺序 vs 求值顺序（附赠考点）

以 $\sigma_{Sage>20}(\Pi_{Sname,Sage}(S))$ 为例，SQL 为：

```sql
SELECT DISTINCT Sname, Sage FROM Student WHERE Sage > 20;
```

- **书写顺序**固定：SELECT → FROM → WHERE；
- **求值顺序**：先 FROM 定位源，再 WHERE 切行（选择），最后 SELECT 切列（投影）；
- 代数式中 σ 与 $\Pi$ 可交换的前提是投影列保留了 σ 用到的属性（本例 Sage 在列清单中，故可交换）；若投影不含 Sage，则 $\sigma$ 必须先做。

## 4. 一句话口诀

见到 SQL 关键字别被名字骗：**`SELECT`=投影 $\Pi$，`WHERE`=选择 $\sigma$，`JOIN`=连接 $\bowtie$，`UNION/EXCEPT/INTERSECT`=并差交，`NOT EXISTS×2`=除**。
