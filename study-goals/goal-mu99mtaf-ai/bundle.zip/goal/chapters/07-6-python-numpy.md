# 第6章 · Python 与 NumPy：把数学跑起来

> 课程：AI 预科——从零补齐数学与编程基础 ｜ 建议学时：24 小时（按 gap-list F 组档位裁剪）｜ 前置：第0–5章
> 本章产出：三场「手写实现 vs 库函数」的对拍（矩阵乘 / 梯度下降 / 交叉熵）、一套 pytest 恒等式测试、一份锁定版本的 `requirements.txt`——以及最重要的：**向量化思维**的换脑手术。

---

## ① 本章概览（总）

### 1.1 本章在全课程框架中的位置

四层地基之上的**工具层**。前五章你一直在纸上和半吊子代码里学数学；本章把解释器升级成你的正式乐器。定位有两句话：

1. **正向**：Python/NumPy 是 AI 世界的通用语——从作业 notebook 到 PyTorch 源码，语法与数据姿势完全相同；
2. **反向巩固**（本章特色）：每个已学概念都值得「跑一遍」——$\sum$ 就是 for 循环（第1章预告）、广播就是分块矩阵（第3章挂账还清）、`scipy.optimize.minimize` 就是你手写的 GD 的专业版（第4章）、`log_loss` 就是你推过的 BCE（第5章）。**代码是不会说谎的陪练**：手算与程序不一致 = 必有一错，当场暴露（第0章双轨制的全面执行）。

台账上归属本章的欠账：NumPy 向量化与广播机制（第1、3章挂）、随机种子与数值精度工程化（第2、4、5章散落各处）、`requirements.txt` 版本锁定承诺（第0章）。

### 1.2 本章抽象框架：三层栈 + 一台对拍机

```mermaid
flowchart TB
    subgraph STACK["科学计算三层栈"]
        L1["语言层: Python 本体<br/>变量·容器·控制流·函数·模块<br/>—— 第1章数学语言的代码镜像"]
        L2["数组层: NumPy ndarray<br/>形状 shape 是新世界观<br/>广播 = 自动补全的分块代数"]
        L3["应用层: matplotlib 画图<br/>SciPy/sklearn 现成数学<br/>pytest 验收"]
        L1 --> L2 --> L3
    end
    subgraph LAB["贯穿全章的对拍方法论"]
        SLOW["慢而正确: 纯 Python 直译公式"]
        FAST["快而等价: 向量化一行式"]
        JUDGE["裁判: 库函数/解析解/assert"]
        SLOW -->|计时对比| FAST
        FAST -->|allclose 容差断言| JUDGE
        JUDGE -->|不一致即 bug 或误解| SLOW
    end
    STACK -.素材全部来自.-> LAB
    OUT["结业标准: 前五章任何一条公式<br/>你能在 10 分钟内给出可运行的向量化验证"]:::hl
    classDef hl fill:#d6f5d6,stroke:#2e8b57
```

一句话读图：语言层解决「会写」，数组层解决「写得像数学家」，应用层解决「看得见、验得过」；对拍环是三层的质检流水线——先求对，再求快，永远求证。

### 1.3 分节地图

| 节 | 内容 | 对应核心知识点 |
|---|---|---|
| §2 | 承接与补完：工程接力 + 台账清偿 | git 动线、依赖安装、广播还账声明 |
| §3 | 热身：解释器是最诚实的助教 | 环境自检 |
| §4.1 | Python 核心语法速成 | 类型、列表/字典、控制流、函数、模块与环境 |
| §4.2 | Jupyter 工作流 | notebook 组织、magic、Markdown+LaTeX 混排 |
| §4.3 | NumPy I：ndarray 与形状 | dtype/shape/切片、$\sum$↔`sum(axis)` |
| §4.4 | NumPy II：广播与向量化 | 广播规则、batch 仿射一行式、性能解剖 |
| §4.5 | matplotlib 三件套 | 函数图/散点/等高线/直方图 |
| §4.6 | SciPy 巡礼与调试习惯 | optimize/stats、步长精度种子、单元测试 |
| §5/§6 | 动手练习 / 小结 | — |

---

## ② 承接与补完

### 2.1 工程接力：从 chapter/05-done 出发

严禁重搭环境。开工：

```powershell
cd C:\Users\pyg12\.dsh\study-work\goal-mu99mtaf-ai\ai-prep
conda activate aiprep
git checkout -b chapter/06-python chapter/05-done   # 从第5章合并点开本章分支
pip install -r requirements.txt                     # 基线已升级为锁定版本清单(含 scikit-learn/pytest)
```

本章文件只进 `06-python/`；基线已预置 `warmup.py`（纯 Python 热身）、`math-in-code.ipynb`（对拍台，第一场已写好示例）、`test_math.py`（pytest 骨架），§5 直接用。

### 2.2 黑盒台账与本章清偿

| 欠账（出处） | 本章清偿位置 |
|---|---|
| 「$\sum$ 就是 for 循环，第6章告诉你它如何压缩成一行向量化」（第1章 §4.4） | §4.3–4.4 |
| 「batch 堆矩阵一次加工、GPU 指令形态」（第3章 §4.6 分块） | §4.4 广播兑现 |
| 「步长、精度、随机种子——代码轨负责『对到什么程度』」（第0章 §5.3、第4章练习 1、第5章 seed=7） | §4.6 专题收编 |
| 「requirements.txt 第6章锁定版本」（第0章 §2.2） | §2.1 已随基线交付，§4.1 讲其意义 |
| 「underflow 的工程化处理 clip/log-sum-exp」（第2、5章） | §4.6 数值习惯 + 练习 2 第三场对拍实测 |

继续挂账不动：反向传播记账细节与知识蒸馏实操（第7章）、MCMC 等高级推断（超出预科，台账在案）。

---

## ③ 热身：解释器是最诚实的助教

打开 PowerShell：

```powershell
python            # 进入 REPL, 出现 >>>
>>> 2 ** 100      # 第2章指数增长的裸演示
1267650600228229401496703205376
>>> exit()
```

这个能即时吐答案的窗口，就是本章全部实验的起跑线。它不会像人一样客气地放过你的错误理解——**你以为的规则和它执行的规则不一致时，永远是你需要修改认知**。

---

## ④ 正文

### 4.1 Python 核心语法：五章数学词汇的代码镜像

**结论先行**：语法只需四样就能覆盖前五章所有伪代码——容器、控制流、函数、模块。逐条与数学记号挂钩学习，效率翻倍。

**变量与类型**：动态类型（贴标签而非铸模具）。关键三族：`int/float`（注意 `/` 永远得 float、`//` 整除、`**` 乘方）、`str`、`bool`。第1章 $\mathbb{N}\subset\mathbb{Z}\subset\mathbb{Q}\subset\mathbb{R}$ 的扩建观在此有代码版：`1` → `1.0` → `True` 各有身份，混合运算自动向上兼容；但浮点是 $\mathbb{R}$ 的**有损采样**——`0.1 + 0.2 == 0.3` 返回 `False`（二进制小数表示缺陷，第2章 underflow 的近亲），比较浮点永远用容差（§4.6）。

**容器**：

| 数学对象 | Python 容器 | 例 |
|---|---|---|
| 集合 $\{x\mid P(x)\}$ | `set` + 推导式 `{x for x in A if P(x)}` | 描述法逐字翻译 |
| 有序数组 $v\in\mathbb{R}^n$ | `list`（异质、慢）→ `np.array`（同质、快） | 第3章向量的两种户口 |
| 映射 $f:A\to B$ | `dict`（键→值哈希表） | 词表→ID 的 embedding 前身 |
| 笛卡尔积 $A\times B$ | `itertools.product(A, B)` 或双层推导式 | 第1章 §4.1 原型 |

**控制流**：`for i, x in enumerate(xs)` 就是「$\forall i\in\{0,\dots,n-1\}$」的量词循环；`if/elif/else` 是分段函数 $f(x)=\begin{cases}\dots\end{cases}$；列表推导 `[f(x) for x in xs if P(x)]` 是「筛选+映射」二合一，比循环优雅且快。

**函数**：`def f(x): return ...` 对应第1章 $x\mapsto f(x)$；默认参数、多返回值（元组打包）、`lambda` 匿名小函数（notebook 里传目标函数用）。函数是一等公民——可以当参数传（第1章复合！`compose(f, g)` 练习 1 见）。

**模块与环境**：`import math`、`from numpy import linalg`；自己写的 `.py` 也是模块（前几章的 `mini-linalg`、`gradient_lab` 今天全部变成 import 对象）。虚拟环境的意义（第0章装 conda 时的悬案）：`aiprep` 就是一个隔离抽屉，`requirements.txt` 是抽屉的**配方单**——版本号锁定（如 `numpy>=1.26,<2.0`）保证一年后复现、同学接手时行为一致。「在我电脑上能跑」是科研第一大谎言，锁版本是第一剂解药。

> ⚠️ 常见误区：可变默认参数陷阱 `def f(xs=[])`——默认值只在定义时创建一次，调用间共享同一列表。地道写法 `xs=None` 然后内部判空。这是 Python 面试与真实事故的双料常客。

### 4.2 Jupyter 工作流：可执行的笔记本

**结论先行**：notebook = Markdown 单元（讲人话和 LaTeX）+ 代码单元（跑数学）+ 输出内嵌，正是第0章笔记体系「概念卡片/例题/代码实验」三件套的单文件融合体。

组织规范（本课程约定）：一个主题一个 `.ipynb`；单元自上而下按「结论 → 实验 → 观察」排列；每个 markdown 单元开头的 `$…$` 公式会被直接渲染（Obsidian 同理——两处编辑器的公式方言一致）。常用 magic：

```
%matplotlib inline     # 图直接画在单元下方
%run script.py         # 运行外部脚本并继承命名空间
%time expr             # 单次计时; %timeit 多次取最优(§4.4 性能解剖用)
!cmd                   # 穿透到 shell, 如 !git status
```

快捷键三板斧：`Esc+A/B` 上下插单元、`Shift+Enter` 执行、`Esc+M/Y` 切 Markdown/代码。**乱序执行是 notebook 的头号暗坑**：单元编号跳着跑过，变量状态就和阅读顺序不一致——交作业前必做 `Kernel ▸ Restart & Run All`，一键从头绿到尾才算真通过。

### 4.3 NumPy I：ndarray 与形状世界观

**结论先行**：`ndarray` 是**同质数字的多维方块**，一切围绕两个属性转：`shape`（形状，各维长度元组）与 `dtype`（元素类型）。第3章说「向量是有序数组、矩阵是数表」，NumPy 给它加了工业条款：**同维同质、连续内存**——所以快。

```python
import numpy as np
a = np.array([1., 2., 3.])          # shape (3,)  —— 注意: 一维数组既非行也非列!
M = np.array([[1., 2.], [3., 4.]])  # shape (2, 2)
X = np.zeros((5, 3))                # 批量样本惯用形状: (样本数, 特征数)
```

**逐元素运算**（数学叫 Hadamard 积，和第1章「向量加法逐分量」一脉相承）：`a + b`、`a * b`、`a ** 2`、`1 / a` 全是对应位置各干各的——**矩阵乘法才需要专属符号 `@`**（`M @ N`，旧代码里的 `np.dot/np.matmul` 同义）。新手第一案：`*` 不是矩阵乘。

**归约 axis**：第1章 $\sum$ 上岗。`arr.sum()` 全体加；`axis=0` 沿**行方向压扁**（每列各自求和，结果吃掉第 0 轴），`axis=1` 每行各自求和。记忆钩子：**axis 指哪根轴，哪根轴就被消灭**。配套武器库：`mean`、`max/min`、`argmax`（softmax 后取预测类别全靠它）、`std`（第5章经验方差一步到位）。

```python
scores = np.random.default_rng(7).standard_normal((4, 10))  # 4 个样本 × 10 类打分
pred = scores.argmax(axis=1)                                # 每行挑最大类的编号
```

**切片与视图**：`M[1:, 0]`（第2行起第0列）、`M.T`（转置，第3章行列互换）、`M.reshape(4, 1)`（改形状不改数据，元素总数必须吻合——接口匹配纪律再现）、`M.ravel()`（展平，第0章图像 784 维化的那一步）。**切片默认是视图**（共享内存，改切片=改原件）：想要副本显式 `.copy()`——省内存的设计，也是连环污染 bug 的来源。

**线性代数全家桶** `np.linalg`：`det`、`inv`、`solve(A, b)`（解 $Ax=b$，比 `inv(A) @ b` 稳且快——数值分析的小偏心，知道即可）、`eig/eigh`（第3章练习已偷用过）、`svd`。你的 `mini-linalg` 从此有了正规军对照本。

> ⚠️ 常见误区：`(3,)` 一维数组与 `(3,1)` 列向量不是一回事！前者参与运算时会按需广播（下一节），后者是正经二维。形状报错十有八九源于此混淆——养成随手 `.shape` 打印的习惯。

### 4.4 NumPy II：广播与向量化——第3章分块的兑现

**结论先行**：**广播（broadcasting）**让形状不同的数组也能逐元素运算。规则只有两行，从右往左逐轴比对：① 轴的个数不够就在前面补 1；② 每一轴要么相等、要么其中一方为 1（为 1 的那方被「复印」拉伸）。

```python
col = np.array([[1.], [2.], [3.]])   # (3,1)
row = np.array([10., 20.])           # (2,) → 视作 (1,2)
col + row                            # (3,1)+(1,2) → 双方拉伸成 (3,2) 外积式相加
```

这与第3章 §4.6 分块矩阵「切口对齐则块照常运算」是同一件事的计算化身：`Z = X @ W.T + b` 一行完成 batch 仿射——`X@W.T` 形状 `(m,n)@(n,k)→(m,k)`（第3章接口匹配律原样执行），`b` 形状 `(k,)` 自动补成 `(1,k)` 再沿 m 轴复印 m 份——**每一行样本都加上同一个偏置向量**。GPU 每天数的万亿次浮点，就是这个模式的无限重复。

**向量化思维 = 把 for 循环改写为「整块数组上的表达式」**。三段进化史（练习 2 逐段计时）：

```python
s = 0.0
for x in xs: s += x*x              # ① 数学系直译: 对, 但慢
s = sum(x*x for x in xs)           # ② Python 惯用法: 略快, 仍是解释器逐个派发
s = np.dot(xs, xs)                 # ③ 向量化: C 编译循环+SIMD, 常快百倍到千倍
```

快的本质：Python 每次循环都在做类型检查装箱拆箱；NumPy 把「同质数字、连续内存」谈妥后，一次性交给编译好的机器码流水线。**代价**：中间结果可能整块复制占内存，超大数组要分块处理（batch size 的工程权衡，第7章续谈）。（→ mini-batch 实测已在第8章讲义 §4.2 实验3 完成，文件 chapters/08-7-ai.md。）

**性能解剖仪式**（写进肌肉记忆）：`%timeit` 三连——纯循环 / 生成器式 / 向量化，亲眼量出数量级差距；再用 `np.allclose(慢版结果, 快版结果)` 证明「快而等价」。这就是本章方法论的心脏。

> ⚠️ 常见误区：广播静默成功 ≠ 语义正确。`(m,1)` 与 `(m,)` 相加会得到 `(m,m)` 而不是你以为的逐元素 `(m,)`——第二轴补 1 对齐后互相复印。凡运算结果形状意外变胖，第一时间回查这两支的形状。

### 4.5 matplotlib：把前五章结论画出来

**结论先行**：API 认两套就够用——面向对象式 `fig, ax = plt.subplots()`（本课程主用，多图画布好管理）与状态机式 `plt.plot()`（快速草稿）。四张模板覆盖前文所有图形需求：

| 图型 | 最小咒语 | 回收的前章结论 |
|---|---|---|
| 函数曲线 | `ax.plot(x, np.sin(x))` | 第2章画廊全部家族 |
| 散点 | `ax.scatter(X[:,0], X[:,1], c=y)` | 第5章两团高斯、分类边界 |
| 等高线 | `ax.contourf(X1, X2, Z, levels=40)` | 第4章下山轨迹底图 |
| 直方图 | `ax.hist(samples, bins=30, density=True)` | 第5章 CLT 贴合理论密度 |

网格坐标三件套是所有曲面图的入口：

```python
x1 = np.linspace(-2, 2, 200); x2 = np.linspace(-2, 2, 200)
G1, G2 = np.meshgrid(x1, x2)          # 两支 (200,200), 铺出坐标网
Z = G1**2 + 2*G2**2                    # 广播逐元素求值——§4.4 技能实战
```

标注纪律：每图必有标题、轴标签、图例；数学文字用 mathtext——`ax.set_title(r'$f(x,y)=x^2+2y^2$')`（`r''` 原始字符串防反斜杠被吃），讲义里的 LaTeX 功夫在此无缝复用。

> ⚠️ 常见误区：`density=True` 的直方图纵轴是**密度**不是频数——柱面积总和为 1，才能和 PDF 曲线同框比较（第5章「概率是面积」的图形化再教育）。bins 数影响观感极大，同一批数据换个 bins 就像换了张脸。

### 4.6 SciPy 巡礼与调试习惯：认识别人写好的数学

**结论先行**：SciPy = 前人把你学过的数学全部工业级实现的合集。巡礼两站，顺便立三条数值家规。

**station 1 — `scipy.optimize`**：`minimize(fun, x0, jac=grad, method='BFGS')` 一行求解第4章的无约束优化。它是专业版的你：内置拟牛顿法（用 Hessian 近似加速，第4章 §4.6 的亲戚）、线搜索（自动调步长）。**巡礼的意义不是弃用手写**，而是校准：你的 GD 与它的 BFGS 收敛到同一个谷底 = 双方互为人质；分歧 = 至少一方有 bug。给 `jac` 递上解析梯度还能顺手验证第4章导数没推错（`check_grad` 更专职此事）。

**station 2 — `scipy.stats`**：`norm.pdf/rvs/fit` 一条龙——画第5章任意密度、抽任意分布的样本、反过来喂样本估参数（MLE 官方代打，`fit` 结果应与你手推的 $\hat\mu,\hat{\sigma^2}$ 吻合）。`sklearn.metrics.log_loss` 则是交叉熵的裁判官（练习 2 第三场对拍主角）。**边界意识**：库替你扛了数值稳定性（log-sum-exp 之类），但你必须懂原理才能判断它何时失灵、参数怎么设——这正是前六章存在的理由。

**三条数值家规**（散落在第2、4、5章的教训正式收编）：

1. **固定随机种子**：`rng = np.random.default_rng(seed)` 一切实验可复现；比较算法优劣时用同一批数据的配对设计（第5章 §4.7 假设检验的同源思想）；
2. **容差比较**：`np.allclose(a, b, rtol=1e-9)` 替代 `==`；中心差商的 $h$ 存在甜蜜点（太大截断误差、太小舍入误差——第4章练习 1 已见过 $10^{-8}$ 反而变差）；
3. **哨兵检查**：训练前先跑 `np.isfinite(loss).all()`；NaN 传染一切，事后追查不如事前拦截。

**单元测试简单用法**：pytest 三步曲——测试函数以 `test_` 开头、断言用 `assert`、命令行 `python -m pytest test_math.py -v`。把前五章的恒等式写成测试集（$\cos^2+\sin^2=1$、$\det(AB)=\det A\det B$、BCE 梯度公式……），从此每条数学结论都有自动化哨兵（练习 3 交付）。

> ⚠️ 常见误区：`random.gauss` 与 `rng.normal` 两套随机系统并存（旧 API 与新 Generator）。新代码统一走 `default_rng`——种子语义清晰，跨版本可复现。

---

## ⑤ 动手练习（基于统一工程 ai-prep，分支 chapter/06-python）

全部文件只进 `06-python/`，严禁另起炉灶。开工（§2.1 已给出）：

```powershell
cd C:\Users\pyg12\.dsh\study-work\goal-mu99mtaf-ai\ai-prep
conda activate aiprep
git checkout -b chapter/06-python chapter/05-done
pip install -r requirements.txt
```

**练习 1 · 纯 Python 热身（§4.1，仓库已备骨架）**
打开预置 `06-python/warmup.py`，实现四个函数：`gauss_sum`（第2章等差求和 + assert 公式自检）、`geo_sum`（等比求和，$r=1$ 特判——第2章 off-by-one 警告的工程版）、`compose(*funcs)`（第1章复合的流水线版，`functools.reduce` 或倒序 for 皆可）、`inverse_map`（第1章反函数单射检验的 dict 实现，冲突抛 `ValueError`）。运行 `python warmup.py` 打印 5050 即过关。

**练习 2 · 三场对拍（§4.3–4.6 主产出，仓库已备骨架）**
打开预置 `06-python/math-in-code.ipynb`：第一场「手写矩阵乘 vs `@`」已写好完整示例（含 `allclose` 断言与 `%timeit` 计时）。按 TODO 完成：第二场——把 `04-calculus/gradient_lab.py` 的手写 GD 与 `scipy.optimize.minimize(method='BFGS', jac=...)` 在 Rosenbrock 上对拍，报告最终坐标差异与评估次数对比；第三场——把 `05-probability/logistic-playground.ipynb` 的手写 BCE 与 `sklearn.metrics.log_loss` 对拍（容差 $10^{-9}$），并额外构造 `z=[1000, 1001, 1002]` 分别用朴素 softmax CE 与 log-sum-exp 版（第2章练习 2 的你写的 `logsumexp` 请搬来复用）算一遍，记录谁先 NaN。附加 TODO：广播三小题（外积、batch 仿射一行式、故意制造形状错误并把你读到的报错信息原文贴在 markdown 单元里）。

**练习 3 · 恒等式测试集（§4.6，仓库已备骨架）**
打开预置 `06-python/test_math.py`，第一条 `test_log_product_rule` 已写好范例；按 TODO 补四条（三角恒等式、行列式乘法律、BCE 梯度 vs 中心差商、softmax 平移不变性），每条 docstring 注明出处章节。运行 `python -m pytest test_math.py -v` 五绿通关。**这条命令以后就是你所有数学代码的验收门**。

**练习 4 · 图形检阅（§4.5）**
新建 `06-python/gallery-redux.ipynb`，用 matplotlib 面向对象式重绘四件旧作并全部换成 NumPy 计算：(a) 第2章 $3\cos(2x)+1$ 与 $\ln(2-x)$（对照当年手绘草图，自评贴合度）；(b) 第4章 GD 下山轨迹等高线图（数据取自练习 2 第二场的轨迹数组，体验「循环 append 列表 → 一次 reshape 成 (steps,2)」的姿势转换）；(c) 第5章骰子均值直方图叠 `scipy.stats.norm.pdf` 理论曲线（`density=True` 的家规勿忘）；(d) meshgrid + `contourf` 画 $f(x,y)=\sin x\cos y$ 的等高线。每图配一句 mathtext 标题。

**练习 5 · 章末验证点 + 台账更新（本章验收点）**
**(a) 验证点**：白板挑战——不看任何资料，把下面这条第5章损失写成 NumPy 一行式并用随机数据验证与循环版 `allclose`：

$$\widehat{\mathrm{CE}}=-\frac1m\sum_{i=1}^{m}\sum_{k=1}^{K} y^{(i)}_k\log \hat y^{(i)}_k,\qquad Y\in\{0,1\}^{m\times K}\ \text{one-hot}$$

提示路线：`(Y * np.log(Y_hat + 1e-12)).sum(axis=1).mean()` 级别的一行式。**通过标准：形状推理口述正确（哪里触发广播、axis 消灭了哪根轴）+ 两版结果一致**。
**(b) 台账**：`00-map/gap-list.md` F 组错题重读后在 `06-python/drills.md` 自编 2 题解答；`00-map/blackbox-ledger.md` 把「NumPy 向量化/广播机制」行改 ✅，登记新挂账：反向传播记账与端到端项目（第7章）；`00-map/math-to-ai-map.md` 的「NumPy 广播」行追加 ✅。

**收章三连**：

```powershell
git add 06-python 00-map requirements.txt
git commit -m "feat(06): python and numpy deliverables"
git checkout main; git merge --no-ff chapter/06-python -m "merge: chapter/06-python done"; git tag chapter/06-done
```

---

## ⑥ 本章小结（回收总览）

回到 §1.2 三层栈 + 对拍机，逐条验收：

1. **语言层（§4.1）**：容器/控制流/函数/模块四件套全部锚定在第1–3章的数学对象上（推导式=描述法、dict=映射、product=笛卡尔积）；浮点是 $\mathbb{R}$ 的有损采样（`0.1+0.2≠0.3`）；虚拟环境 + 锁定版 `requirements.txt` 是可复现性的配方单。
2. **工作流（§4.2）**：notebook 三件套合流第0章笔记体系；magic 四连；交作业前 Restart & Run All 治乱序暗坑。
3. **数组层（§4.3）**：ndarray 的 `shape/dtype` 世界观；逐元素运算 vs `@` 矩阵乘的分野；`axis` 归约 = $\sum$ 的方向盘（指哪灭哪）；切片是视图、改形靠 reshape（元素守恒）；`np.linalg` 让 mini-linalg 转正。
4. **广播与向量化（§4.4）**：两行规则（补 1 对齐、相等或其一为 1）；`Z=X@W.T+b` 一行兑现第3章分块与 batch 承诺；三段进化（循环→生成器→向量化）+ `%timeit`/`allclose` 的「快而等价」仪式；形状变胖是广播最常见的静默事故。
5. **可视化（§4.5）**：四张模板回收第2/4/5章全部图形结论；meshgrid 三件套 + 广播求值；mathtext 让 LaTeX 功夫无缝迁移；`density=True` 的直方图才是 PDF 的正确同框姿势。
6. **生态与家规（§4.6）**：`optimize.minimize` 与 `stats.distributions` 是「别人写好的数学」的巡礼站兼裁判席；三条数值家规（种子/容差/哨兵）收编前三章散落教训；pytest 把五条恒等式变成自动化哨兵。
7. **台账结账（§2.2）**：五项前账全清（$\sum$↔向量化、分块↔广播、步长精度种子专题、requirements 锁定、clip/log-sum-exp 实测）；新挂账反向传播记账移交第7章。

**下一章预告**：第7章「综合实战与 AI 课程衔接」——工具层就位，四层地基全员到齐：你将**不用任何框架**，从正规方程与梯度下降两条路实现线性回归、从 BCE 手推到逻辑回归训练全程，给「一张图看懂一次训练」签上自己的名字，然后拿着缺口自查清单走进正式 AI 课程。开工命令：`git checkout -b chapter/07-capstone chapter/06-done`。
