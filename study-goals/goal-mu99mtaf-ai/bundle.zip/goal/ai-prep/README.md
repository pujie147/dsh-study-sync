# ai-prep — AI 预科统一工程

全课程唯一练习仓库。主分支 `main` = 全课程基线，**禁止直接在 main 上开发**。

## 目录骨架

| 目录 | 对应章节 |
|---|---|
| `00-map/` | 第0章 · 全景地图与自我定位（思维导图、摸底卷、gap-list） |
| `01-language/` | 第1章 · 数学的语言：集合、符号与函数思维 |
| `02-functions/` | 第2章 · 关键函数家族与变化直觉 |
| `03-linalg/` | 第3章 · 线性代数 |
| `04-calculus/` | 第4章 · 微积分与最优化 |
| `05-probability/` | 第5章 · 概率、统计与信息论 |
| `06-python/` | 第6章 · Python 与 NumPy |
| `07-capstone/` | 第7章 · 综合实战与 AI 课程衔接 |

## 分支约定（每章统一遵循）

1. 从上一章的合并点开本章分支：`git checkout -b chapter/NN-主题`
2. 本章所有文件只加在本章目录内
3. 章末验证通过后合并回 main：`git checkout main && git merge --no-ff chapter/NN-主题`
4. 打完合并 tag：`git tag chapter/NN-done`，作为下一章的 checkout 起点

## Hello World 冒烟测试

```powershell
python .\hello.py   # 预期输出: hello, ai-prep
jupyter lab         # 浏览器打开后新建 notebook，运行 print("ok")
```
