﻿"""warmup.py: 纯 Python 热身（第6章练习1）。
全部素材来自前五章已学数学——这次让解释器当你的草稿纸。
"""


def gauss_sum(n):
    """返回 sum_{i=1}^n i, 用 for 循环。对照公式 n(n+1)/2 自检 assert。"""
    raise NotImplementedError


def geo_sum(a1, r, n):
    """等比求和 a1*r^0 + ... + a1*r^(n-1), 循环累加。r=1 时直接返回 n*a1。"""
    raise NotImplementedError


def compose(*funcs):
    """compose(f,g,h)(x) = h(g(f(x))) —— 第1章复合的流水线版。提示: reversed() + functools.reduce 或 for。"""
    raise NotImplementedError


def inverse_map(pairs):
    """pairs=[(1,'a'),(2,'b')] → {'a':1,'b':2}; 若反转后键冲突抛 ValueError(单射检验, 第1章反函数)。"""
    raise NotImplementedError


if __name__ == "__main__":
    print("gauss_sum(100) =", gauss_sum(100))
