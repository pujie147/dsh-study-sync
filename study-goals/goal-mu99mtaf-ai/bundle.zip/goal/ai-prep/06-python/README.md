﻿# 第6章 · Python 与 NumPy 练习目录

- `math-in-code.ipynb`: 三场对拍 + 广播实验(练习2), 运行: jupyter lab math-in-code.ipynb
- `test_math.py`: pytest 测试文件(练习3), 运行: python -m pytest test_math.py -v
- `warmup.py`: 纯 Python 热身脚本(练习1), 运行: python warmup.py
