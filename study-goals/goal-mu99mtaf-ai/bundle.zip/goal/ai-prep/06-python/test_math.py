﻿"""test_math.py: pytest 单元测试（第6章练习3）。
要求: 每个测试只验一条已学恒等式, 断言消息里写清出处小节。
运行: python -m pytest test_math.py -v
"""
import math
import numpy as np
import pytest


def test_log_product_rule():
    """第2章 §4.3: log(uv)=log u+log v。"""
    u, v = 3.7, 11.2
    assert math.log(u * v) == pytest.approx(math.log(u) + math.log(v), rel=1e-12)


# TODO 补四个测试:
# test_cos_sin_identity      第2章 §4.1 cos²+sin²=1, 随机角度 100 个全过
# test_det_multiplicative    第3章 §4.4 det(AB)=detA·detB, 3x3 随机阵
# test_grad_bce_formula      第5章 §4.8 结论 dL/dw=(p-y)x 对比中心差商
# test_softmax_shift_invar   第5章 §4.3 softmax(z+c)=softmax(z)
