﻿# 第5章 · 概率统计与信息论 练习目录

- `monte-carlo.py`: 大数定律/CLT/高斯MLE/贝叶斯实验(练习1-3), 运行: python monte-carlo.py
- `logistic-playground.ipynb`: 玩具二分类器(练习4), 运行: jupyter lab logistic-playground.ipynb
