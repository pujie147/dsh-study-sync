﻿"""monte-carlo.py: 蒙特卡洛实验台（第5章练习骨架, 讲义 §5）。
只用标准库 random/math + 前四章数学; NumPy 仅作对拍裁判(第6章正式学)。
"""
import random
import math


# ---- 练习1.a: 大数定律——掷硬币频率收敛 (§4.6) ----
def coin_convergence(n_trials=10_000, seed=7):
    """返回 (heads_list, err_list): 逐次正面频率与它对 p=0.5 的偏差。
    提示: random.random() < 0.5 记一次正面; 累计计数用 running sum。"""
    raise NotImplementedError


# ---- 练习1.b: 中心极限定理——骰子均值直方图 (§4.6) ----
def dice_means(n_dice_per_sample=30, n_samples=1000, seed=7):
    """每次掷 n_dice_per_sample 颗骰子取平均, 重复 n_samples 次, 返回均值列表。
    观察: 分布形状像什么?(对照 §4.3 高斯密度公式画一条理论曲线叠上去)"""
    raise NotImplementedError


# ---- 练习2: 一维高斯的 MLE (§4.5) ----
def gauss_mle(samples):
    """由 §4.5 推导结果直接实现: mu_hat=样本均值, sigma2_hat=样本二阶中心矩(分母 n 不是 n-1!)。
    输入: 实数列表; 输出: (mu_hat, sigma2_hat) 元组。"""
    raise NotImplementedError


# ---- 练习3: 贝叶斯疾病检测 (§4.2 全概率+贝叶斯) ----
def bayes_disease(prevalence=0.01, sensitivity=0.99, false_positive=0.05):
    """返回 P(患病|阳性)。用 §4.2 公式:
    P(pos) = sens*prev + fp_rate*(1-prev);  P(d|pos)= sens*prev / P(pos)。"""
    raise NotImplementedError


if __name__ == "__main__":
    print("coin:", "TODO")
    try:
        print("P(病|阳) =", bayes_disease())
    except NotImplementedError:
        print("[TODO] 从练习3或1.a开始逐个填空")
