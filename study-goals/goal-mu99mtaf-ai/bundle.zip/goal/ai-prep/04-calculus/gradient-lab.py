﻿"""gradient-lab: 手写梯度下降实验台（第4章练习骨架, 讲义 §5）。
本文件只用第1-4章数学 + 基础 Python; NumPy 仅作裁判(第6章才正式学)。
待实现函数按讲义小节顺序填空。
"""
import math


# ---- 练习1.a: 数值微分 (§4.1 差商直觉, 第0章 first-dual-track 的推广) ----
def num_deriv(f, x, h=1e-5):
    """中心差商 (f(x+h)-f(x-h))/(2h)。返回 f 在 x 处导数的近似。"""
    raise NotImplementedError


# ---- 练习1.b: 解析导数对拍表 (§4.2 求导法则) ----
def d_poly(x):
    """f(x)=x^3-4x+7 的解析导数。"""
    raise NotImplementedError


def d_exp(x):
    """f(x)=exp(2x) 的解析导数(链式法则!)。"""
    raise NotImplementedError


# ---- 练习1.c: 一元梯度下降 (§4.7) ----
def gd_1d(fprime, x0, eta, steps):
    """x_{t+1} = x_t - eta * f'(x_t); 返回轨迹列表 [x0, x1, ...]。"""
    raise NotImplementedError


# ---- 练习2: 二元函数与梯度 (§4.5) ----
FUNCS = {
    "parabola":   {"f": lambda x, y: x*x + 2*y*y,
                   "grad": None},          # TODO: 填解析梯度 (fx, fy)
    "rosenbrock": {"f": lambda x, y: (1-x)**2 + 100*(y-x*x)**2,
                   "grad": None},          # TODO: fx=-2(1-x)-400x(y-x^2), fy=200(y-x^2) —— 自己推一遍再对照!
}


def grad_num(f, xy, h=1e-5):
    """数值偏导对拍器: 用 num_deriv 分别沿 x、y 方向差分。"""
    fx = num_deriv(lambda t: f(t, xy[1]), xy[0], h)
    fy = num_deriv(lambda t: f(xy[0], t), xy[1], h)
    return (fx, fy)


# ---- 练习2c: 动量法 (§4.5/§4.7, 第2章递推数列的 AI 化身) ----
def gd_momentum(fgrad, x0, eta, mu=0.9, steps=200):
    """v_{t+1} = mu*v_t + grad(x_t);  x_{t+1} = x_t - eta*v_{t+1}。返回轨迹。"""
    raise NotImplementedError


if __name__ == "__main__":
    print("num_deriv(x^2, 3) =", num_deriv(lambda x: x*x, 3.0), "(理论值 6)")
