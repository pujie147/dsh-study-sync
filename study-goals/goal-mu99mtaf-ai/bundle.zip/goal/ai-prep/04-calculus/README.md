﻿# 第4章 · 微积分与最优化 练习目录

- `gradient-lab.py`: 手写数值微分/梯度/梯度下降(练习1-3), 运行: python gradient-lab.py
- `descent-lab.ipynb`: 等高线下山可视化(练习2/3/选做), 运行: jupyter lab descent-lab.ipynb
