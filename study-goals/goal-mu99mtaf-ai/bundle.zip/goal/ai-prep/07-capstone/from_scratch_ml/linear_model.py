"""linear_model.py: from-scratch 线性回归双解法（第7章练习1骨架）。
约定: X 形状 (m,n), y 形状 (m,)。禁止 import sklearn; 允许 numpy。
每个方法 docstring 标注所用预科知识点与章节出处——这是毕业项目的第一纪律。
"""
import numpy as np


def add_bias(X):
    """左侧补一列全1, 把截距 b 并入权重向量. 返回 (m, n+1).
    [TODO 练习1a] 提示: np.ones + np.hstack, 或先 copy 再切片赋值(视图家规!)."""
    raise NotImplementedError


def fit_normal_equation(X, y):
    """闭式解 theta* = (X^T X)^-1 X^T y —— 第3章§4.7 正规方程(投影几何版).
    用 np.linalg.solve 而非显式求逆(第6章§4.3 稳定性小偏心).
    [TODO 练习1a]"""
    raise NotImplementedError


def fit_gd(X, y, eta=0.1, steps=2000):
    """梯度下降解 min ||y - X theta||^2 / m.
    梯度 = (2/m) X^T (X theta - y) —— 第4章§4.5 多元链式法则的习题答案在此兑现.
    返回 (theta, loss_curve), loss_curve 记录每步 MSE 供画图.
    [TODO 练习1b] 前置实验: 不标准化直接跑, 观察锯齿; 再 zscore 后重跑对比."""
    raise NotImplementedError


def predict(X, theta):
    """X @ theta —— 第3章『一层网络就是一次矩阵乘』的最小实例. [TODO 练习1a]"""
    raise NotImplementedError
