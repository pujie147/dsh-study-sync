"""metrics.py: 评估指标（第7章练习2骨架）。全部向量化写法, 附循环版对拍测试。"""
import numpy as np


def mse(y_true, y_pred):
    """MSE = mean((y-yhat)^2) —— 第1章逐词听写过的老朋友. [TODO 练习2]"""
    raise NotImplementedError


def softmax(z, axis=1):
    """softmax(z)_k = e^{z_k}/sum_j e^{z_j}, 必须走 log-sum-exp 稳定化路线
    (先减 max). —— 第5章§4.3 定义 + 第6章练习2 NaN 实测的教训固化. [TODO 练习3]"""
    raise NotImplementedError


def cross_entropy(y_true, y_prob):
    """CE = -mean_i sum_k y_ik log p_ik, y_true 为 one-hot.
    —— 第5章§4.8 '一条损失三重名字' 的最终实现. [TODO 练习3]"""
    raise NotImplementedError


def accuracy(y_true_label, y_prob):
    """argmax(p) == y_true 的比例. 第6章§4.3 argmax 上岗. [TODO 练习3]"""
    raise NotImplementedError
