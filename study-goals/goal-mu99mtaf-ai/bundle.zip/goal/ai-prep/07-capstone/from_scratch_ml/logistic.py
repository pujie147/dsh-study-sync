"""logistic.py: 交叉熵+GD 逻辑回归（第7章练习3骨架）。多类版: W 形状 (n+1, K)。"""
import numpy as np


def forward(Xb, W):
    """前向: logits = Xb @ W; probs = softmax(logits).
    —— 第1章函数复合 + 第3章仿射层 + 第5章 softmax 三合一. [TODO 练习3]"""
    raise NotImplementedError


def grads(Xb, probs, Y_onehot):
    """手推结论: dL/dW = (1/m) Xb^T (probs - Y). 一行矩阵式背后是整条链式法则.
    [TODO 练习3] 先在纸上重推一遍再写码(本章验证点素材)."""
    raise NotImplementedError


def train(Xb, Y_onehot, eta=0.5, steps=1000, l2=0.0):
    """GD 循环 + 可选 L2 惩罚(高斯先验/MAP 的工程开关, 第5章§4.6).
    返回 (W, curve). [TODO 练习3]"""
    raise NotImplementedError
