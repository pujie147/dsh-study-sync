﻿# 第7章 · 综合实战（capstone）

微型库 `from_scratch_ml/`: linear_model.py(双解法) · logistic.py(CE+GD) · metrics.py(评估)。
数据: `python make_data.py` 生成 housing.csv 与 blob3.npz。
验收: `python -m pytest test_capstone.py -v` 全绿 + report.md 评审通过。

## 全课程知识 → AI 技术栈 最终映射图

```mermaid
flowchart LR
    subgraph PREP["预科四层地基 + 工具层"]
        L1["语言层<br/>集合·符号·函数复合"]
        L2["数据几何层<br/>向量·矩阵·投影·特征值"]
        L3["变化最优层<br/>导数·梯度·凸性·拉格朗日"]
        L4["不确定层<br/>概率·MLE·正则·交叉熵"]
        T["工具层<br/>NumPy·广播·matplotlib"]
    end
    subgraph ML["正式 AI 技术栈"]
        LR["线性·逻辑回归<br/>本章已从零通关"]
        NN["神经网络·反向传播<br/>= 链式法则记账"]
        CNN["视觉 CNN<br/>= 卷积上的 GD"]
        TF["Transformer·LLM<br/>= attention 点积 + CE 自回归"]
        GEN["生成模型<br/>= 贝叶斯 + 采样"]
        RL["强化学习<br/>= 递推 + 期望回报"]
    end
    L1 --> NN --> TF
    L2 --> CNN --> TF
    L2 --> TF
    L3 --> NN
    L3 --> RL
    L4 --> TF
    L4 --> GEN
    L4 --> RL
    T --> LR
```

一句话读图: 你在本章亲手跑通的最左节点, 是右边每一根梁的共同祖先。
