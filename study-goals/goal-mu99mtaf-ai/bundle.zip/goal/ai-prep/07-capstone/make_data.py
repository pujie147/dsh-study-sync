"""make_data.py: 生成毕业项目数据集（已写好, 直接运行）。
housing.csv : 单特征回归合成集(真实隐私友好替代波士顿房价), 含噪声项.
digits_small.npz : sklearn 手写数字子集(0/1/2 三类, 各200张 8x8), 仅作一次性裁判对照.
"""
import numpy as np

rng = np.random.default_rng(2026)

# --- 回归集: y = 3.2 x1 - 1.5 x2 + 4 + N(0, 0.5^2), 故意让两特征尺度差 100 倍 ---
m = 400
x1 = rng.normal(0, 1, m)
x2 = rng.normal(0, 100, m)          # 未标准化 → GD 锯齿现形
y = 3.2 * x1 - 1.5 * (x2 / 100) + 4 + rng.normal(0, 0.5, m)
X = np.column_stack([x1, x2])
np.savetxt("data/housing.csv", np.column_stack([X, y]), delimiter=",", header="x1,x2,y", comments="")

# --- 分类集: 三类高斯 blob, 二维可画 ---
centers = np.array([[0., 0.], [4., 3.], [-2., 5.]])
pts, labels = [], []
for k, c in enumerate(centers):
    pts.append(c + rng.normal(0, 1.1, (150, 2)))
    labels += [k] * 150
Xc = np.vstack(pts); yc = np.array(labels)
perm = rng.permutation(len(yc))
np.savez("data/blob3.npz", X=Xc[perm], y=yc[perm])
print("saved: data/housing.csv, data/blob3.npz")
