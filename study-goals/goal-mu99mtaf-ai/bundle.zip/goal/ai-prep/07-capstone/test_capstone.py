"""test_capstone.py: 毕业验收测试（讲义 §5 练习 5 填完实现后应全绿）。
运行: python -m pytest test_capstone.py -v   （在 07-capstone/ 目录下）
"""
import numpy as np
import pytest

from from_scratch_ml import linear_model as lm
from from_scratch_ml import metrics as mt


def rng_z(seed=7):
    return np.random.default_rng(seed).standard_normal((4, 6))


def test_add_bias_shape():
    X = np.ones((5, 3))
    assert lm.add_bias(X).shape == (5, 4)
    assert np.allclose(lm.add_bias(X)[:, 0], 1.0)


def test_normal_vs_gd_agree():
    """两条路收敛到同一解: 第3章几何 vs 第4章迭代的人质互保。"""
    rng = np.random.default_rng(7)
    X = rng.standard_normal((60, 2)); y = X @ np.array([2., -1.]) + 0.3
    Xb = lm.add_bias(X)
    th_n = lm.fit_normal_equation(Xb, y)
    th_g, curve = lm.fit_gd(Xb, y, eta=0.5, steps=3000)
    assert np.allclose(th_n, th_g, atol=1e-2)
    assert curve[-1] < curve[0]


def test_softmax_rows_sum_to_one():
    p = mt.softmax(rng_z())
    assert np.allclose(p.sum(axis=1), 1.0)
    assert (p > 0).all()


def test_softmax_shift_invariance_stable():
    """大数不移位: 朴素版会 NaN, 稳定版幸存——第6章对拍的教训固化成哨兵。"""
    z = np.array([[1000., 1001., 1002.]])
    p = mt.softmax(z)
    assert np.isfinite(p).all()


def test_ce_matches_manual():
    y = np.array([[1., 0.]]); p = np.array([[0.7, 0.3]])
    assert mt.cross_entropy(y, p) == pytest.approx(-np.log(0.7), rel=1e-9)
