﻿# 第2章练习 · 函数图像画廊（骨架）

- 运行: jupyter lab family-gallery.ipynb（先 pip install ipywidgets 以启用交互滑杆）
- 按讲义 §5 练习 1~3 填写 TODO 单元; log-vs-exp.ipynb 为练习 2 的对照实验。
