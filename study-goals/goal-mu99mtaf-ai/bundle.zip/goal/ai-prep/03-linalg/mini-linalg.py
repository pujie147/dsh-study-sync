﻿"""mini-linalg: 纯 Python 矩阵类（第3章练习1骨架）。
只允许使用第1、2章已学的语法与数学; NumPy 仅作对拍裁判(第6章才正式学)。
待实现方法均抛出 NotImplementedError, 按讲义 §4 各节逐步填空。
"""
import math


class Mat:
    """m x n 矩阵, rows 为嵌套列表 [[...],[...]]。"""

    def __init__(self, rows):
        self.rows = [list(r) for r in rows]
        self.m = len(self.rows)                      # 行数
        self.n = len(self.rows[0])                   # 列数
        if any(len(r) != self.n for r in self.rows):
            raise ValueError("行长度不一致: 不是合法矩阵")

    # ---- 练习1.a: 加法与数乘 (§4.1 逐元素运算) ----
    def __add__(self, other):
        raise NotImplementedError

    def scale(self, c):
        raise NotImplementedError

    # ---- 练习1.b: 转置 (§4.2) ----
    def T(self):
        raise NotImplementedError

    # ---- 练习1.c: 矩阵乘向量, 再推广到矩阵乘矩阵 (§4.2/§4.6) ----
    def vecmul(self, v):
        """v 是长度 n 的列表; 返回长度 m 的列表. 第 i 行与 v 的点积(点积公式见 §4.5)."""
        raise NotImplementedError

    def __matmul__(self, other):
        raise NotImplementedError

    # ---- 练习1.d: 单位阵与逆(仅2x2, 用 §4.4 行列式+伴随公式) ----
    @staticmethod
    def eye(k):
        raise NotImplementedError

    def inv2(self):
        """2x2 求逆: A^-1 = 1/det * [[d,-b],[-c,a]]; det=0 时抛 ValueError(不可逆)."""
        raise NotImplementedError

    # ---- 练习1.e:  Frobenius 范数 sqrt(sum a_ij^2), 对照 §4.5 范数定义 ----
    def norm_f(self):
        raise NotImplementedError


def dot(u, v):
    """点积: sum_i u_i*v_i, 用内置 sum + zip (第1章 §4.4 的 ∑↔for 直译)."""
    return sum(a * b for a, b in zip(u, v))


if __name__ == "__main__":
    A = Mat([[1, 2], [3, 4]])
    print("A =", A.rows)
    try:
        print("A@A =", A.__matmul__(A).rows)
    except NotImplementedError:
        print("[TODO] 尚未实现, 从练习1.a 开始逐个填空")
