﻿# 第3章 · 线性代数 练习目录

- `mini-linalg.py`: 纯 Python 矩阵类(练习1), 运行: python mini-linalg.py
- `transform-lab.ipynb`: 可视化实验(练习2/3/选做), 运行: jupyter lab transform-lab.ipynb
