# 第0章 零基础地基：Python、HTTP API 与开发环境

## ② 本章概览（总）

### 本章在全课程框架中的位置与作用

全课程的「总」是一张图：**应用六层技术栈**（L1 模型 → L2 编排 → L3 记忆 → L4 工具 → L5 护栏 → L6 可观测）＋ **三条横切支撑带**（数据与知识带、评测带、治理与集成带）＋ 最上面的**业务带**。

本章不碰这张图里的任何一层。它是这张图的**画布和笔**——Python 语言、HTTP 接口调用、Git 版本管理这三样工具能力。理由很直接：后面每一层的排查动作，最终都归结为三件事——**读日志、改代码、发版本**。这三项不过关，第3章之后的所有内容都会退化成"照着抄一段能跑的代码，但改不动也坏不起"。

```mermaid
flowchart TB
    subgraph BIZ["业务带 · 第2章"]
        direction LR
        SC["场景选型与价值评估"]
    end
    subgraph STACK["应用六层技术栈 · 第3至8章"]
        L6["L6 可观测层 · 第7章"]
        L5["L5 护栏层 · 第6章"]
        L4["L4 工具层 · 第5章"]
        L3["L3 记忆层 · 第4章"]
        L2["L2 编排层 · 第5章"]
        L1["L1 模型层 · 第3章"]
        L6 --- L5 --- L4 --- L3 --- L2 --- L1
    end
    subgraph BANDS["三条支撑带"]
        direction LR
        D1["数据与知识带 · 第4章"]
        D2["评测带 · 第6章"]
        D3["治理与集成带 · 第8章"]
    end
    subgraph FOUND["本章 · 动手地基"]
        direction LR
        P["Python 读写能力"]
        H["HTTP 与 JSON 心智模型"]
        G["Git 分支与合并点纪律"]
    end
    BIZ --> STACK
    STACK --- BANDS
    STACK ==> FOUND
    FOUND -.没有这三样 上层全部变成抄作业.-> BIZ
```

一句话说明：本章产出的三项能力是全课程唯一的硬前置，所有上层内容都建立在这块地基上。

### 分节地图

| 节 | 内容 | 对应核心知识点 |
|---|---|---|
| 4.1 | Python 最小够用集 | 变量/列表/字典、函数、条件循环、异常、模块与包 |
| 4.2 | 环境与依赖：虚拟环境 | venv 或 uv |
| 4.3 | HTTP 与 API 心智模型 | 请求/响应、状态码、JSON 序列化与反序列化 |
| 4.4 | 命令行、文件与环境变量 | cd/ls/mkdir、路径、读写文本、`.env` 管密钥 |
| 4.5 | Git 基本功与"分支—合并点"主线 | init/add/commit/branch/checkout/merge/push/pull、`.gitignore` |
| 4.6 | 读报错的能力 | Traceback 从下往上读、三类错误区分、如何搜索 |
| 4.7 | API Key 的安全习惯 | 绝不写进代码与提交历史，只从环境变量读取 |

---

## ③ 承接与补完

### 前置清偿

本章是全课程第一章，无前置讲义需要阅读；反向地，本章要为后续九章**预先埋好欠账标记**：

| 本章"作黑盒使用"的概念 | 在后续哪一章详述 |
|---|---|
| "调用一个大模型对话接口拿回一段文字"——本章只把它当作一个普通的 HTTP 接口来调，完全不解释它内部是什么、参数怎么选、为什么会胡说 | 第3章（模型层与提示词工程） |
| "Embedding、向量检索、知识库" | 第4章（RAG）**→ 已在第4章讲清**：见第4章 4.4 Embedding 与向量检索、4.5 进阶检索、4.7 权限与数据治理 |
| Agent、工具调用、工作流 | 第5章（编排层与工具层）**→ 已在第5章讲清**：见第5章 4.1 控制回路、4.2 Function calling、4.3 MCP、4.8 HITL |
| 评测集、黄金集、CI 门禁 | 第6章（评测带与护栏层）**→ 已在第6章讲清**：见第6章 4.2 黄金集、4.3 指标体系、4.5 CI 门禁、4.6–4.8 护栏与注入攻防与红队 |
| 容器化部署、可观测平台 | 第7章（部署与运维）**→ 已在第7章讲清**：见第7章 4.2 容器与部署、4.4 可观测性与轨迹双写、4.5 成本治理 |
| OAuth 授权、企业身份体系 IdP | 第8章（治理与集成）**→ 已在第8章讲清**：见第8章 4.2 身份与授权、4.3 密钥管理、4.5 网关限流、4.7 合规地图 |

本章对它们的唯一要求是：**你的环境能发出一次 HTTPS 请求并解析返回的 JSON**。仅此而已。

### 统一工程接力与本章分支动线

本章是全课程唯一在 `main` 上直接建立初始基线的一章（因为还没有基线可言）。从第1章起，一律禁止直接在 `main` 上开发。

```mermaid
flowchart LR
    A["装工具链"] --> B["git init 建仓库 ai-landing-course"]
    B --> C["搭目录骨架 src data docs scripts"]
    C --> D["写 .env 与 .gitignore"]
    D --> E["跑通 scripts/hello_api.py"]
    E --> F{"验证点通过?"}
    F -- 否 --> E
    F -- 是 --> G["打 tag baseline-ch00 作为全课程基线合并点"]
```

一句话说明：本章终点是一个打了 `baseline-ch00` 标签的可运行仓库，后续每一章都从这个合并点切出分支。

**本章具体动线**：

1. 在本地新建目录并初始化仓库：`git init`，确认默认分支名为 `main`。
2. 直接在 `main` 上完成本章全部内容（唯一例外），每次有效进展就 `commit`。
3. 章末验证点通过后打标签：`git tag baseline-ch00`。
4. **不做** `push` 到远端也可以继续本课程，但建议尽早推到私有远端备份。

---

## ④ 正文分节

### 4.1 Python 最小够用集

**结论先行**：本课程不需要你成为 Python 专家。你需要的是"能读懂别人的代码、能改、能加一层判断"。这只需要五个东西：容器、函数、控制流、异常、模块。

#### 4.1.1 变量与两种核心容器：列表与字典

Python 里名字（变量）指向一个对象。真正贯穿全课程的是两个容器：

```python
# 列表 list：有序、可重复、按位置取。用来装"一批同类的东西"
models = ["deepseek-chat", "gpt-a-mini", "claude-x"]
print(models[0])        # deepseek-chat
print(len(models))      # 3

# 字典 dict：键值对。用来描述"一个东西的多个属性"
request = {
    "model": "deepseek-chat",
    "temperature": 0.2,
    "messages": [{"role": "user", "content": "你好"}],
}
print(request["model"])          # deepseek-chat
print(request.get("timeout"))    # None —— get 不存在时返回 None，不炸
```

**为什么这两个够了**：几乎所有 AI 接口的请求体都是一个字典（里面套着列表，列表里又套字典），返回值也是同样结构。你能看懂嵌套字典，就能看懂 90% 的 API 文档。

**常见误区**：把 `request["missing"]` 写成访问不存在键——会抛 `KeyError`。用 `.get("key", 默认值)` 更稳。这个区别在第4章解析检索结果时会救你一命。

#### 4.1.2 函数：把重复动作收成一个名词

```python
def call_llm(prompt: str, temperature: float = 0.2) -> str:
    """给一个提示词，返回模型的回答文本。"""
    ...
    return answer
```

三个要点：

- **默认参数**让调用方可简可繁（`temperature` 不传就用 0.2）。后面章节里"模型配置"几乎全靠这个机制传递。
- **类型标注** `prompt: str` 不影响运行，纯粹给人和编辑器看。养成写的习惯。
- **docstring** 是函数自带说明书。团队协作时这是最低成本的沟通。

#### 4.1.3 条件与循环

```python
for msg in request["messages"]:
    role = msg["role"]
    if role == "user":
        print(f"用户: {msg['content']}")     # f-string：本课程最常用的字符串拼接方式
    elif role == "assistant":
        print(f"助手: {msg['content']}")
    else:
        print(f"[{role}] {msg['content']}")
```

注意 f-string 里外层的引号要错开（外双内单）。第3章拼提示词模板时天天用。

#### 4.1.4 异常处理 try-except：本章最重要的工程习惯

```python
import time

def call_with_retry(fn, max_retries=3):
    for attempt in range(max_retries):
        try:
            return fn()
        except TimeoutError:                       # 只抓你预期的错
            wait = 2 ** attempt                    # 指数退避：1s, 2s, 4s
            print(f"超时，第 {attempt + 1} 次失败，等 {wait}s 后重试")
            time.sleep(wait)
    raise RuntimeError("重试次数耗尽")
```

三条纪律：

1. **不要裸写 `except:`**——它会连"你代码里打错变量名"这种 bug 一起吞掉，导致线上完全查不到原因。至少写 `except Exception as e:` 并把 `e` 记进日志。
2. **抓具体的异常类型**：网络问题抓连接/超时类异常，数据问题抓 `KeyError`/`json.JSONDecodeError`。
3. **重试必须配退避与上限**。这条在第5章会变成硬性要求——不设上限的重试就是"跑飞 Agent"事故的雏形。

#### 4.1.5 模块与包：`import` 到底在干什么

```python
import os                      # 导入整个模块，用时写 os.environ
from pathlib import Path       # 只导入其中的名字，直接用 Path
from dotenv import load_dotenv # 第三方库同理
```

一个目录里有 `__init__.py` 就成了**包**（package），可以被 `import`。本课程统一工程的 `src/` 就是一个包，第3章起会在里面长出一堆子模块。

### 4.2 环境与依赖：虚拟环境

**结论先行**：每个项目一套独立的 Python 环境，永远不要往系统全局 Python 里装包。

为什么这条对企业级落地至关重要：AI 生态的库版本冲突极其频繁（不同向量库、不同框架要求的依赖版本互相打架）。混在一个全局环境里，做到第5章你就会遇到"装了 A 就不能用 B"的死局，而这时你无法分辨是代码错了还是环境坏了。

```powershell
# 方案一：标准库自带，无需额外安装
python -m venv .venv
.\.venv\Scripts\Activate.ps1        # Windows PowerShell 激活
# source .venv/bin/activate         # macOS / Linux

# 方案二：uv，更快，本课程同样推荐
uv venv
uv pip install requests python-dotenv
```

配套两件事：

- 把 `.venv/` 写进 `.gitignore`（见 4.5）。**环境本身绝不进仓库**。
- 维护 `requirements.txt` 或 `pyproject.toml` 记录依赖及版本。换一台机器靠它复现环境——这就是第7章 Dockerfile 的前身。

```text
requests==2.32.3
python-dotenv==1.0.1
```

### 4.3 HTTP 与 API 心智模型

**结论先行**：调大模型 = 发一个 HTTP POST 请求，请求体是一段 JSON，服务器回一段 JSON。没有任何魔法。理解了这一句，本章就够了。

#### 4.3.1 一次请求的四要素

```mermaid
sequenceDiagram
    participant C as "客户端 你的脚本"
    participant S as "服务端 模型API"
    C->>S: "POST /v1/chat/completions 带 URL 方法 头 体"
    Note over C,S: "四要素 地址 方法 头部 请求体"
    S-->>C: "200 OK 响应头 响应体JSON"
    C->>C: "解析JSON 取出回答文本"
```

一句话说明：一次 API 调用无非是把四样东西发出去、把回来的 JSON 拆开。

| 要素 | 是什么 | 实例 |
|---|---|---|
| URL | 地址：协议+域名+路径 | `https://api.example.com/v1/chat/completions` |
| Method | 动作意图 | `GET` 取东西、`POST` 提交并处理 |
| Headers | 元信息 | `Authorization: Bearer <KEY>`、`Content-Type: application/json` |
| Body | 真正的数据 | 上面那个 `request` 字典 |

#### 4.3.2 状态码：先分类再读细节

| 区间 | 含义 | 你该怎么反应 |
|---|---|---|
| `2xx` | 成功 | 解析响应体 |
| `401` / `403` | 没带钥匙 / 有钥匙但没权限 | 检查 API Key、检查该 Key 能否用这个模型。**不是代码逻辑错** |
| `404` | 地址不存在 | 检查 URL 拼写与路径版本 |
| `429` | 请求太频繁或被限流 | 退避重试（见 4.1.4）。第7章会把它做成正式策略 |
| `4xx` 其他 | 你给的数据不对 | 逐字段核对请求体 |
| `5xx` | 对方服务器故障 | 重试或降级；这不是你的 bug |

**常见误区**：只看"有没有返回内容"，不看状态码。结果是 `401` 时你也拿到了一段 JSON（里面写着错误信息），程序却把它当正常回答往下传，最后表现为莫名其妙的空答案。正确做法：

```python
resp = requests.post(url, headers=headers, json=payload, timeout=30)
if resp.status_code != 200:
    raise RuntimeError(f"API 调用失败 status={resp.status_code} body={resp.text[:300]}")
data = resp.json()
```

#### 4.3.3 JSON：序列化与反序列化

JSON 是文本格式，Python 里是对象，两者之间需要转换：

| 方向 | 术语 | Python 函数 |
|---|---|---|
| 对象 → 文本 | 序列化 / 编码 | `json.dumps(obj)`（写文件）、`f.write()` |
| 文本 → 对象 | 反序列化 / 解码 | `json.loads(text)` |

`requests` 帮你省了这一步：`json=payload` 自动序列化，`resp.json()` 自动反序列化。

注意差异：JSON 的 `null` ↔ Python 的 `None`，`true/false` ↔ `True/False`。手写测试数据时常踩。

#### 4.3.4 第一次真实调用

```python
# scripts/hello_api.py —— 全课程的最小起点
import os
from pathlib import Path
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / ".env")   # 见 4.4.3

BASE_URL = os.environ["LLM_BASE_URL"]                        # 缺失就直接报错，好排查
API_KEY  = os.environ["LLM_API_KEY"]

payload = {
    "model": "REPLACE_WITH_A_REAL_MODEL_ID",                  # 版本号锁定的意义见第3章
    "messages": [{"role": "user", "content": "用一句话解释什么是 API"}],
    "temperature": 0.2,
}

resp = requests.post(
    f"{BASE_URL}/chat/completions",
    headers={"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"},
    json=payload,
    timeout=30,                                              # 永远设超时，永不省略
)
resp.raise_for_status()                                      # 非 2xx 直接抛异常
answer = resp.json()["choices"][0]["message"]["content"]
print(answer)
```

这段代码里 `temperature`、`choices`、`messages` 的含义**本章全部不解释**——它们是 L1 模型层的内容，第3章详述。本章只要求你把它当成"某个接口的某个字段"来看待并完成传输。

> 🔧 **欠账清偿记录**（后续章节回填）
> - 「大模型接口内部是什么、为什么会胡说」→ **已在第1章讲清**：见第1章 4.1 本质与三大先天缺陷、4.2 五个直观概念（token／上下文窗口／温度与采样／推理模型 vs 快模型／无状态）。
> - 「这些字段在整体架构中归谁管」→ **已在第1章讲清**：见第1章 4.3.1 L1 模型层。
> - 「具体怎么选模型、怎么调参、怎么写提示词」→ **已在第3章讲清**：见第3章 4.3 选型矩阵与版本锁定、4.4 提示词工程、4.5 关键参数。

### 4.4 命令行、文件与环境变量

#### 4.4.1 最少命令集

| 目的 | PowerShell (Windows) | bash (macOS/Linux) |
|---|---|---|
| 当前位置 | `Get-Location` / `pwd` | `pwd` |
| 列目录 | `Get-ChildItem` / `ls` | `ls -la` |
| 进入目录 | `cd 路径` | `cd 路径` |
| 新建目录 | `New-Item -ItemType Directory 名字` | `mkdir -p 名字` |
| 看文件内容 | `Get-Content 文件名` | `cat 文件名` |

#### 4.4.2 路径概念与 `pathlib`

两类路径必须分清：**绝对路径**从盘符或根开始（`C:\Users\you\proj\.env`），**相对路径**从当前工作目录开始（`./data/a.txt`）。同一份代码在不同目录下运行，相对路径的结果会不一样——这是新手最常见的"在我机器上能跑"来源。

```python
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]     # 锚定到项目根，不受运行时所在目录影响
env_path = ROOT / ".env"                        # 用 / 拼路径，跨平台安全
env_path.read_text(encoding="utf-8")            # 读；务必显式指定 utf-8
(ROOT / "data").mkdir(parents=True, exist_ok=True)   # 建目录，幂等
```

**中文乱码的头号原因**是没写 `encoding="utf-8"`。Windows 默认编码不是 UTF-8，从第4章读企业文档开始这会反复出现，现在就把习惯立起来。

#### 4.4.3 环境变量与 `.env`

**环境变量**是操作系统层面的"键值对袋子"，进程启动时继承。程序从中取值，而不是从代码里取。

`.env` 文件是为了让你能在本地方便地填这些变量：

```dotenv
# .env —— 放在项目根目录，永不提交
LLM_BASE_URL=https://api.example.com/v1
LLM_API_KEY=sk-xxxxxxxxxxxxxxxx
```

```python
from dotenv import load_dotenv
load_dotenv()                 # 把 .env 里的键值注入环境变量
import os
key = os.environ.get("LLM_API_KEY")
if not key:
    raise SystemExit("缺少 LLM_API_KEY，请复制 .env.example 为 .env 并填写")
```

同时提供一份 `.env.example`（只有键名、值为占位符），**这个文件要提交**——它是给别人看的说明书，不含真密钥。

### 4.5 Git 基本功与"分支—合并点"主线

**结论先行**：Git 的核心不是命令，是一句话——**改动先关在分支里验证，通过了才并进主干**。本课程九个章节全部按这条纪律推进。

#### 4.5.1 三个区与基本流转

```mermaid
flowchart LR
    W["工作区 你正在编辑的文件"] -->|"git add"| S["暂存区 准备提交的清单"]
    S -->|"git commit"| R["本地仓库 已归档的历史"]
    R -->|"git push"| O["远端仓库 备份与协作"]
    O -->|"git clone / git pull"| W
```

一句话说明：`add` 是点名，`commit` 是盖章存档，`push` 是寄出备份。

#### 4.5.2 命令速查

```bash
git init -b main                      # 建仓并指定主分支名
git status                            # 现在什么状态（用得最多，随时看）
git add .                             # 暂存全部改动
git commit -m "chore: 建立工程骨架"    # 提交，写清楚做了什么
git log --oneline --graph             # 看图说话：历史长什么样
git branch chapter/01-overview        # 建分支
git switch chapter/01-overview        # 切过去（旧写法 git checkout 分支名 亦可）
git switch -c chapter/02-scenario     # 建并切换，一步到位
git switch main                       # 回到主干
git merge chapter/01-overview         # 在 main 上把分支并进来
git remote add origin <URL> ; git push -u origin main
```

提交信息建议用 `feat:` / `fix:` / `docs:` / `chore:` 前缀。第6章 CI 门禁会依赖清晰的提交历史。

#### 4.5.3 本课程的主线：分支—合并点

这是全课程统一的工程纪律，请务必照做：

```mermaid
gitGraph
    commit tag: "baseline-ch00"
    branch chapter/01-overview
    checkout chapter/01-overview
    commit
    commit
    checkout main
    merge chapter/01-overview tag: "merge-ch01"
    branch chapter/02-scenario
    checkout chapter/02-scenario
    commit
    checkout main
    merge chapter/02-scenario tag: "merge-ch02"
```

规则四条：

1. `main` 是全课程基线，**任何一章都不允许直接在 `main` 上开发**（仅本章建立初始基线时例外）。
2. 每章开始时，从**上一章的合并点**切出分支：`git switch -c chapter/NN-主题`。
3. 章末验证点通过后，切回 `main` 执行 `git merge`，形成新的合并点 `merge-chNN`。
4. 下一章从新合并点继续。这样任何一章写崩了，都能干净回退到上一章的状态。

**为什么这么设计**：本课程每章都在同一个工程上做增量。没有这条纪律，你在第5章把 Agent 改坏了，会把第4章已经跑通的 RAG 一起毁掉，且无法恢复。有了合并点，回退只是一条命令。

#### 4.5.4 `.gitignore`

```gitignore
# 环境与密钥
.venv/
.env
*.local

# Python 产物
__pycache__/
*.pyc
.pytest_cache/

# 编辑器与系统
.vscode/
.DS_Store

# 数据与日志（按需保留样例数据）
data/raw/
logs/
*.log
```

**危险提醒**：`.env` 必须在**第一次 commit 之前**就写进 `.gitignore`。一旦真密钥被提交过，即使后面删掉文件，它仍留在历史里，等于永久泄漏（补救办法见 4.7 之后的小结练习）。

### 4.6 读报错的能力

**结论先行**：报错不是失败，是系统在告诉你精确位置。会读报错的人修 bug 用三分钟，不会的人重启电脑碰运气。

#### 4.6.1 Traceback 从下往上读

```text
Traceback (most recent call last):
  File "scripts/hello_api.py", line 24, in <module>
    answer = resp.json()["choices"][0]["message"]["content"]
  File ".../requests/models.py", line 976, in json
    return complexjson.loads(self.text, **kwargs)
json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)
```

阅读顺序：

1. **最后一行**＝错误类型与原因。这里是"想解析 JSON，但内容开头就不是合法 JSON"。
2. **往上找自己写的那一行**（`hello_api.py line 24`）。库里的那些帧只是调用路径。
3. 定位因果：返回的不是 JSON——很可能是网关返回了一段 HTML 错误页，或者状态码是 204 空响应。

**关键技巧**：报错位置往往不是错误根源。这里真正的问题是 4.3.2 说的"没检查状态码"。

#### 4.6.2 三类错误的判别法

| 类别 | 典型表现 | 何时暴露 | 怎么修 |
|---|---|---|---|
| 语法错误 `SyntaxError` | `invalid syntax`、括号引号不配对 | 程序还没跑起来就报 | 对照报错行的**上一行**常更有效（漏了右括号时报错指向后面） |
| 运行时错误 | `NameError`、`KeyError`、`TypeError`、`IndexError` | 跑到某一行才炸 | 打印那一行的变量实际值和类型 |
| 网络/外部错误 | `ConnectionError`、`Timeout`、`SSLError`、HTTP 4xx/5xx | 只在联网时发生 | 先看状态码归类（4.3.2），再判断是鉴权、限流还是对方故障 |

调试的基本动作只有一个：在可疑处把变量的值和类型打出来。

```python
print(type(data), data.keys() if isinstance(data, dict) else data[:200])
```

#### 4.6.3 如何搜索报错

三步：

1. 去掉个性化部分（路径、变量名、数字），只留**错误类型与原始英文短语**，如 `"JSONDecodeError" "Expecting value"`。
2. 加上下文限定词：库名＋版本，如 `requests JSONDecodeError status_code 200 empty`。
3. 优先看官方文档与 issue 区，其次看问答社区；**注意答案的日期**——AI 生态半年前的解法今天可能已失效。

### 4.7 API Key 的安全习惯

**结论先行**：密钥一旦进入代码或提交历史，就必须假定它已经泄露并立即作废重发。没有"应该没事"这种情况。

四条铁律：

1. **只从环境变量读**，代码里永不出现明文密钥（见 4.4.3）。
2. **`.env` 进 `.gitignore`**，且在首次提交前完成。
3. **提交前自查**：`git diff --cached` 看一眼暂存了什么。或用工具扫描。
4. **误提交后的正确处置**：立刻在服务商后台**吊销并重新生成**密钥（这是首要动作，先于一切清理），然后再考虑清洗历史。仅仅删除文件、重新提交是无效的——历史里还在。

**为什么企业级特别强调这点**：第8章会讲到，Agent 若能读到长期静态凭证，等于把任何一次提示注入事件的爆炸半径永久放大。个人项目的后果是账单，企业项目的后果是安全事故通报。

---

## ⑤ 动手练习（基于统一工程增量开发）

以下练习全部在 `ai-landing-course` 这一个仓库里完成，**严禁另起炉灶新建无关项目**。

### 练习 1：建立基线仓库（约 30 分钟）

1. 新建目录 `ai-landing-course`，`git init -b main`。
2. 建目录骨架：`src/`、`data/`、`docs/`、`scripts/`，各放一个 `.gitkeep` 或 README。
3. 写 `.gitignore`（含 `.venv/` 与 `.env`）。
4. 创建虚拟环境并安装 `requests`、`python-dotenv`，生成 `requirements.txt`。
5. 提交：`chore: 建立工程骨架与环境基线`。

### 练习 2：跑通最小 API 调用（约 40 分钟）

1. 写 `.env` 与 `.env.example`。
2. 实现 `scripts/hello_api.py`（参照 4.3.4），要求：显式超时、`raise_for_status()`、失败时打印状态码与响应前 300 字符。
3. 运行成功，把返回的一句话存进 `data/hello.txt`（用 `encoding="utf-8"`）。

### 练习 3：加固成可复用函数（约 60 分钟）★本章验收重点

把 4.3.4 的脚本升级成 `src/client.py`，供后续所有章节复用：

```python
def chat(prompt: str, model: str | None = None, temperature: float = 0.2) -> str: ...
```

必须实现的要求：

- 从环境变量读取 base_url 与 api_key，缺失时给出**明确可读**的错误提示（不许是裸 `KeyError`）。
- 带指数退避的重试，**最多 3 次**，只对超时与 429/5xx 重试，对 401/403/404 **立即失败不重试**。
- 返回前校验响应结构，缺字段时抛出包含原始响应片段的异常。

### 练习 4：亲手制造并读懂四类错误（约 30 分钟）

依次故意制造下列情况，把报错原文和你的判读结论写进 `docs/errors-log.md`：

| 编号 | 制造方法 | 你应该观察到 |
|---|---|---|
| E1 语法错误 | 删掉一个右括号 | 程序根本没发出请求 |
| E2 运行时错误 | 把 `["choices"]` 改成 `["choice"]` | `KeyError` |
| E3 鉴权错误 | 把密钥改错一位 | 401，且不触发重试 |
| E4 网络错误 | 把 base_url 域名改成一个不存在的名字 | 连接类异常 |

这个练习的价值在于：以后遇到同类报错，你能在十秒内判断它属于哪一类。

### 练习 5：密钥泄漏演练（约 20 分钟）

1. 故意把假密钥（如 `sk-FAKE-123`）硬编码进一个临时文件并提交。
2. 用 `git log -p --all | Select-String "sk-FAKE"` 证明它确实留在历史里。
3. 删除文件、提交，再次搜索，观察它**依然存在**。
4. 得出结论并写进 `docs/security-note.md`：为什么"删掉再提交"不够，以及正确的两步处置是什么。

### 章末验证点（全部通过才可合并）

```mermaid
flowchart TD
    V1{"换一台机器或新克隆<br/>按 README 三步能拿到模型回复?"}
    V2{"断网运行时<br/>是否在合理时间内给出清晰错误而非无限卡死?"}
    V3{"仓库里搜不到任何真实密钥?<br/>grep 一遍 .env 的值确认"}
    V4{"git log 显示 main 上有完整基线<br/>且已打 tag baseline-ch00?"}
    V1 -->|是| V2
    V2 -->|是| V3
    V3 -->|是| V4
    V4 -->|是| DONE["打 tag baseline-ch00<br/>本章结束 下一章从此合并点切分支"]
```

README 必须写清那三步：建虚拟环境 → 复制 `.env.example` 为 `.env` 并填值 → 运行 `python scripts/hello_api.py`。

---

## ⑥ 本章小结

回收本章概览那张框架图：本章交付的是画布与笔，即三项地基能力，`baseline-ch00` 是全课程第一个合并点。逐条对应正文：

1. **Python 最小够用集**（4.1）：列表装同类集合、字典描述对象属性、嵌套字典就是 API 文档的样子；函数用默认参数传递配置；异常只抓预期类型、重试必带上限与退避；`import` 与包让 `src/` 成为后续所有模块的家。
2. **虚拟环境**（4.2）：一项目一环境，`.venv/` 不进仓库，依赖锁进 `requirements.txt`——这是为了让你在做到第5章时不被依赖冲突卡死，也是第7章容器化的前身。
3. **HTTP 与 API 心智模型**（4.3）：调模型＝URL＋方法＋头部＋JSON 请求体，换回一段 JSON；状态码先分类再行动，`401/403` 是钥匙问题不是代码问题；必须先检查状态码再解析响应体，否则错误会被当成正常回答往下传。
4. **命令行、文件与环境变量**（4.4）：用 `Path(__file__)` 锚定项目根避免"换目录就崩"；读写一律显式 `utf-8`；密钥走 `.env` ＋ `os.environ`，并留一份可提交的 `.env.example`。
5. **Git 与分支—合并点主线**（4.5）：工作区→暂存区→本地仓库→远端；本章是唯一在 `main` 上建立基线的例外，此后每章从上一章合并点切 `chapter/NN-主题`、章末验证后合并回 `main`，**禁止直接在主分支开发**；`.env` 必须在首次提交前就忽略。
6. **读报错**（4.6）：Traceback 从最后一行读类型、往上找自己那一行，且报错位置常非根源；语法/运行时/网络三类错误的判别表；搜索时剥离个性化内容只留错误类型与英文原语。
7. **API Key 安全**（4.7）：密钥入历史即视为泄露；正确处置是先吊销重发、再谈清理，光删文件重提交无效。

**遗留欠账声明**：本章出现的 `temperature`、`messages`、`choices`、模型版本号等一律未解释，属 L1 模型层内容——**第3章详述**。Embedding／向量库／Agent／评测／部署／OAuth 分别在第4、5、6、7、8章展开。

**下一章预告**：第1章不再增加任何动手能力，而是把本章开头那张"六层＋三带"的图彻底讲透——包括大模型到底为什么会一本正经地胡说，以及 Demo 和产品之间那六道差距分别落在哪一层。
