# 第4章 可执行文件格式与进程内存：PE 与 ELF

## ① 本章在全课程框架中的位置

五层链：**表示层 → 语言层 → 载体层 → 分析层 → 实战层**。前三章解决"看得懂字节和指令"，本章进入**载体层**：这些指令和数据被装在哪个集装箱里、操作系统怎么把它搬进内存跑起来。

不理解装载过程，你在调试器里就答不出两个致命问题：**「该从哪一行开始看」**（入口点在哪、TLS 回调会不会先跑）和**「这个地址为什么和文件里的偏移不一样」**（ImageBase、RVA、节对齐）。第1章留下的最后一个黑盒——`0x14000177b` 这种地址的每一部分从何而来——在本章彻底清偿。

本章还是**静态分析与脱壳两章的共同前置**：Ghidra 加载文件时做的第一件事就是解析节表并把 RVA 映射成它的内部地址；而第9章手动脱壳的全部难点（找 OEP、重建导入表、修重定位）都建立在本章的结构知识上。

```mermaid
flowchart LR
    A["第1至3章<br/>表示层与语言层<br/>会读字节会读指令"] --> B["第4章 载体层<br/>PE ELF 与进程内存<br/>本章"]
    B --> C["第5章 静态 Ghidra<br/>依赖节表与 RVA"]
    B --> D["第6章 动态 x64dbg<br/>依赖基址与模块视图"]
    B --> E["第9章 脱壳<br/>依赖 OEP 导入表 重定位"]
    style B fill:#e0ffe0
```

### 本章抽象框架

一个可执行文件回答四个问题，本章按这四问组织：

```mermaid
flowchart TD
    Q1["问题一 这是什么类型的文件<br/>魔数 位数 子系统"] --> M1["DOS头 MZ e_lfanew<br/>NT头 Signature FileHeader OptionalHeader"]
    Q2["问题二 代码数据放在哪<br/>分几块 各自权限"] --> M2["节表 Section Headers<br/>.text .data .rdata .bss .idata .reloc"]
    Q3["问题三 从哪开始执行<br/>以及需要谁"] --> M3["AddressOfEntryPoint 与数据目录<br/>导入表 导出表 TLS 异常表"]
    Q4["问题四 怎么变成内存里的进程<br/>地址对不上怎么办"] --> M4["两种对齐 SizeOfImage<br/>重定位与 ASLR"]
    M1 --> FULL["一张完整的二进制地图"]
    M2 --> FULL
    M3 --> FULL
    M4 --> FULL
    FULL --> USE["支撑第5到7章的所有操作"]
```

图的含义：前三个问题在**磁盘上的文件**里回答，第四个问题跨越磁盘与内存。本章最容易被忽略但最重要的是第四问——它解释了"同一个 exe 每次运行地址不同"这一现象，也是脱壳后必须修重定位的原因。

### 分节地图

| 节 | 内容 | 对应核心知识点 |
|---|---|---|
| 4.1 | PE 总体结构 | MZ 魔数 `0x5A4D`、`e_lfanew`、NT 头三段式 |
| 4.2 | 关键字段 | ImageBase、AddressOfEntryPoint、两种 Alignment、SizeOfImage、Subsystem、DllCharacteristics |
| 4.3 | 节的职责 | `.text` `.data` `.rdata` `.bss` `.idata` `.reloc` `.pdata` `.rsrc` |
| 4.4 | **RVA ↔ 文件偏移换算** | $offset = rva - VirtualAddress + PointerToRawData$ |
| 4.5 | 导入表 | IAT/ILT、延迟绑定、GetProcAddress 隐匿 |
| 4.6 | 三个隐藏入口边角 | 导出表与序号、TLS 回调、SEH |
| 4.7 | ELF 对照 | e_entry、PT_LOAD、`.got`/`.plt`、PIE 与非 PIE |
| 4.8 | 装载与地址随机化 | ASLR/DEP/NX、磁盘与内存地址不一致、重定位修复 |

---

## ② 承接与补完：统一工程接力与本章分支动线

### 承接

第3章合并后 `main` 处于 `v3-assembly`。本章起点：

```bash
cd re-lab
git checkout main
git checkout -b chapter/04-pe-elf
```

本章复用第1章的 `serial_x64.exe` 作为主要分析对象——**用自己的样本当靶子的好处是答案已知，可以自校验**。

### 本章分支动线与验证点

```mermaid
flowchart LR
    S1["main 的 v3-assembly<br/>checkout -b chapter/04-pe-elf"] --> S2["lab/pe/rva_calc.py<br/>RVA 双向换算工具"]
    S2 --> S3["lab/pe/pe_dump.py<br/>纯手工解析 PE 头与节表"]
    S3 --> S4["tools/check.ps1<br/>报告自家 exe 的 ASLR DEP 状态"]
    S4 --> S5["WSL 侧编一份等价 C<br/>readelf 输出贴进 notes/04-pe-vs-elf.md"]
    S5 --> S6{"章末验证点<br/>只用十六进制编辑器手工找到<br/>OEP 与 .text 的文件偏移"}
    S6 -->|"通过"| S7["合并回 main 打 v4-pe-elf"]
    S6 -->|"未通过"| S3
```

**禁止直接在 `main` 上开发。** 章末：

```bash
git add lab/pe tools/check.ps1 notes/04-pe-vs-elf.md
git commit -m "feat(ch04): manual PE parser, rva calculator, protection checker, PE vs ELF table"
git checkout main && git merge --no-ff chapter/04-pe-elf -m "merge ch04: PE/ELF and process memory"
git tag v4-pe-elf
```

### 清偿前置黑盒

| 出处 | 原标注 | 本章清偿位置 |
|---|---|---|
| 第1章 1.6.4 | 「`printf` 不在你的 exe 里，它是怎么被找到的 → 作黑盒使用，第4章」 | **4.5 导入表** |
| 第1章 1.6.4 | 「地址 `14000177b` 里的 `0x140000000` 是哪来的 → 第4章 ImageBase/RVA」 | **4.2 / 4.4** |
| 第1章 练习 4 | 「这两组数字之间是什么换算关系？」 | **4.4 公式 + 实测** |
| 第2章 2.2.4 | 「写到只读页当场崩溃，DEP → 作黑盒使用，第4章详述」 | **4.2.4 / 4.8.2** |
| 第2章 2.4.1 | 「字符串的地址与文件中位置的换算 → 作黑盒使用，第4章」 | **4.4** |
| 第3章 3.4.3 | 「MSVC 用 `.pdata`/`.xdata` 描述异常帧」 | **4.3.4** |

本章新留黑盒：**Ghidra 如何把这套结构可视化** → 第5章；**运行时在调试器里看模块基址** → 第6章；**脱壳后如何重建被破坏的导入表** → 第9章。

---

## ③ 正文

本章所有数字均来自本机对 `_probe/serial_x64.exe`（即第1章 `serial.c` 的产物）的真实解析，你可以完全复现。

### 4.1 PE 总体结构

**结论先行：PE 文件是"套了三层信封"的结构——DOS 头只是引路牌，真正的信息在 `e_lfanew` 指向的 NT 头里。**

#### 4.1.1 三层结构

```mermaid
flowchart TD
    D["MS-DOS 头 IMAGE_DOS_HEADER<br/>偏移 0 起 共 64 字节<br/>e_magic = 0x5A4D 即 MZ<br/>e_lfanew @ 0x3C 指向 NT 头"] -->|"e_lfanew = 0x80"| N["NT 头 IMAGE_NT_HEADERS @ 0x80"]
    N --> S["Signature 4 字节<br/>PE\0\0 = 0x00004550"]
    N --> F["FileHeader IMAGE_FILE_HEADER 20 字节<br/>Machine NumberOfSections TimeDateStamp<br/>SizeOfOptionalHeader Characteristics"]
    N --> O["OptionalHeader 240 字节 PE32+<br/>Magic AddressOfEntryPoint ImageBase<br/>两种 Alignment SizeOfImage Subsystem<br/>DllCharacteristics 数据目录表 x16"]
    O --> H["Section Headers 节表<br/>每项 40 字节 共 NumberOfSections 项"]
    H --> B["各节实际内容<br/>按 FileAlignment 排在文件里"]
```

图的关键信息：`e_lfanew` 是一个**跳板**。DOS 头存在的唯一历史理由是兼容 Windows 3.x 之前的系统（那时代码真的能跑，打印 "This program cannot be run in DOS mode."）。今天它只剩两个字段有用：`e_magic` 用来快速判断"这是个 exe"，`e_lfanew` 用来找到 NT 头。

#### 4.1.2 本机实测：手摸三层

对 `serial_x64.exe` 的真实解析结果：

```
file size         = 0xF349 (62281 字节)
e_magic           = MZ                      ← 偏移 0x00，两字节 0x5A 0x4D
e_lfanew          = 0x80                    ← 偏移 0x3C 处的 dword
PE signature      = "PE" + 两个 0            ← 位于 0x80
Machine           = 0x8664                  ← AMD64，即 64 位
NumberOfSections  = 18
SizeOfOptionalHdr = 0xF0 (240)              ← 说明是 PE32+
Magic             = 0x20B                   ← PE32+
```

三个 magic 必须记住：

| 名称 | 值 | 位置 | 含义 |
|---|---|---|---|
| `e_magic` | `0x5A4D` = `"MZ"` | 文件偏移 `0x00` | 是个 DOS/PE 可执行文件 |
| PE Signature | `0x00004550` = `"PE\0\0"` | `e_lfanew` 处 | 是真 PE（而非纯 DOS 程序） |
| Optional Magic | `0x10B` / `0x20B` | `e_lfanew+24` | `0x10B`=PE32(32位)，`0x20B`=PE32+(64位) |

⚠️ **小端陷阱在这里兑现**（第1章 1.4）：`e_magic` 的值是 `0x5A4D`，但文件里前两字节是 `4D 5A`（`'M' 'Z'`）——低字节在前。同理 PE Signature `0x00004550` 在文件里是 `50 45 00 00`（`'P' 'E' 0 0`）。如果你按 `5A 4D` 去搜反而搜不到 `0x5A4D`，就是这个原因。

#### 4.1.3 Machine 字段的常用值

第1章 1.6.3 让你记住 `0x14c` 与 `0x8664`，现在给出完整出处（它们在 FileHeader 偏移 +0 处）：

| 值 | 架构 | 常见场景 |
|---|---|---|
| `0x14c` | `IMAGE_FILE_MACHINE_I386` | 32 位 Windows |
| `0x8664` | `IMAGE_FILE_MACHINE_AMD64` | 64 位 Windows |
| `0x1c0` | ARM | 老 Windows CE |
| `0x1c2` / `0xAA64` | ARM Thumb / ARM64 | Windows on ARM、Android so |
| `0x266` / `0x200` / `0x80` | Itanium / Alpha / Intel MCS | 古董 |

**这条判据比任何工具都快**：读 `e_lfanew`，再往后 4 字节取 2 字节，就是架构。第9章识别"这个样本是不是我预期平台"用它。

### 4.2 关键字段

**结论先行：OptionalHeader 里有五个字段决定你对整个文件的理解方式。它们不是字典条目，而是互相咬合的一组约束。**

#### 4.2.1 本机实测数值

```
AddressOfEntryPoint = 0x105F
ImageBase           = 0x140000000
SectionAlignment    = 0x1000   (4096)
FileAlignment       = 0x200    (512)
SizeOfImage         = 0x16000  (90112)
SizeOfHeaders       = 0x600
Subsystem           = 3        (IMAGE_SUBSYSTEM_WINDOWS_CUI 控制台)
DllCharacteristics  = 0x0160   → NX_COMPAT | DYNAMIC_BASE
```

于是 **OEP 虚拟地址 = ImageBase + AddressOfEntryPoint = `0x140000000 + 0x105F` = `0x14000105F`**。

验证一下（objdump 真实输出）：

```asm
000000014000105f <mainCRTStartup>:
   14000105f:  push   rbp
   140001060:  mov    rbp,rsp
   140001063:  sub    rsp,0x30
```

**完美吻合。** 而且注意函数名是 `mainCRTStartup` 而不是 `main`——这是 CRT 的启动代码，它会做初始化（设置 stdio、调用全局构造函数、处理 `_configure_narrow_argv`），最后才 `call main`。第1章看到的 `<__tmainCRTStartup>` 正是这条链。

> **重要认知**：**入口点 ≠ main。** 程序真正的第一条指令是 CRT startup。这对逆向有两个直接影响：① 你从 OEP 往下走会先经过一大段你不关心的初始化代码，别在那里耗时间；② 有些样本（尤其加壳的）会把 OEP 改到壳的 stub 上，此时 OEP 连"CRT"都不是。

#### 4.2.2 ImageBase：那个 0x140000000 的来历

现在正式清偿第1章的黑盒。

$$\text{虚拟地址 (VA)} = \text{ImageBase} + \text{相对虚拟地址 (RVA)}$$

- **RVA**：相对于镜像被加载到内存之起始位置的偏移。它是 PE 内部**所有**引用（入口点、数据目录、跳转表、导入表）使用的坐标。
- **ImageBase**：链接器写死的"建议加载地址"。64 位 MSVC/GCC 惯例是 `0x140000000`，32 位惯例是 `0x400000`（这就是为什么无数教程里的地址长这样）。

于是第1章那条 `call 140001760 <check>` 的地址拆解为：

$$\underbrace{0x140000000}_{\text{ImageBase}} + \underbrace{0x1760}_{\text{RVA}} = 0x140001760$$

**为什么要有 ImageBase 这个概念？** 因为 CPU 执行时需要的是 VA，而文件里存的是 RVA（省空间且便于重定位）。链接器知道理想情况下镜像会被放到 ImageBase，但如果那里已被占用（见 4.8），系统会搬到别处并做修正。

#### 4.2.3 两种 Alignment：文件与内存的对齐粒度不同

这是本章最容易搞混也最关键的一对概念：

| 字段 | 本机值 | 作用于 | 为什么 |
|---|---|---|---|
| `SectionAlignment` | `0x1000` | **内存中**每节的起始地址对齐 | 匹配 CPU 页大小（4 KB），使每节能独立设权限 |
| `FileAlignment` | `0x200` | **文件中**每节的起始偏移对齐 | 匹配磁盘扇区（512 B），省空间 |

```mermaid
flowchart LR
    subgraph FILE["磁盘上的文件"]
        FH["headers<br/>0x000-0x5FF"] --> T1[".text<br/>Raw 0x600"] --> T2[".data<br/>Raw 0x2C00"] --> T3[".rdata<br/>Raw 0x2E00"]
    end
    subgraph MEM["内存中的镜像"]
        MH["headers<br/>VA 140000000-1400005FF"] --> M1[".text<br/>VA 140001000"] --> M2[".data<br/>VA 140004000"] --> M3[".rdata<br/>VA 140005000"]
    end
    FILE -.->|"装载器按节复制<br/>并按页对齐展开"| MEM
```

图的含义：同一份字节，在文件里挤在一起（512 对齐），在内存里被拉开到页边界（4096 对齐）。**这个间距差正是 4.4 那个换算公式存在的理由。**

本机节表实测（截取关键几节）：

```
Name      VA(RVA)    VirtSize   RawOffset  RawSize    Flags      perm
.text     0x00001000 0x00002520 0x000600   0x002600   0x60000020 XRW→ R+X
.data     0x00004000 0x000000D0 0x002C00   0x000200   0xC0000040 RW
.rdata    0x00005000 0x00006C8  0x002E00   0x000800   0x40000040 R
.bss      0x00009000 0x000001A0 0x000000   0x000000   0xC0000080 RW (无文件数据!)
.idata    0x0000A000 0x00000934 0x004000   0x000A00   0x40000040 R
.reloc    0x0000D000 0x00000060 0x005000   0x000200   0x42000040 R
.pdata    0x00007000 0x000002A0 0x003800   0x000400   0x40000040 R
.rsrc     0x0000C000 0x000002B0 0x004C00   0x000400   0x40000040 R
.tls      0x0000B000 0x00000010 0x004A00   0x000200   0xC0000040 RW
```

`Flags` 的位含义：`0x00000020`=CODE、`0x00000040`=INITIALIZED_DATA、`0x00000080`=UNINITIALIZED_DATA、`0x20000000`=EXECUTE、`0x40000000`=READ、`0x80000000`=WRITE。所以 `.text` 的 `0x60000020` = CODE|READ|EXECUTE，`.rdata` 的 `0x40000040` = INITIALIZED_DATA|READ（**不可写**——这就是第2章 2.2.4 那个"写到只读页当场崩"的权限来源）。

#### 4.2.4 SizeOfImage、SizeOfHeaders 与 DllCharacteristics

- **`SizeOfImage = 0x16000`**：镜像在内存里占的总字节数（从 ImageBase 算起）。装载器要按这个量预留虚拟内存空间。注意它远大于文件大小 `0xF349`——因为页对齐撑开了空隙。
- **`SizeOfHeaders = 0x600`**：DOS 头 + NT 头 + 节表一共占多少。这解释了为什么第一个节从文件偏移 `0x600` 开始。
- **`DllCharacteristics = 0x0160`**：安全标志位。本机解析出两个：

| 位 | 值 | 名称 | 作用 |
|---|---|---|---|
| bit 6 | `0x0040` | `DYNAMIC_BASE` | **ASLR**：镜像可被随机放置 |
| bit 8 | `0x0100` | `NX_COMPAT` | **DEP**：数据页不可执行 |
| bit 9 | `0x200` | ISOLATION | 隔离 |
| bit 10 | `0x400` | NO_SEH | 禁用 SEH（4.6.3 的话题） |
| bit 15 | `0x8000` | GUARD_CF | 控制流防护 CFG |

**这两个标志直接决定了后面章节的操作难度**：
- ASLR 开着 → 每次运行基址不同 → 你在调试器里看到的地址不能硬编码进脚本（第6章会讲怎么从模块窗口读实时基址）。
- DEP 开着 → 你不能往 `.data` 里塞 shellcode 再跳过去执行（漏洞利用方向，本课程不深入）。

`tools/check.ps1` 就是把上面这段逻辑做成一键脚本（练习 3）。

### 4.3 节的职责

**结论先行：节名只是约定俗成的标签，真正有强制意义的是权限标志位。但掌握惯例能让你一眼预判某类数据在哪。**

#### 4.3.1 六大常规节

| 节 | 装什么 | 典型权限 | 是否占文件 | 逆向时的用途 |
|---|---|---|---|---|
| `.text` | 机器指令 | R+X | ✓ | 所有逻辑都在这里；改行为就是改这里 |
| `.data` | 已初始化的全局/静态变量 | R+W | ✓ | 注册标志、配置、状态机变量 |
| `.rdata` | 常量、字符串字面量、**跳转表**、部分导入表 | R | ✓ | 找字符串入口；跳转表在这里 |
| `.bss` | 未初始化/零初值的全局静态 | R+W | **✗** | 大缓冲区常在此，文件里搜不到 |
| `.idata` | 导入表相关结构 | R | ✓ | 4.5 主角 |
| `.reloc` | 重定位表 | R | ✓ | 4.8.3 主角；ASLR 靠它工作 |

第2章 2.4.1 那张分区表在这里获得**文件层面的对应物**：源码级的 `.text/.data/.bss` 划分，编译链接后就落成这些节。特别地，第2章说"`.bss` 不占文件空间"——本机实测证实：`.bss` 的 `RawOffset=0, RawSize=0`，但 `VirtSize=0x1A0`。声明一个大数组不会让 exe 变大，就是这个机制。

#### 4.3.2 非常规节与它们的信号价值

| 节 | 出现意味着 |
|---|---|
| `.pdata` / `.xdata` | x64 异常展开信息（MSVC 必产，GCC 也可能有） |
| `.rsrc` | 图标、对话框、版本信息、manifest |
| `.tls` | 存在 TLS 回调（4.6.2！） |
| `.debug` / `.drectve` | 调试信息或链接器指令残留 |
| `UPX0` / `UPX1` / `.aspack` | **加壳！** 第9章 |
| 名字乱码或长度异常的节 | 手工改过、可能被脱壳工具处理过 |

本机样本里就有 `/4`、`/14`、`/29`… 这类怪名字。这不是损坏——MinGW 的 COFF 符号表用"**斜杠 + 十进制字符串表偏移**"表示超长节名（如 `/29` 意为"节名存在字符串表偏移 29 处"）。看到这种命名，第一反应应是"这是 GCC/COFF 的产物"，而不是"被改过"。

#### 4.3.3 节间空隙与填充

`.text` 的 `RawSize=0x2600` 而 `VirtSize=0x2520`：文件里多出的 `0xE0` 字节是**为满足 FileAlignment 而填的垃圾**（通常是 0）。反过来 `.data` 的 `VirtSize=0xD0` 小于 `RawSize=0x200`，也是同类现象。

**推论**：不要用 `RawSize` 推断节内容长度，要用 `VirtSize`；不要在 `VirtSize` 之外寻找有意义的数据。

#### 4.3.4 .pdata 与 x64 异常表（清偿第3章 3.4.3）

x64 Windows 取消了 32 位的链式 SEH，改用**基于表的异常处理**：`.pdata` 里每个 `RUNTIME_FUNCTION` 结构（12 字节）记录一个函数的 `[BeginAddress, EndAddress, UnwindInfoAddress]`。

```
.pdata 每项: BeginAddress(RVA) EndAddress(RVA) UnwindInfo(RVA → .xdata)
```

**逆向价值两条**：
1. **函数列表可以从 `.pdata` 直接拿到**，即使符号被剥离！每个 `BeginAddress` 就是一个函数入口。这是第7章"strip 后只剩 `sub_xxx`"应对手段之一，也是 Ghidra 自动划函数时会参考的信息。
2. 若样本没有 `.pdata` 却声称是 x64 Windows 程序，多半被人为删除或加了壳。

### 4.4 RVA ↔ 文件偏移换算

**结论先行：这是本章唯一必须刻进肌肉记忆的公式。查字符串、下补丁、定位跳转表，全靠它。**

#### 4.4.1 公式与推导

给定节表中某节 $S$（其字段记为 $S_{VA}, S_{VS}, S_{RA}, S_{RS}$）：

$$\boxed{\;offset = rva - S_{VA} + S_{RA}\;}$$

其中 $S$ 是满足 $S_{VA} \le rva < S_{VA} + \max(S_{VS}, S_{RS})$ 的那个节。

反向：

$$rva = offset - S_{RA} + S_{VA}$$

推导直觉：$rva - S_{VA}$ 是这个地址在**节内**的第几个字节；再加上节在文件里的起点 $S_{RA}$，就是文件偏移。

#### 4.4.2 本机三重实测验证

**例 1：找字符串 `"input: "`。** 第1章反汇编里 `lea rax,[rip+...] # 140005050`，故 RVA $= 0x140005050 - 0x140000000 = 0x5050$。它落在 `.rdata`（$S_{VA}=0x5000, S_{RA}=0x2E00$）：

$$offset = 0x5050 - 0x5000 + 0x2E00 = 0x2E50$$

实读文件 `0x2E50` 处：

```
rva=0x005050 -> sec=.rdata off=0x002E50 bytes=69 6E 70 75 74 3A 20 00 25 64 ascii=[input: .%d]
```

`69 6E 70 75 74 3A 20 00` 正是 `"input: "` 加终止符 ✓。紧跟着的 `25 64` 是 `"%d"`，印证 4.4.3。

**例 2：OEP。** RVA $= 0x105F$，落在 `.text`（$S_{VA}=0x1000, S_{RA}=0x600$）：

$$offset = 0x105F - 0x1000 + 0x600 = 0x65F$$

实读 `0x65F` 处字节：`55 48 89 E5 48 83 EC 30` —— 逐条对上 objdump 的 `push rbp`(`55`)、`mov rbp,rsp`(`48 89 E5`)、`sub rsp,0x30`(`48 83 EC 30`) ✓✓。

**例 3：`"ok"` 与 `"no"`。** RVA `0x505B` → offset `0x2E5B`，读到 `6F 6B 00 6E 6F 00` = `"ok\0no\0"` ✓。

#### 4.4.3 字符串在 .rdata 里是连续排布的

由例 3 可见，`"input: "`、`"%d"`、`"ok"`、`"no"` 被编译器打包放在相邻地址（`0x5050`–`0x505E`）。这是链接器的字符串合并优化。

**逆向价值**：当你找到一个提示字符串（比如 `"Correct!"`），它前后几乎必然还有别的字符串（`"Wrong!"`、`"Enter key:"`）。所以在 Ghidra/x64dbg 的字符串列表里，**按地址邻近聚类**往往能一次捞出一整套 UI 文案，帮你迅速定位主逻辑区域。

#### 4.4.4 手工换算的三个坑

1. **别忘减 ImageBase**。节表里的 `VirtualAddress` 是 **RVA**，不含 ImageBase；而你在反汇编里看到的是 **VA**。必须先 $rva = va - ImageBase$。
2. **`.bss` 无法换算**——它没有文件数据（$S_{RA}=0, S_{RS}=0$）。想读 `.bss` 的内容只能在运行时读内存（第6章）。
3. **对齐填充不算内容**。$S_{RS} > S_{VS}$ 的部分是垃圾，别试图解释它。

### 4.5 导入表

**结论先行：导入表是一张"我需要别人的函数"清单。它是逆向中最高效的切入点之一——因为它告诉你这个程序和外部世界的接口。**

#### 4.5.1 数据结构

导入表在数据目录（OptionalHeader 里 16 个目录项的**第 1 项**）中登记。本机实测：

```
Import Directory RVA = 0xA000   size = 2356
```

它由若干 `IMAGE_IMPORT_DESCRIPTOR`（IID，20 字节）组成，每个描述一个 DLL，末尾以全零项结束：

```
typedef struct {
    DWORD OriginalFirstThunk;  // → ILT（Intended Load Table）数组 RVA
    DWORD TimeDateStamp;       // 0 = 未绑定；非 0 = 已绑定快照
    DWORD ForwarderChain;
    DWORD Name;                // DLL 名字字符串的 RVA
    DWORD FirstThunk;          // → IAT（Import Address Table）数组 RVA
} IMAGE_IMPORT_DESCRIPTOR;
```

两个 thunks 数组的关系：

```mermaid
flowchart LR
    IID["IID for KERNEL32.dll"] --> ILT["ILT 也叫 Thunk 数组<br/>OriginalFirstThunk 指向<br/>内容是 hint 与函数名的 RVA"]
    IID --> IAT["IAT<br/>FirstThunk 指向<br/>装载时被改写为真实函数地址"]
    ILT --> INT1["entry 0 → Hint/Name 表项"]
    INT1 --> NM["字符串 DeleteCriticalSection"]
    IAT --> ADDR1["entry 0 → 7FF8xxxxxxxx"]
```

图的含义：**ILT 是给分析者看的（静态可读），IAT 是给 CPU 用的（运行时才被填真）**。两者通常一一对应，但 ILT 可以被删掉（`OriginalFirstThunk = 0`），此时只能靠 IAT——而 IAT 在文件里全是 0，得等运行时才有值。这是"为什么有时静态看不到导入函数名"的第一个原因。

#### 4.5.2 本机实测：我们的样本导入了什么

```
KERNEL32.dll : 14 imports -> DeleteCriticalSection, EnterCriticalSection, FreeLibrary,
                            GetLastError, GetModuleHandleA, GetProcAddress, ...
api-ms-win-crt-environment-l1-1-0.dll : __p__environ
api-ms-win-crt-heap-l1-1-0.dll : _set_new_mode, calloc, free, malloc
api-ms-win-crt-locale-l1-1-0.dll : _configthreadlocale
api-ms-win-crt-math-l1-1-0.dll : __setusermatherr
api-ms-win-crt-private-l1-1-0.dll : __C_specific_handler, memcpy
api-ms-win-crt-runtime-l1-1-0.dll : __p___argc, __p___argv, _cexit, _configure_narrow_argv, ...
api-ms-win-crt-stdio-l1-1-0.dll : __acrt_iob_func, __stdio_common_vfprintf,
                                  __stdio_common_vfscanf, fflush, ...
api-ms-win-crt-string-l1-1-0.dll : strlen, strncmp
```

**清偿第1章黑盒**：`printf` 确实不在这个 exe 的代码里。它经由 `api-ms-win-crt-stdio-l1-1-0.dll` 的 `__stdio_common_vfprintf` 走到 UCRT。CPU 执行 `call printf` 时，实际是跳到 **IAT 里那个槽位所存的地址**。

注意几个有意思的点：
- **UCRT 的分层 API Set**：`api-ms-win-crt-*` 是 Windows 的 API Set 虚拟化名，不是真实 DLL 文件名。这让"看导入表猜依赖"变得复杂（第7章 triage 会处理）。
- **我们写了 `scanf`/`printf`，导入表里却没有这两个名字**——因为它们被 MinGW 的 CRT 包装成了 `__stdio_common_vfprintf` 之类。这说明**导入表反映的是链接后的真实调用，不是你写的源码符号**。
- **`GetModuleHandleA` + `GetProcAddress` 同时出现** → 高度可疑的动态解析组合（4.5.4）。

#### 4.5.3 延迟绑定：装载时到底发生了什么

```mermaid
sequenceDiagram
    participant L as "装载器 loader"
    participant K as "kernel32 ntdll"
    participant P as "你的进程内存"
    L->>L: "读 DOS 头 e_lfanew 得 NT 头"
    L->>K: "按 ImageBase 或随机地址映射镜像"
    L->>K: "递归加载依赖 DLL 并各自重定位"
    L->>P: "遍历 IAT 每一项 写入目标 DLL 中该函数的真实地址"
    Note over P: "此步称为绑定 binding"
    L->>K: "调用 DLL 的入口点 DLL_PROCESS_ATTACH"
    L->>P: "执行 TLS 回调 见 4.6.2"
    L->>P: "跳转到 AddressOfEntryPoint"
```

关键在最后三步的顺序：**TLS 回调在 OEP 之前执行**。这是 4.6.2 的理论基础，也是很多样本把真逻辑藏起来的合法手段。

#### 4.5.4 三种"导入表看不到关键 API"的现象

这是 gap_notes 与 focus_points 都点名的重点：

| 手法 | 原理 | 识别线索 | 对策 |
|---|---|---|---|
| **`GetProcAddress` 动态获取** | 只在导入表留 `LoadLibrary` + `GetProcAddress`，其余函数运行时现取 | 导入表极短、代码里有大量字符串形式的函数名、有一张名字表被循环遍历 | 在 `GetProcAddress` 上下断（第6章），或用字符串交叉引用找那些 API 名 |
| **延迟加载 delay load** | 第一次调用时才解析，IID 走独立的 Delay Directory（数据目录第 13 项） | 有 `..yaml`/`__delayLoadHelper2`、Delay Import Directory 非空 | 看延迟导入目录；Ghidra 会分开显示 |
| **手工构造调用** | 直接 `call qword ptr [固定地址]`，绕过标准 thunk | 代码里出现指向数据的间接 call，而该数据不在标准 IAT 范围内 | 顺着地址找到那张表，手工识别 |

**为什么这对 crackme 重要**：出题人常用 `GetProcAddress` 藏住 `strcmp`/`MessageBox`，让"从导入表下手"这条路失效。这时你要转向**字符串**（4.4.3）与**内存断点**（第6章）。

#### 4.5.5 序号导入

ILT/IAT 项若是最高位置 1（x64 下 bit 63，x86 下 bit 31），低位就是**函数序号**而非名字 RVA：

$$\text{thunk} = \texttt{0x8000000000000001} \;\Rightarrow\; \text{ordinal } 1$$

后果：导入表里只显示序号，看不到名字。某些 DLL（老版 `ws2_32`、`oleaut32` 的部分导出）本来就常用序号。第9章脱壳重建导入表时，序号项的处理方式与名字项不同（只需标记高位即可，无需找名字字符串）。

### 4.6 三个常被用作真实入口的"边角"

**结论先行：不要假设程序从 `main` 开始干活。作者可以把真逻辑藏在导出表、TLS 回调、异常处理里，让 `main` 只是个幌子。**

#### 4.6.1 导出表与序号

导出表在数据目录**第 0 项**，结构 `IMAGE_EXPORT_DIRECTORY`：

```
AddressOfFunctions[]  → 函数 RVA 数组
AddressOfNames[]      → 函数名 RVA 数组
AddressOfNameOrdinals[] → 名字到函数索引的映射
Base                  → 起始序号
```

exe 也可以有导出表（DLL 必有）。**逆向价值**：
- 导出函数名是**未被混淆的高价值符号**——即使符号全 strip，导出名仍在。
- 分析 DLL 时，导出表就是你的目录页。
- 序号与名字的三角映射容易搞错：`AddressOfNames[i]` 配 `AddressOfNameOrdinals[i]`，后者才是 `AddressOfFunctions[]` 的下标。**不是同名同序**。

本机样本是 exe，导出表为空（数据目录第 0 项 RVA = 0）——这是正常现象。

#### 4.6.2 TLS 回调：真正的"最早执行"

TLS（Thread Local Storage）目录在数据目录**第 9 项**。它包含一张回调函数指针数组，Windows 在**完成导入表绑定之后、跳转到 OEP 之前**依次调用它们。

```c
#pragma comment(linker, "/TLSCB")   // MSVC 风格示意
void NTAPI MyCallback(PVOID h, DWORD reason, PVOID ctx) {
    if (reason == DLL_PROCESS_ATTACH) { /* 这里可以干任何事 */ }
}
// GCC: __attribute__((constructor)) 效果类似但在 CRT 之后
```

**识别线索**：
- 节表里有 `.tls` 节（本机样本就有：`VA=0xB000, VSz=0x10`）——MinGW 也会生成它，所以有 `.tls` 不等于有恶意回调，但值得检查目录项。
- 数据目录第 9 项非空。
- Ghidra 会在 Entry Points 里列出 `initial-function` / TLS callbacks（第5章）。

**为什么这是"隐藏入口"**：你在 `main` 里翻半天找不到校验逻辑，因为逻辑在 TLS 回调里已经跑完了——甚至可能已经把某个全局标志设好，或者干脆检测调试器后直接 `ExitProcess`（第9章反调试的一种）。

#### 4.6.3 SEH 与异常表

32 位 x86 Windows 用**链式 SEH**：栈上每帧有一个 `EXCEPTION_REGISTRATION_RECORD`（`prev` + `handler`），通过 `FS:[0]` 指向链表头。

```asm
push  dword ptr fs:[0]        ; 保存旧的链头
mov   eax, [esp]
push  offset my_handler       ; 新 handler
push  eax                     ; 新 prev
mov   dword ptr fs:[0], esp   ; 挂上链表
```

x64 改为 4.3.4 的表驱动（`.pdata`）。

**逆向价值**：
1. **handler 地址是隐藏的第二个执行入口**。样本可以在开头故意除零，让异常处理器接管后续流程——从 OEP 线性追下去你会以为程序"立刻崩溃"。
2. **链式 SEH 是 32 位栈溢出的经典利用目标**（覆盖 handler 指针）。这也是为什么 DEP/ASLR/CFG 都在防它。
3. 若 `DllCharacteristics` 有 `NO_SEH`(0x400)，说明作者主动放弃了 SEH——本身是一种加固声明。

### 4.7 ELF 对照

**结论先行：ELF 与 PE 解决同一个问题，取向不同。PE 面向"节(section)"，ELF 面向"段(segment)"；PE 用数据目录，ELF 用程序头表。**

Linux 侧用 WSL 或交叉工具链。本机可用 `readelf`（MinGW 自带，也能读 PE，但对 ELF 更合适）。

#### 4.7.1 结构对照表

| 概念 | PE (Windows) | ELF (Linux) |
|---|---|---|
| 魔数 | `MZ` + `PE\0\0` | `\x7FELF` |
| 主头 | `IMAGE_NT_HEADERS` | `Elf64_Ehdr`（`e_ident`、`e_type`、`e_machine`、`e_entry`） |
| 入口 | `AddressOfEntryPoint`（**RVA**） | `e_entry`（**绝对虚拟地址**，非 PIE 时含基址） |
| 装载视角 | 节表 + 两种 Alignment | **Program Header Table**（`PT_LOAD` 段） |
| 链接视角 | 节表兼任 | **Section Header Table**（`.text`/`.symtab`/`.strtab`…） |
| 外部函数 | 导入表 IID/ILT/IAT | `.dynsym` + **`.got`** + **`.plt`** |
| 重定位 | `.reloc`（基于页的 block） | `.rela.dyn` / `.rela.plt`（条目式） |
| 特殊早执行 | TLS 回调 | `.init_array` / `DT_INIT` / `__attribute__((constructor))` |
| 位置无关 | `/DYNAMICBASE` 标志 | `ET_DYN`（PIE）vs `ET_EXEC` |
| 线程局部 | `.tls` 节 | `PT_TLS` 段 + `TPADDR` 重定位 |

**最重要的观念差异**：ELF 区分**段（segment，给装载器看）**与**节（section，给链接器/调试器看）**。多个节可以合并进一个 `PT_LOAD` 段——所以 Linux 上一个可执行的 `PT_LOAD` 里同时含 `.text` 和 `.rodata` 是很常见的，权限是整段统一的。PE 则是**一节一权限**，粒度更细。

#### 4.7.2 readelf 实操要点

```bash
readelf -h a.out     # 头部：Type(Exec/Dyn)、Machine、Entry point、Start of section headers
readelf -l a.out     # Program headers：PT_LOAD 的 Off/VirtAddr/FileSiz/MemSiz/Flags —— 这才是装载依据
readelf -S a.out     # Section headers：.text .data .bss .rodata .got .plt 的位置与大小
readelf -d a.out     # Dynamic 段：NEEDED(libc.so.6)、INIT、INIT_ARRAY、JMPREL、SYMTAB
readelf -s a.out     # 符号表（若未 strip，能看到函数名！）
nm -D a.out          # 动态符号
objdump -d -M intel a.out   # 反汇编，与 PE 侧一致
```

`readelf -l` 输出里 **`Off`（文件偏移）与 `VirtAddr`（虚拟地址）并存**，这正是 ELF 版的"RVA↔偏移"信息源：

$$offset = vaddr - P_{VirtAddr} + P_{Off} \quad (\text{按所在 } PT\_LOAD)$$

形式与 4.4 的公式同构——**换皮不换骨**。

#### 4.7.3 GOT / PLT：ELF 的"导入表"

调用外部函数时，ELF 走一条两级跳板：

```mermaid
flowchart LR
    CALL["你的代码<br/>call puts@plt"] --> PLT["PLT 桩 put@plt<br/>jmp qword PTR got_put"]
    PLT --> GOT["GOT 槽 got_put<br/>装载后或首次调用后被填真"]
    GOT --> REAL["libc 里 puts 的真实地址"]
    GOT -.->|"未初始化时指向<br/>resolver 回填路径"| RES["ld.so lazy resolver"]
```

含义：`call puts@plt` 是**固定地址**（在 `.plt` 里），而 `puts` 的真身在 `GOT` 里可被修改。这带来两个实用后果：
1. **懒绑定（lazy binding）**：默认第一次调用时才解析，所以刚装载时 GOT 里指向的是 resolver。想看真地址要么运行时看（第6章 GDB/pwndbg），要么读 `.rela.plt` 自己算。
2. **PLT 是天然的函数清单**：`.plt` 里每个桩对应一个外部函数，逐个 `jmp [GOT]` 的模式很好认。逆向时"找出所有 PLT 桩"约等于"列出所有外部调用"。

#### 4.7.4 PIE 与非 PIE

| | 非 PIE (`ET_EXEC`) | PIE (`ET_DYN`) |
|---|---|---|
| 加载地址 | 固定（`e_entry` 就是最终地址） | 随机（等同 ASLR） |
| 内部引用 | 绝对地址 | **全部 RIP 相对** |
| 现代默认 | 少见 | gcc 默认开启 |

PIE 二进制看起来像"到处是 `[rip+0x…]`"（第1章已见过这种形态，只不过那是 Windows 的 `/DYNAMICBASE`）。**判断方法**：`readelf -h` 看 `Type:` 是 `DYN` 还是 `EXEC`。

顺带一提：本机 Windows 样本的 `DllCharacteristics` 有 `DYNAMIC_BASE`，效果等同于 PIE——两者都靠重定位表工作，见 4.8。

### 4.8 装载与地址随机化

**结论先行：磁盘上的字节与内存里的地址常常不一致，这正是重定位存在的理由。工具帮你把这个映射对上，你能不能利用它取决于你是否知道这个映射关系。**

#### 4.8.1 装载全流程

```mermaid
flowchart TD
    A["CreateProcess 打开 exe"] --> B["读 DOS 头 验 MZ 取 e_lfanew"]
    B --> C["读 NT 头 验 PE 签名 取 Machine 位数"]
    C --> D["按 SizeOfImage 预留一段虚拟内存"]
    D --> E["把 SizeOfHeaders 那部分复制到起始处"]
    E --> F["逐节复制 从 RawOffset 到 VA 对齐的目标地址"]
    F --> G["递归加载依赖 DLL"]
    G --> H{"实际基址 等于 ImageBase 吗"}
    H -->|"是"| I["无需重定位"]
    H -->|"否"| J["按 .reloc 表逐项修正绝对地址"]
    I --> K["填充 IAT 绑定导入函数"]
    J --> K
    K --> L["执行 TLS 回调"]
    L --> M["跳转入 OEP"]
```

图里 `H` 那个分支是本节核心。历史上 exe 被放在 `ImageBase` 就皆大欢喜；现代系统为了安全**故意不放**（ASLR），于是每次都要走 `J` 分支。

#### 4.8.2 ASLR 与 DEP

| 保护 | 做什么 | 本机样本状态 | 对逆向的影响 |
|---|---|---|---|
| **ASLR** | 随机化镜像基址、堆、栈、`ntdll` 等 | `DYNAMIC_BASE` 已开 | 每次运行地址不同；RVA 稳定但 VA 不稳定 |
| **DEP/NX** | 数据页不可执行 | `NX_COMPAT` 已开 | 不能执行注入到 `.data` 的代码 |
| **Stack Cookie (/GS)** | 返回地址前放随机 canary | 需看具体函数 | 覆盖返回地址会触发 `__report_gsfailure` |
| **CFG (/guard:cf)** | 间接调用前查合法目标表 | `GUARD_CF` 未开 | 限制ROP/JOP |

**ASLR 带来的实操纪律**（gap_notes 点名要整合讲解的内容）：

1. **静态分析工具的地址是"假"的**。Ghidra 默认按 `ImageBase` 显示地址（`0x140001760`），这与第一次运行的实际 VA 可能不符。所以：**跨会话引用地址时永远记 RVA，不要记 VA**。
2. **调试器里必须现场读基址**。x64dbg 的模块窗口（Labels/Modules 面板）显示当前进程的 Base Address；正确做法是 `实际地址 = 模块基址 + RVA`，或在调试器里用 `Go to` 输入表达式。**观测手段作黑盒使用，第6章详述。**
3. **patch 落盘要用文件偏移，不能用运行时地址**。你想改掉 `0x140001767` 那条 `cmp`，得先用 4.4 公式算出它在文件里的位置，否则改了也没用（运行时改动不落盘，见第6章临时 patch 与 Save patch 的区别）。
4. **想让地址稳定以便教学/复现**，可以关掉 ASLR：链接时用 `/DYNAMICBASE:NO`（MSVC）或 `-Wl,--disable-dynamicbase`（MinGW），或直接去掉 `DllCharacteristics` 的 `0x40` 位。本课程第6章的练习建议这么做一次，体会差别。

#### 4.8.3 重定位表：ASLR 的实现机制

`.reloc` 节由若干个 block 组成，每个 block 覆盖一页（$4096$ 字节）范围：

```
IMAGE_BASE_RELOCATION {
    DWORD VirtualAddress;   // 本 block 起始 RVA（页对齐）
    DWORD SizeOfBlock;      // 含头在内的总字节数
    WORD  TypeOffset[];     // 高 4 位类型 + 低 12 位页内偏移
}
```

`TypeOffset` 项的编码：

$$\text{type} = \frac{\text{entry} >> 12}{\;},\qquad \text{pageOffset} = entry \,\&\, 0xFFF$$

| type | 名称 | 修正动作 |
|---|---|---|
| 0 | ABSOLUTE | 无操作/块结束标记 |
| 3 | HIGHLOW | 32 位字段 += delta（x86 主力） |
| 10 (0xA) | DIR64 | 64 位字段 += delta（x64 主力） |

其中 $\Delta = \text{实际基址} - \text{ImageBase}$。修正动作就是把指定位置上的数值加上 $\Delta$。

本机样本 `.reloc` 只有 `0x60` 字节——很小，因为现代代码几乎全用 RIP 相对寻址，不需要重定位；只有绝对地址的数据（跳转表、字符串指针数组、COMDAT 局部重载）才需要。

**这条知识在第9章变成刚需**：脱壳后 dump 出来的内存镜像，其重定位表往往已被壳破坏或与原始布局错位；若不重建，加壳后的程序换个基址就崩。同理，**如果 dump 时用了错误的基址，所有绝对地址都会偏一个固定的 $\Delta$** —— 这是"脱壳成功但一运行就崩"的头号原因。

#### 4.8.4 为什么磁盘与内存地址对不上：三个层次

```mermaid
flowchart LR
    L1["层次一 对齐不同<br/>FileAlign 0x200 对 SecAlign 0x1000<br/>导致节间距被拉大"] --> X["同一个字节<br/>在文件与内存中<br/>位置编号不同"]
    L2["层次二 基址随机<br/>ASLR 使 ImageBase 与实际不符<br/>再加 delta"] --> X
    L3["层次三 虚地址空间<br/>每个进程独立 4GB 或 128TB<br/>物理地址由 MMU 翻译"] --> X
```

图的含义：三层原因叠加，但**每一层都是可计算的**。4.4 解决层次一，4.8.2 的"记 RVA"纪律解决层次二，层次三对你透明（虚拟地址就是你看到的那套）。

### 4.9 本章速查：拿到陌生文件的前五个动作

把本章压缩成一套可执行清单（第7章会把它固化进 triage 脚本）：

```powershell
# 1. 类型与位数
$b = [IO.File]::ReadAllBytes("target.exe")
"magic=$([char]$b[0])[char]$b[1]"                       # MZ? 还是 7F 45 4C 46 (ELF)?
$lf = [BitConverter]::ToUInt32($b,0x3C)
"machine=0x{0:X4}" -f [BitConverter]::ToUInt16($b,$lf+4) # 14c=x86 8664=x64

# 2. 入口点
"OEP RVA=0x{0:X}" -f [BitConverter]::ToUInt32($b,$lf+24+16)

# 3. 节表一览（找可疑节名/权限/熵）
#    → 用 DIE 或 CFF Explorer 更快

# 4. 导入表（这个程序和外界说了什么话）
#    → PE-bear / CFF Explorer / Ghidra 的 Symbol Tree → Import

# 5. 字符串（人类可读的线索最多）
strings -a -t x target.exe        # Sysinternals 或 binutils
```

五条做完，你对一个二进制已经有了：**架构、入口、布局、外部接口、文本线索**。这就是第5章 Ghidra 工作的起点，也是第7章 triage 报告的骨架。

---

## ④ 动手练习（基于统一工程增量开发）

全部在 `chapter/04-pe-elf` 分支上。⚠️ **Python 环境提醒**：第1章 1.5.6 已记录本机 `python` 命中的是 WindowsApps 存根、实际不可用。本章练习 1、2 依赖 Python，请先按 1.5.6 装好；若暂时无法安装，讲义同时给出了 PowerShell 等价实现思路。

### 练习 1：rva_calc.py【必做】

写一个双向换算小工具，接口如下：

```
$ python lab/pe/rva_calc.py build/serial_x64.exe --to-offset 0x5050
.rdata  rva=0x5050 -> offset=0x2E50

$ python lab/pe/rva_calc.py build/serial_x64.exe --to-rva 0x2E50
offset=0x2E50 -> rva=0x5050 (.rdata)
```

要求：
1. 只用 `struct.unpack_from` 手工解析，不许引入 `pefile` 之类的库（目的是练手感）；
2. 支持 PE32 与 PE32+ 两种 Magic（偏移不同，见 4.2.1 的 `opt+24` vs `opt+28`）；
3. 对落在 `.bss` 的 RVA 明确报错"BSS has no file data"；
4. 对未映射地址报错并列出所有节的范围供参考；
5. **自校验**：把 4.4.2 的三个实测值写成断言放进脚本，跑一遍确认全绿。

### 练习 2：pe_dump.py【必做】

输出一个 exe 的完整"体检报告"，至少包含：

```
=== DOS ===        e_magic, e_lfanew
=== FILE ===       Machine(+架构名), NumberOfSections, TimeDateStamp, Characteristics
=== OPTIONAL ===   Magic(PE32/PE32+), EntryPoint, ImageBase, SecAlign, FileAlign,
                   SizeOfImage, SizeOfHeaders, Subsystem(带名字), DllCharacteristics(逐位展开)
=== DATA DIRS ===  16 个目录项的 RVA/Size，标注哪些非空（EXPORT/IMPORT/RESOURCE/
                   EXCEPTION/CERTIFICATE/RELOC/MISC/DEBUG/TLS/LOAD_CONFIG/DELAY/BASERELLOC）
=== SECTIONS ===   名称、VA、VSz、Raw、RawSz、Flags 解码出的 R/W/X、以及每节的粗略熵
```

额外两项：
- **熵计算**：对每节统计字节频率分布，香农熵 $H = -\sum_{i} p_i \log_2 p_i$（$p_i$ 是字节 $i$ 出现的概率，除以本节总长）。经验阈值：$H > 7.0$ 高度疑似压缩或加密（第9章判壳的重要线索），普通代码约 $6.0$–$6.8$，纯文本更低。
- 与 CFF Explorer / DIE 的结果逐项比对，**任何不一致都写进笔记并解释原因**（通常是工具做了额外推断，或你解析的偏移错了）。

### 练习 3：tools/check.ps1 保护状态检查【必做】

```powershell
# tools/check.ps1 —— 报告 exe 的 ASLR / DEP 等状态
param([Parameter(Mandatory)][string]$Path)
$b = [IO.File]::ReadAllBytes($Path)
if ($b[0] -ne 0x4D -or $b[1] -ne 0x5A) { Write-Error "not a PE"; exit 1 }
$lf = [BitConverter]::ToUInt32($b, 0x3C)
$so = [BitConverter]::ToUInt16($b, $lf+4+16)
$opt = $lf + 4 + 20
$magic = [BitConverter]::ToUInt16($b, $opt)
$dllch = [BitConverter]::ToUInt16($b, $opt + 70)
"{0,-16} 0x{1:X4}" -f "DllCharacteristics", $dllch
foreach ($p in @( @(0x0040,"DYNAMIC_BASE (ASLR)"), @(0x0100,"NX_COMPAT (DEP)"),
                   @(0x0200,"ISOLATION"), @(0x0400,"NO_SEH"), @(0x8000,"GUARD_CF")) ) {
    "{0,-24} {1}" -f ("0x{0:X4}" -f $p[0]), $(if ($dllch -band $p[0]) {"ON"} else {"off"})
}
```

跑 `build/serial_x64.exe`，确认输出与 4.2.4 的本机实测一致（应为 `DYNAMIC_BASE ON`、`NX_COMPAT ON`、其余 off）。

然后**造一个关 ASLR 的版本**：

```powershell
gcc -O0 -g -Wl,--dynamicbase -o build\serial_aslr.exe lab\serial.c      # 显式开
gcc -O0 -g -Wl,--disable-dynamicbase -o build\serial_noaslr.exe lab\serial.c  # 尝试关
./tools/check.ps1 build\serial_noaslr.exe
```

记录两者的差异，并在笔记里写一句："关掉 ASLR 对我的第6章练习有什么便利？"（答案将在第6章用到：地址可预测，脚本与笔记里的地址可直接复用。）

### 练习 4：手工找 OEP【必做，本章验证点】

**不许用任何 PE 工具**，只用 HxD。先把绝对地址算清楚（本机实测值）：

| 结构 | 计算式 | 文件偏移 |
|---|---|---|
| DOS 头 | — | `0x00` |
| `e_lfanew` 字段本身 | `0x3C` | `0x3C` |
| NT 头签名 `"PE\0\0"` | `= e_lfanew` | **`0x80`** |
| FileHeader | `lf + 4` | `0x84` |
| OptionalHeader | `lf + 4 + 20` | `0x98` |
| Section Headers（节表） | `opt + SizeOfOptionalHeader` = `0x98 + 0xF0` | **`0x188`** |

步骤：

1. 打开 `build/serial_x64.exe`，确认偏移 `0x00` 是 `4D 5A`；
2. 跳到偏移 `0x3C`，读 4 字节小端得 `e_lfanew` → `80 00 00 00` = `0x80`；
3. 跳到 `0x80`，确认 `50 45 00 00`（即签名 `0x00004550`）；
4. FileHeader 从 `0x84` 起：+0 两字节 Machine = `64 86` → `0x8664`（x64）；+2 两字节节数 = `12 00` → **18**；+16 两字节 OptionalHeader 大小 = `F0 00` → **0xF0(240)**；
5. OptionalHeader 从 `0x98` 起：+0 两字节 Magic = `0B 02` → `0x20B`(PE32+)；+16 四字节 AddressOfEntryPoint = `5F 10 00 00` → **`0x105F`**；+24 八字节 ImageBase = `00 00 00 00 00 00 01 00` → **`0x140000000`**；
6. 节表从 `0x98 + 0xF0 = ` **`0x188`** 开始。第一项即 `.text`：名 8 字节 `2E 74 65 78 74`、+8 四字节 VirtSize=`20 25 00 00`(`0x2520`)、+12 四字节 VirtualAddress=`00 10 00 00`(**`0x1000`**)、+16 四字节 SizeOfRawData=`00 26 00 00`(`0x2600`)、+20 四字节 PointerToRawData=`00 06 00 00`(**`0x600`**)、+36 四字节 Flags=`20 00 00 60`(`0x60000020`)；
7. 手工代入公式：$offset = 0x105F - 0x1000 + 0x600 = 0x65F$；
8. 跳到 `0x65F`，读出 `55 48 89 E5 48 83 EC 30`；
9. 用 `objdump -d` 核对 `0x14000105F` 处确实是 `push rbp` / `mov rbp,rsp` / `sub rsp,0x30` 三条指令。

⚠️ 第 6 步那个 `0x188` 是本练习最容易算错的地方——它取决于 `SizeOfOptionalHeader`，而 PE32 与 PE32+ 的这个值不同（常见 `0xE0` 与 `0xF0`）。**必须现场读出来，不能背。**

**这一步做扎实，你就永久摆脱了"地址对不上"的困惑。** 完成后在 `notes/` 写一篇复盘，把你实际读到的每个字节抄下来。

### 练习 5：导入表解剖【必做】

扩展 `pe_dump.py`，让它遍历导入目录并打印：

```
KERNEL32.dll
    OriginalFirstThunk(ILT RVA)=0x????  FirstThunk(IAT RVA)=0x????  TimeDateStamp=0x??
    - DeleteCriticalSection
    - EnterCriticalSection
    ...
```

然后回答三个问题：
1. 本机样本的 IID 里 `TimeDateStamp` 是 0 还是非 0？这说明导入表**有没有被绑定**（4.5.1）？
2. `ILT` 与 `IAT` 两个 RVA 相同吗？如果不同，它们分别落在哪个节？
3. 用 4.4 的公式把 IAT 的 RVA 换算成文件偏移，在 HxD 里看那块字节——**它们是 0 还是有值？** 由此解释"为什么静态分析看不到外部函数的真实地址"。

### 练习 6：PE 与 ELF 左右对照【必做】

在 WSL（或任意 Linux）里编译同一份 `serial.c`：

```bash
gcc -O0 -g -o serial_linux serial.c
readelf -h serial_linux  > elf_h.txt
readelf -l serial_linux  > elf_l.txt
readelf -S serial_linux  > elf_s.txt
readelf -d serial_linux  > elf_d.txt
objdump -d -M intel serial_linux > elf_asm.txt
```

把这些输出贴进 `notes/04-pe-vs-elf.md`，做成一张**左右双栏对照表**，行项目至少包括：魔数、架构字段、入口点及其语义（RVA vs 绝对 VA）、代码所在容器、只读数据在哪、未初始化数据在哪、外部函数机制、重定位机制、装载视角、位置无关性开关。

再回答：
1. `readelf -h` 的 `Type:` 是 `DYN` 还是 `EXEC`？据此判断这是 PIE，并说明它对应 Windows 的哪个标志。
2. `readelf -l` 里有几个 `PT_LOAD`？各自的 `Flags` 是什么（`RWE` 组合）？与 PE 的"一节一权限"相比有何不同？
3. `elf_asm.txt` 里 `puts` 的调用目标是 `puts@plt`。请在 `readelf -S` 里找到 `.plt` 与 `.got` 的地址，解释这次调用要跳几次。

### 练习 7：可疑特征自查【选做，衔接第9章】

用练习 2 的工具扫几个不同来源的 exe（开源软件安装包、你自己加 UPX 后的样本），记录：

| 文件 | 节数 | 最大熵的节 | 有无 `.reloc` | 有无 `.pdata` | 导入 DLL 数 | 可疑度 |
|---|---|---|---|---|---|---|

思考题：如果一个 exe 只有两节、第一节熵 7.9、第二节叫 `UPX1`、导入表里只有 `LoadLibraryA` 和 `GetProcAddress`——你会得出什么结论？（第9章正式回答）

---

## ⑤ 本章小结

回收本章"四问"框架，逐条对应正文：

**问题一 · 这是什么文件（4.1）**
1. PE 是三层信封：DOS 头（`e_magic = 0x5A4D` 即 `"MZ"`，`e_lfanew @ 0x3C` 是跳板）→ NT 头（`PE\0\0` 签名 + FileHeader 20 字节 + OptionalHeader）→ 节表 → 节内容。本机 `e_lfanew = 0x80`。
2. 三个 magic 分工：`MZ` 判"是不是可执行"，`PE\0\0` 判"是不是真 PE"，Optional Magic `0x10B`/`0x20B` 判"32 位还是 64 位"。
3. `Machine` 在 FileHeader +0：`0x14c`=x86、`0x8664`=x64（本机值），另有 ARM 系列 `0x1c0`/`0x1c2`/`0xAA64`。这是最快的架构判据。
4. 小端在此兑现：`0x5A4D` 在文件里是 `4D 5A`，`0x00004550` 是 `50 45 00 00`。

**问题二 · 代码数据放哪（4.2、4.3）**
5. 五个关键字段互相咬合：本机 `AddressOfEntryPoint=0x105F`、`ImageBase=0x140000000`、`SectionAlignment=0x1000`、`FileAlignment=0x200`、`SizeOfImage=0x16000`、`SizeOfHeaders=0x600`、`Subsystem=3`(控制台)。
6. **入口点 ≠ main**。本机 OEP = `0x14000105F` 落在 `mainCRTStartup`，它做完初始化才 `call main`。从 OEP 线性追会先路过一大段无关代码。
7. 两种 Alignment 的意义：内存按页（4096）对齐以便逐节设权限，文件按扇区（512）对齐以省空间——**这个差值是 4.4 公式存在的全部理由**。
8. 六常规节职责：`.text`(R+X 码)、`.data`(R+W 已初始化全局)、`.rdata`(R 常量/字符串/跳转表/部分导入结构)、`.bss`(R+W，**RawSize=0 不占文件**)、`.idata`、`.reloc`。第2章的分区表在文件层获得对应物。
9. 权限位比节名更有强制意义：`0x20000000`=EXECUTE、`0x40000000`=READ、`0x80000000`=WRITE。`.rdata` 的 `0x40000040` 不可写，正是第2章"写只读页当场崩"的根源（清偿 DEP 黑盒的一半，另一半在 4.8.2）。
10. 非常规节是信号：`.pdata`/`.xdata`=x64 异常表、`.tls`=可能有 TLS 回调、`UPX0`/`UPX1`/`.aspack`=加壳。MinGW 的 `/4`、`/29` 怪名是 **COFF 长节名的字符串表偏移写法**，不是被篡改。
11. `.pdata` 里每个 `RUNTIME_FUNCTION` 给出函数的 `[Begin,End,UnwindInfo]`——**符号被 strip 时它仍是一份免费函数清单**。

**问题三 · 从哪执行、需要谁（4.4、4.5、4.6）**
12. 核心公式 $offset = rva - S_{VA} + S_{RA}$（反向 $rva = offset - S_{RA} + S_{VA}$），选节条件是 $S_{VA} \le rva < S_{VA}+\max(S_{VS},S_{RS})$。三条铁律：先减 ImageBase 得 RVA；`.bss` 无法换算；$S_{RS}>S_{VS}$ 的差额是填充垃圾。
13. 本机三次实测闭环验证：`"input: "` rva `0x5050`→off `0x2E50`（读到 `69 6E 70 75 74 3A 20 00`）；OEP rva `0x105F`→off `0x65F`（读到 `55 48 89 E5`，与 `push rbp; mov rbp,rsp` 逐字节对上）；`"ok"/"no"` rva `0x505B/0x505E`→off `0x2E5B/0x2E5E`。
14. 字符串在 `.rdata` 里连续排布（链接器合并），所以**找到一个提示串就能顺藤捞出一整套文案**，这是定位主逻辑区的捷径。
15. 导入表 = 程序与外界的接口清单。结构是 IID(20B)×N + 全零终止；`OriginalFirstThunk`→ILT（给人看，含 Hint/Name RVA），`FirstThunk`→IAT（给 CPU 用，装载时被填真）。本机 Import Dir RVA=`0xA000`，含 `KERNEL32.dll` 14 项及八个 `api-ms-win-crt-*` API Set。
16. **第1章"printf 不在 exe 里怎么被找到"至此清偿**：`call printf` 实际跳到 IAT 槽位所存的地址；本机源码级 `printf` 被链接成 `__stdio_common_vfprintf`。教训：**导入表反映链接后的真实调用，不是你写的符号名**。
17. 装载顺序决定一切：映射 → 递归加载依赖 → 重定位 → **填 IAT** → **TLS 回调** → 跳 OEP。TLS 在 OEP 之前，所以它是合法的"最早执行"藏身处。
18. 三种"导入表看不到关键 API"：`GetProcAddress` 动态获取（线索：导入表极短 + 一堆 API 名字符串）、延迟加载（数据目录第 13 项）、手工构造间接 call。序号导入（thunk 最高位为 1）则只显示序号不显示名字。
19. 三个隐藏入口边角：导出表（exe 也可有；注意名字→序号→函数索引是**三方映射**，不是同名同序）、TLS 回调（`.tls` 节 + 数据目录第 9 项）、SEH（32 位链式 handler 是第二执行入口，x64 改 `.pdata` 表驱动；`NO_SEH` 标志表示作者主动放弃）。

**问题四 · 怎么变成进程（4.7、4.8）**
20. ELF 与 PE 的观念差异：PE 面向**节**且一节一权限；ELF 面向 **`PT_LOAD` 段**，多节可并入一段共享权限。ELF 区分 Program Header（装载视角）与 Section Header（链接/调试视角）。
21. ELF 换算同构：$offset = vaddr - P_{VirtAddr} + P_{Off}$。`e_entry` 是**绝对 VA**（非 PIE 时），而 PE 的 `AddressOfEntryPoint` 是 **RVA**——这是最容易踩的对照差异。
22. GOT/PLT 是 ELF 版导入表：`call puts@plt` → `jmp [got_puts]` → libc 真身；默认懒绑定使刚装载时 GOT 指向 resolver，所以要看真地址须运行时观察或解析 `.rela.plt`。`.plt` 桩序列本身就是"所有外部调用"的清单。
23. PIE(`ET_DYN`) ≈ Windows 的 `DYNAMIC_BASE`：地址随机、内部引用全 RIP 相对。判据 `readelf -h` 的 `Type:`。
24. ASLR 四条纪律：**跨会话记 RVA 不记 VA**；调试器里现场读模块基址（观测手段第6章详述）；**patch 落盘必须换算成文件偏移**；教学期可用 `-Wl,--disable-dynamicbase` 关 ASLR 换取地址可预测。
25. 重定位是 ASLR 的实现机制：`.reloc` 按页分 block，`TypeOffset` 高 4 位类型低 12 位页内偏移，type 3=HIGHLOW(32位)、type 10=DIR64(64位)，修正量为 $\Delta = $ 实际基址 $-$ ImageBase。本机 `.reloc` 仅 `0x60` 字节，因为现代代码多用 RIP 相对寻址。
26. 磁盘与内存对不上有三层原因（对齐差、基址随机、虚拟地址空间），但**每层都可计算**：4.4 解第一层，"记 RVA"解第二层，第三层对分析者透明。
27. 拿到陌生文件的前五个动作：验 `MZ`/`7F454C46` → 读 Machine 定架构 → 读 EntryPoint → 扫节表（名/权限/熵，$H=-\sum p_i\log_2 p_i$，$H>7.0$ 疑压缩加密）→ 看导入表与字符串。这五条就是第7章 triage 脚本的骨架。

**本章新留的黑盒**：调试器里读实时基址与模块视图 → 第6章；Ghidra 如何呈现节与导入 → 第5章；脱壳后重建导入表与重定位 → 第9章。

下一章（第5章）我们终于打开 Ghidra：它替你做的第一件事就是本章 4.9 那五个动作，而你现在已经知道它每一步在读哪些字节、哪里可能骗你。
