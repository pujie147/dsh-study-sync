# 第5章 静态分析主力：Ghidra 反汇编、反编译与交叉引用

## ① 本章在全课程框架中的位置

五层链：**表示层 → 语言层 → 载体层 → 分析层 → 实战层**。前四章打完"看得懂"的地基，本章正式进入**分析层的静态一侧**。

静态分析的定义是：**不运行程序，靠读反汇编与反编译伪代码理解整体逻辑。** 它的不可替代之处在于——只有静态能看见运行时永远走不到的分支（死代码、反调试触发路径、异常处理入口），也只有静态能在样本"一跑就退"时仍然工作。

选 Ghidra 作主力的理由已在第1章给出（NSA 2019 开源、自带反编译器、多架构、免费可商用；IDA Free 则限 x86/x64、反编译走云端、不可商用）。本章训练三件事：**导航能力**（在成千上万个函数里找到那一个）、**建模能力**（把 `sub_140001760` 变成 `check_serial`，把一团字节变成结构体）、**怀疑能力**（反编译器给的是"猜测的 C"，不是真相）。

```mermaid
flowchart LR
    A["第1至4章<br/>地基 看得懂"] --> B["第5章 分析层静态侧<br/>Ghidra 建图<br/>本章"]
    B --> D["第7章 静动合流<br/>方法论"]
    A --> C["第6章 分析层动态侧<br/>x64dbg 实地勘察"]
    C --> D
    D --> E["第8至9章 实战层"]
    style B fill:#e0e8ff
```

### 本章抽象框架

一次完整的静态分析会话，本质是在三个层次之间反复切换：

```mermaid
flowchart TD
    L1["层次一 原始视图<br/>Listing 反汇编<br/>绝对可信 但难读"] --> L3["层次三 结论<br/>这个函数在做什么"]
    L2["层次二 推断视图<br/>Decompiler 伪代码<br/>好读 但可能骗你"] --> L3
    L2 -->|"存疑时下沉核对"| L1
    L1 -->|"看懂后回填命名与类型"| L2
    NAV["贯穿两视图的操作<br/>导航 交叉引用 字符串 导入表"] --> L1
    NAV --> L2
```

图的含义是本课的方法论内核：**伪代码用来快速建立假设，反汇编用来验证假设，命名与类型用来固化结论。** 单向信任伪代码是新手最大的错误；只看反汇编则是效率的自我惩罚。本章每一节都在这三条边上做文章。

### 分节地图

| 节 | 内容 | 对应核心知识点 |
|---|---|---|
| 5.1 | 导入与分析流程 | 新建项目、Import File、Auto Analyze 参数取舍、Function 数与 Entry Points 判读 |
| 5.2 | 四大视图与导航 | Listing / Decompiler / Function Navigator / Data Type Manager；Xrefs；Back-Forward |
| 5.3 | 切入点选择 | 字符串、导入表 API、入口点与 TLS、失败提示反推 |
| 5.4 | 伪代码的正确读法 | `DAT_`/`PTR_` 含义、goto 与 do-while、被拆坏的 stack_var、随时对照 Listing |
| 5.5 | 重命名与类型建模 | Rename、Struct Editor、Apply Function Data、可读性跃升 |
| 5.6 | 控制流与数据流分析 | 流程图视图、Trace Data Flow、忽略死分支与对齐填充 |
| 5.7 | 脚本提效 | Script Manager、批量重命名、按模式搜字节、导出全部伪代码 |
| 5.8 | 多架构与跨平台 | 同一份 C 在 x86/x64/ARM 下的差异、固件类练习 |

---

## ② 承接与补完：统一工程接力与本章分支动线

### 承接

第4章合并后 `main` 处于 `v4-pe-elf`。本章起点：

```bash
cd re-lab
git checkout main
git checkout -b chapter/05-ghidra-static
```

本章复用两个既有资产：**第1章的 `serial.c`/`serial_x64.exe`**（答案已知，适合校验工具行为）与**第3章的 `lab/asm/` 五组对照样本**（每个都有已知的 C 源码，用来检验 Ghidra 还原得准不准）。这是全课程第一次可以"用标准答案考工具"。

### 本章分支动线与验证点

```mermaid
flowchart LR
    S1["main 的 v4-pe-elf<br/>checkout -b chapter/05-ghidra-static"] --> S2["建 ghidra/ 项目目录<br/>导入 lab/asm 全部样本"]
    S2 --> S3["写 tools/ExportPseudo.java<br/>一键导出所有用户函数伪代码"]
    S3 --> S4["产出 decompiled 目录<br/>把伪代码与原始 C 做 diff"]
    S4 --> S5["写 notes/05-workflow-checklist.md<br/>静态十步清单"]
    S5 --> S6{"章末验证点<br/>对剥离符号且无提示串的自制 exe<br/>只用 Ghidra 还原核心校验函数"}
    S6 -->|"通过"| S7["合并回 main 打 v5-ghidra"]
    S6 -->|"未通过"| S3
```

**禁止直接在 `main` 上开发。** 章末：

```bash
git add ghidra/.gitkeep tools/ExportPseudo.java decompiled notes/05-workflow-checklist.md
git commit -m "feat(ch05): Ghidra workflow, pseudo export script, static ten-step checklist"
git checkout main && git merge --no-ff chapter/05-ghidra-static -m "merge ch05: Ghidra static analysis"
git tag v5-ghidra
```

⚠️ `.gitignore` 里已排除 `*.rep/` 与 `*.gpr`（第1章设定），所以 Ghidra 工程本体不进仓库；进仓库的是**导出的伪代码文本**——它是可读、可 diff、可检索的产物。

### 清偿前置黑盒

| 出处 | 原标注 | 本章清偿位置 |
|---|---|---|
| 第1章 1.6.5 | 「同一段代码 objdump 给 10 行汇编、Ghidra 给 3 行伪代码，后者可读性跃升——这是第5章的入口」 | **5.4 / 5.5** |
| 第2章 2.3.3 | 「偏移序列是类型信息的化石……这正是第5章手工建模的思维内核」 | **5.5.3** |
| 第2章 2.5.3 | 「crackme 的标志位一定是全局/静态变量，这条判据直接指导第5章找什么」 | **5.3.4** |
| 第3章 3.7.3 | 「一旦认出跳转表就能 dump 出整张 case 表」 | **5.5.4** |
| 第4章 4.3.4 | 「`.pdata` 是符号被 strip 时的免费函数清单」 | **5.6.4** |
| 第4章 4.6.2 | 「Ghidra 会在 Entry Points 里列出 TLS callbacks」 | **5.1.4** |

本章新留黑盒：**运行时真实数值怎么取** → 第6章（伪代码告诉你"这里算出一个值"，但那个值是多少只有动态知道）；**基址漂移与地址复核** → 第6章模块窗口 + 第7章协同纪律。

---

## ③ 正文

### 5.1 导入与分析流程

**结论先行：Ghidra 打开文件时替你做的，正是第4章 4.9 那五个动作。理解它做了什么、没做什么，你才知道结果哪些可信。**

#### 5.1.1 项目模型

Ghidra 的组织层级是 **Project → Program → 地址空间**。要点：

- 一个 Project 是一个容器目录（`.gpr` + `.rep` 文件夹），里面放多个 Program。
- 一个 Program = 一个被导入的文件 + 你对它做的**全部修改**（命名、注释、结构体、类型）。这些修改存在 `.rep` 里，**不改动原文件**。
- 同一个 exe 可以被导入多次成为不同 Program，互不干扰——本课程建议**每个样本开一个 Program，并把关键结论同时写进 `notes/`**，因为 `.rep` 不在版本控制内。

#### 5.1.2 Import File 的三个决策点

File → Import File 后弹窗里有三处需要你判断：

| 选项 | 默认 | 何时改 |
|---|---|---|
| **Format** | Auto（按魔数嗅探） | 裸固件镜像（无头的 bin）必须手工指定 Loader 并填加载地址 |
| **Load Address** | 用文件的 ImageBase | 想固定地址便于比较两次分析时手工指定；分析 shellcode 时手工设为目标基址 |
| **Open the file in…** | 询问 | 建议选"One shot"式导入后立即开始分析 |

⚠️ **重要提醒**：Ghidra 版本迭代快（11.x 系列反编译器持续改进），界面截图教程极易误导。**以菜单文字为准、以实测为准**，不要照抄旧版截图里的菜单位置。

#### 5.1.3 Auto Analyze 的参数取舍

导入完成后会问"Analyze?"，点是之后弹出 **Analysis Options** 对话框。三个标签页需要理解：

**Analysis 标签**的关键项：

| 分析器 | 作用 | 取舍建议 |
|---|---|---|
| Disassemble Entry Points | 从入口反汇编 | 必开 |
| **Stack** | 推断栈变量、生成 `stack[]` 引用 | 必开（关掉会让局部变量显示成 `[RSP+0x??]` 硬编码，极难读） |
| **XReferences** | 建立交叉引用数据库 | 必开（本章一切导航的基础） |
| Reference resolver | 解析间接引用 | 开 |
| Subroutine Links / Aggressive Instruction Finder | 激进找函数 | **默认关**。遇到大量"data 而非 code"的碎片时再开 |
| ASCII Strings | 建字符串表 | 开（5.3.1 依赖它） |
| Demangler Microsoft/GNU | C++ 名字还原 | 遇到 C++ 样本才有用（第7章 7.6） |
| Embedded Media and Binary Templates | 识别图片等资源 | 大文件慢，可关 |
| Call Convention ID | 推断非默认调用约定 | 开 |

**Limit Options**：设 `Maximum function length` 可防止一个误判的巨大函数吞掉半段代码。

**Prologue delay**：影响函数序言识别，一般不动。

**本课程的标准做法**：先用默认设置跑一遍 Auto Analyze；若发现明显漏识别（比如某段全是 `db` 但你确信是指令），选中该处右键 → Disassemble，或开启 Aggressive Instruction Finder 重跑。

#### 5.1.4 分析完成后的三项判读

分析结束后，左下角进度条消失，此时先别急着读代码，做三项体检：

**(1) 函数数量是否合理。** Window → Function Managers（或 Symbol Tree）。一个几十 KB 的 crackme 通常有 20–200 个函数；若只有 3 个而 `.text` 很大，说明**大量代码没被识别为函数**，需要手工介入。若上万，说明你可能导入了一个带完整 CRT 的大程序。

**(2) Entry Points 检查。** Symbol Tree 底部的 **Entry Points** 节点，Ghidra 会列出：

```
Entry point for .text                    ← 各节的起始
__image_base__                            ← 0x140000000
EXTERNAL                                  ← 外部符号占位
<program entry point>                     ← OEP，来自 AddressOfEntryPoint
TLS Callbacks                             ← 若有（第4章 4.6.2 的兑现）
```

**这一步就是第4章 4.6 的可视化验收**：如果 Entry Points 里出现 TLS Callbacks 而你没注意到，你会在 `main` 里白找半天。

**(3) 有没有 EXTERNAL 之外的"空洞"。** Symbol Tree 的 `Symbols` 里若几乎为空（没有导入名），说明导入表被破坏或被隐匿（第4章 4.5.4），要改用字符串路线。

#### 5.1.5 本机样本的第一眼

导入 `serial_x64.exe` 后，Symbol Tree 里能看到 `main`、`check`、`__tmainCRTStartup`、`printf`、`scanf`、`puts` 等符号——因为第1章编译时带了 `-g`，Ghidra 读到了调试信息。

> **教学纪律**：这是**作弊模式**。真实样本不会有符号。所以本章的每个练习都要求你做两遍：第一遍带 `-g` 导入（得到标准答案），第二遍 strip 掉符号或用 `objcopy -strip-all` 处理后重新导入（体验真实难度），然后对比你的还原准确度。这个自测闭环比任何练习题都有效。

### 5.2 四大视图与导航

**结论先行：Ghidra 有十几个窗口，但你只需要四个视图加一条导航习惯。导航的本质是"沿着引用跳"，而不是"顺着地址滚"。**

#### 5.2.1 四大视图

```mermaid
flowchart LR
    V1["Listing<br/>反汇编视图<br/>左列地址 中间助记符 右列注释"] --> V2["Decompiler<br/>伪代码视图<br/>双击函数或按 F5 打开"]
    V3["Function Navigator<br/>函数列表 可按名与大小排序"] --> V4["Data Type Manager<br/>本地数据类型库<br/>结构体 typedef enum 都在这里"]
    V2 -.->|"选中标识符按 L 或 Ctrl+Shift+G<br/>可跳到对应汇编"| V1
    V1 -.->|"选中函数按 F5"| V2
```

配套还有：Symbol Tree（左侧，Functions / Namespaces / Data / Entry Points / Bookmarks）、Search Text、Script Manager、Todo Comments、Address Map。初学阶段不必全开，用 `Window` 菜单按需调出。

#### 5.2.2 导航快捷键（必须形成肌肉记忆）

| 操作 | 键 | 说明 |
|---|---|---|
| 后退 / 前进 | `Ctrl+-` / `Ctrl+Shift+-` | **最高频**。像浏览器一样回退你的跳转历史 |
| 转到地址 | `Ctrl+G` | 输入 VA 或标号 |
| 交叉引用窗口 | `L`（在选中项上） | 弹出"谁引用了这个"列表 |
| 跳到定义 | `Ctrl+Shift+F12`? 视版本 | 更常用：双击符号 |
| 反编译当前函数 | `F5`（在 Listing 中） | 打开/刷新 Decompiler |
| 重命名 | `L`（Listing 中标签）/ `Ctrl+L`? | **注意版本差异**：多数版本用 `L` 改 label、右键 Change Name 改符号 |
| 添加注释 | `;`（分号） | 光标所在行加注释 |
| 创建函数 | `P` | 把一段代码定义为函数 |
| 取消函数 | `Ctrl+K`? 视版本 | 右键 → Remove Function |
| 反汇编 | 右键 → Disassemble | 把 data 变 code |
| 标记为数据 | `D` | 把 code 变 data（可指定类型） |

⚠️ 快捷键在不同版本间有差异，**以右键菜单为准**。本课程只承诺一件不变的事：`L` 看交叉引用、`F5` 反编译、`Ctrl+-` 回退，这三条在所有近期版本里都存在。

#### 5.2.3 交叉引用：静态分析的脊柱

**"谁调用了我"是逆向中最有价值的一个问题。** Xrefs 有三个方向：

| 方向 | 问题 | 在哪看 |
|---|---|---|
| **To**（入向） | 谁引用了这个地址/数据 | 选中后按 `L`，或右键 Show References To |
| **From**（出向） | 这个位置引用了谁 | 同上窗口切换 |
| **Flow**（控制流） | 从这里能走到哪 | 流程图视图 |

四类典型用法：

1. **字符串 → 引用 → 函数**。看到 `"Wrong password"`，`L` 一下，立刻知道哪个函数在用它。这是 5.3.1 的核心链路。
2. **API → 调用点**。想知道 `strcmp` 在哪被调用：在 Symbol Tree 的 Import 里找到它，`L`，得到全部调用点列表。
3. **全局变量 → 读写点**。想知道 `dword_140009018` 谁写过：`L` 列出所有读写指令。**这是找"注册标志位在哪里被设置"的标准手法**（第2章 2.5.3 的兑现）。
4. **函数 → 调用者**。判断某个函数的角色：入向引用少 = 顶层；多 = 公共工具函数。

**读 Xref 窗口的技巧**：它会区分 `READ`/`WRITE`/`DATA`/`CODE`/`CALL`/`JUMP` 等类型。找"谁改了全局变量"时只看 WRITE；找"谁用了这个字符串"时看 DATA 引用。

#### 5.2.4 一个常见困惑：为什么我的地址和调试器不一样

Ghidra 默认按 PE 头里的 `ImageBase` 显示地址（本机是 `0x140000000`）。而 ASLR 开着（第4章 4.8.2），实际运行时基址每次不同。

**纪律**：**记录与沟通一律用 RVA**。把 Ghidra 地址减去基址得到 RVA，才是跨会话稳定的坐标。第6章会教你在调试器里用"模块基址 + RVA"的方式复核。

### 5.3 切入点选择

**结论先行：拿到一个陌生二进制，永远不要从入口开始一行行读。要找"锚点"——那些必然与人类语义绑定的位置。**

#### 5.3.1 优先级总表

```mermaid
flowchart TD
    P1["首选 字符串<br/>Search String 窗口<br/>找 Correct Wrong Enter Success"] --> R["定位到关键函数"]
    P2["次选 导入表 API<br/>MessageBox strcmp ReadFile<br/>CreateFile InternetOpen"] --> R
    P3["三选 入口与特殊点<br/>OEP TLS 回调 导出函数"] --> R
    P4["四选 失败提示反推<br/>从错误分支倒推判定条件"] --> R
    P5["兜底 结构与熵<br/>节名异常 高熵区 跳转表"] --> R
```

第8章会把这张表升级为"通用解题入口优先级"并给出具体题目演练。

#### 5.3.2 字符串路线实操

Search → For Strings → All（或当前 Program），等待扫描完成。勾选 **minimum length = 4**，注意结果里区分 `ascii` 与 `unicode` 两种类型（第2章 2.2.2 讲过 UTF-16LE 的"隔位 00"特征）。

对本机 `serial_x64.exe`，你会看到：

```
140005050  ascii  "input: "
140005058  ascii  "%d"
14000505b  ascii  "ok"
14000505e  ascii  "no"
```

双击任一项 → Listing 跳到该地址 → 按 `L` → 看到引用它的那条 `lea` → 再 `Ctrl+-` 回到函数上下文。**三步之内你就在主逻辑函数里了。**

**字符串路线的三个失效场景**（必须提前知道，否则会以为工具坏了）：
1. **字符串被加密**：扫描只见乱码。→ 需动态抓解密时刻（第6章内存断点），或找解密函数（第8章题型二）。
2. **字符串被 strip**：某些程序连提示都没有。→ 转导入表路线。
3. **UI 由资源绘制**：Windows 对话框的文字在 `.rsrc` 里而非 `.rdata`。→ 用 Resource View 或看 `DialogBoxParamA` 的模板参数（第4章 4.3.2）。

#### 5.3.3 导入表路线实操

Symbol Tree → Imports。按功能分类扫一眼，往往比读代码更快定性：

| 看到的 API | 大概率在做什么 |
|---|---|
| `ReadFile` / `CreateFileA` / `GetFileSize` | 读文件（可能是 keyfile 型 crackme） |
| `RegOpenKeyEx` / `RegQueryValueEx` | 读注册表（试用计数常存这） |
| `GetWindowTextA` / `GetDlgItemTextA` | 取用户输入（GUI 注册机题） |
| `lstrcmpA` / `strcmp` / `memcmp` | **直接比较——最易破解** |
| `MessageBoxA` / `DialogBoxParamA` | 弹提示（成功/失败信号） |
| `time` / `GetLocalTime` / `GetTickCount` | 时间限制型 |
| `CreateThread` / `VirtualAlloc` / `WriteProcessMemory` | 自解压/注入，警惕加壳 |
| `IsDebuggerPresent` / `NtQueryInformationProcess` | **反调试**（第9章） |
| `InternetOpen` / `URLDownloadToFile` / `socket` | 联网（恶意样本/C2） |
| `LoadLibrary` + `GetProcAddress` 独占 | 隐匿导入（第4章 4.5.4） |

**技巧**：在 Import 项上按 `L` 直接得到所有调用点，比在函数里翻快得多。若导入表可疑地短，说明作者刻意藏了东西。

#### 5.3.4 全局变量路线（第2章判据的兑现）

第2章说"crackme 的状态标志必然是全局/静态变量"。在 Ghidra 里落地为：

1. Symbol Tree → **Data**，浏览所有已定义的全局；
2. 关注名字里带 `flag`/`count`/`state`/`registered` 语义的（若已被命名）；未命名的则看 `DAT_14000xxxx` 系列；
3. 对候选变量按 `L`，看 WRITE 引用有几处——**写入点极少、读取点很多的布尔型全局，几乎一定就是那个"注册成功标志"**；
4. 顺 WRITE 引用的函数进去，那里就是校验逻辑。

配合第4章 4.3.1：`.data` 里的初始值你能在文件里读到（`RawSize>0`），`.bss` 里的只能运行时看。

### 5.4 反编译伪代码的正确读法

**结论先行：伪代码是"猜测的 C"。它给你的类型、循环形态、变量划分都是启发式推断的结果。养成习惯：反编译器说这里是个 int，你要去内存窗口与 Listing 里亲自核对长度和对齐。工具越智能，越要保留这一份怀疑。**

#### 5.4.1 本机实测：三段真实伪代码

**样本 A — `check`（简单情形，还原得很好）**

```c
int __cdecl check(int param_1)
{
  return (int)(param_1 == 0x51);
}
```

对照第3章 3.4.3 的 10 行汇编，Ghidra 正确还原了：参数经 `ECX` 传入（但它标成 `__cdecl` 是 Ghidra 的习惯标注，Microsoft x64 首参实为 `RCX`，见 5.4.5）、比较常量 `0x51`、返回值在 `EAX`。**这就是第1章说的"可读性跃升"。**

**样本 B — `sum_n`（`-O0`，循环还原正确）**

```c
undefined4 __fastcall sum_n(int n)
{
  undefined4 uVar1;
  int iVar2;
  int iVar3;

  iVar3 = 0;
  uVar1 = 1;
  if (1 < n) {
    do {
      iVar2 = (int)uVar1;
      iVar3 = iVar3 + iVar2;
      uVar1 = (undefined4)((ulong)uVar1 + (ulong)(uint)"\n\b"[0]);
    } while ((int)uVar1 <= n);
  }
  ...
}
```

注意几个**典型的不可信之处**：
- `uVar1` 的类型被猜成 `undefined4`——它其实是 `int`。
- `(uint)"\n\b"[0]` 这种荒谬表达式：Ghidra 把一个 `add reg,1` 里的立即数 `1` 误关联到了附近的字符串字面量。**这是反编译器的真实 bug 形态之一**，看到奇怪的东西要下沉到 Listing 核对原始指令。
- `if (1 < n)` 的外层判断是 GCC 生成的边界分支被正确还原。

**样本 C — CRT 启动函数（复杂情形，充满噪声）**

```c
void __cdecl __tmainCRTStartup(void)
{
  undefined8 *puVar1;
  ...
  do {
    puVar1 = (undefined8 *)malloc(0x30);
    if (puVar1 == (undefined8 *)0x0) {
      _invalid_parameter_noinfo();
      ...
    }
    *(undefined8 **)*puVar1 = puVar1;
    ...
LAB_1400013d1:
    if (*(int *)(&DAT_140009018 + ...) != 0) goto LAB_1400013db;
    ...
  } while( ... );
}
```

这类大型函数里，**`goto` 与 `do{}while` 混排、指针算术混乱、`&DAT_xxx` 满天飞**是常态。应对策略见 5.4.2–5.4.4。

#### 5.4.2 `DAT_`、`PTR_`、`UNDEFINED_` 命名体系

| 前缀 | 含义 | 你该做什么 |
|---|---|---|
| `DAT_140005050` | 该地址有数据但类型未知 | 查它是不是字符串/结构体，然后定义类型 |
| `PTR_14000a100` | 该处是一个**指针**（常用于 IAT） | 多半是导入函数表项，改名并赋予函数指针类型 |
| `undefined1/2/4/8` | 宽度已知、语义未知 | 根据用法收窄（比较对象是字符？计数？） |
| `code` | 被识别为指令但不在任何函数内 | 用 `P` 建函数 |
| `switchD_140001abc` | switch 的跳转表 | 见 5.5.4 |
| `stack[]` | 栈变量数组（Stack Analyzer 产物） | 逐个改名并赋类型 |
| `fPtr`/`_func_*` | 函数指针类型 | 结合调用点判断原型 |

**核心心法**：`DAT_`/`PTR_` 密集出现的地方，就是你**还没做完建模工作**的地方。每清掉一个，伪代码就更接近可读。

#### 5.4.3 goto 与 do-while：循环被还原成什么样

三种常见形态及解读：

```c
// 形态一：正常 while（Ghidra 认出来了）
while (iVar1 > 0) { ... }

// 形态二：do-while（至少执行一次）
do { ... } while (cond);

// 形态三：goto 逃生舱（Ghidra 没能识别成结构化循环）
LAB_140001234:
  ...
  if (cond) goto LAB_140001234;     // ← 这其实就是一个循环
```

形态三里 `if (cond) goto LABEL;` 且 LABEL 在当前代码之前 ⇒ **它就是循环**。这是编译器 `-O2` 优化后常见的"非自然"形态（第2章 2.6.2 讲的展开与尾跳转）。

**多个 `goto` 汇聚到同一标签** ⇒ 那是共用的出口/清理块（C++ 析构、错误处理、`return` 集中点）。第8章变形控制流型题目专门玩这个。

#### 5.4.4 被拆坏的 stack_var 与"变量归并"

`-O2` 下寄存器分配会让**同一个栈槽先后承载多个不相关变量**（slot reuse）。Ghidra 于是输出：

```c
  uVar3 = *(undefined4 *)(param_1 + 4);
  *(undefined4 *)pcVar5 = uVar3;
  uVar3 = *(undefined4 *)(param_1 + 8);   // 又用一次 uVar3
```

或者反过来，把**一个变量的多次访问拆成多个 `uVar`**。

对策三条：
1. 不要执着于"Ghidra 认为有几个变量"，而是看**寻址形式**：同一个 `[rbp-0x18]` 上的多次读写，语义上就是一个变量（或其不同字段）。
2. 手工给它定类型（5.5.2），Ghidra 会自动重新切分字段。
3. 若实在混乱，回到 Listing 读原始指令——第3章的四抓手永远比伪代码可靠。

#### 5.4.5 调用约定的标注未必准

5.4.1 样本 A 里 Ghidra 写了 `__cdecl check(int param_1)`，但我们知道本机是 MinGW 编的 x64 程序，首参在 `RCX`。这不是错——在 x64 语境下 `__cdecl` 只是 Ghidra 表达"整数参数走默认寄存器序列"的方式，与 32 位的 cdecl 含义不同。

**真正需要你干预的场景**：某个自定义 DLL 用了非默认约定，导致 Ghidra 猜错参数个数与位置。此时在函数上右键 → Function Properties → Calling Convention 手工改（`stdcall`、`thiscall`、`fastcall` 或自定义），伪代码会立刻重排参数。第3章 3.6.1 的清栈判据在这里当尺子用。

#### 5.4.6 怀疑—核对流程（gap_notes 点名内容）

gap_notes 指出"反编译器误判的排错方法几乎没有成文指南"。本节给出可执行的三步：

```mermaid
flowchart LR
    A["第一步 起疑<br/>伪代码出现 undefined DAT_ 奇怪字符串索引<br/>或明显不合常理的运算"] --> B["第二步 下沉 Listing<br/>定位到对应机器指令 逐条读<br/>用第3章四抓手独立还原"]
    B --> C["第三步 修正输入<br/>给地址定类型 建结构体 改调用约定 重命名<br/>让反编译器拿到更好的信息"]
    C --> D["刷新 F5 看是否改善"]
    D -->|"仍不对"| B
    D -->|"改善"| E["结论可信 继续推进"]
```

**关键认知**：反编译质量取决于**你喂给它的信息量**。它输出垃圾，往往不是因为算法差，而是因为那块内存的类型信息缺失。修类型 → 重反编译，是提升可读性的正循环。这也是 5.5 存在的意义。

### 5.5 重命名与类型建模

**结论先行：这是把"能看懂"变成"看得舒服"的唯一途径，也是唯一能让分析成果留存下来的方式。命名和类型是你的分析笔记，只不过记在了工具里。**

#### 5.5.1 重命名规范

三类对象各自的重命名点：

| 对象 | 操作 | 命名风格建议 |
|---|---|---|
| 函数 | 右键 → Function name（或编辑框内改） | 动词短语：`check_serial`、`decrypt_buffer`、`get_user_input` |
| 全局/数据 | 右键 → Label | `g_registered`、`cfg_max_tries`、`s_err_wrongkey` |
| 局部变量 | 在伪代码里右键 → Rename Variable | 语义名：`i`、`len`、`hash_acc`、`cursor` |
| 标签/地址 | `L` 改 label（注意与 Xref 快捷键冲突，看版本） | `loc_` 自定义前缀如 `fail_exit` |

**命名即思考**。当你无法给一个函数起名时，说明你还没真的懂它——这是一个极好的自检信号。第7章的分析纪律会把它写成规则。

#### 5.5.2 给数据定类型

两种方式：

**(a) 就地改**：在伪代码里右键变量 → Retype Variable；或在 Listing 里按 `D` 选类型。

**(b) 建类型再用**：Data Type Manager（Shift+Ctrl+D? 视版本，或 Window → Data Type Manager）→ New Data Type Category → 定义 struct → 在使用处 Apply Data Type / `Ctrl+L`? 用右键菜单最稳。

#### 5.5.3 结构体重建：偏移序列的兑现（清偿第2章 2.3.3）

第2章说过："看到 `BYTE PTR [rcx]`、`DWORD PTR [rcx+0x4]`、`BYTE PTR [rcx+0x8]`、`QWORD PTR [rcx+0x10]` 就能反推出含 padding 的结构体。"现在做出来。

假设 Ghidra 伪代码给你：

```c
undefined4 __fastcall parse(undefined8 param_1)
{
  if (*(char *)param_1 == 'V') {
    if (*(int *)(param_1 + 4) == 0x100) {
      if (*(char *)(param_1 + 8) != '\0') {
        return *(double *)(param_1 + 0x10);
      }
    }
  }
  return 0;
}
```

**推理过程**（完全复用第2章 2.3 的对齐规则）：

| 访问 | 宽度 | 偏移 | 推断 |
|---|---|---|---|
| `*(char*)p` | 1 | 0 | `char field_0` |
| `*(int*)(p+4)` | 4 | 4 | `int field_4`，**偏移 4 说明 1→4 之间有 3 字节 padding** |
| `*(char*)(p+8)` | 1 | 8 | `char field_8` |
| `*(double*)(p+0x10)` | 8 | 16 | `double field_16`，**偏移 16 说明 9→16 之间有 7 字节 padding** |

于是建结构体：

```c
struct ConfigRec {
    char   magic;      // 0x00  期望 'V'
    char   pad0[3];    // 0x01
    int    version;    // 0x04  期望 0x100
    char   enabled;    // 0x08
    char   pad1[7];    // 0x09
    double value;      // 0x10
};                   // sizeof = 0x18 = 24
```

**操作**：在 Data Type Manager 里新建这个 struct（Ghidra 会自动插入 padding 并显示 offset 列，与你推算的一致即正确），然后回到函数，把 `param_1` 右键 → **Function Properties → Arguments** 改成 `ConfigRec *`，或选中变量右键 **Apply Data Type**。

**效果**：伪代码立刻变成

```c
  if (pcVar1->magic == 'V') {
    if (pcVar1->version == 0x100) {
      if (pcVar1->enabled != '\0') {
        return pcVar1->value;
```

**这就是"可读性跃升"的实际含义**——不是工具变聪明了，是你给了它正确的信息。第2章学的对齐规则在此刻全额兑现。

#### 5.5.4 跳转表的结构化（清偿第3章 3.7.3）

Ghidra 认出 switch 时会生成 `switchD_140001abc` 这样的标签，并在 Listing 中把表项显示为一串地址。三种确认手段：

1. **流程图视图**（5.6.1）：菱形分发节点扇出 N 条边，一眼看清 case 数。
2. **伪代码里的 `switch`**：Ghidra 通常能还原成标准 `switch(iVar){case 1: ...}`。若还原失败会退化成 `goto` 链。
3. **手工 dump 表**：若 Ghidra 没识别（常见于混淆样本），在 `switchD_` 地址处按 `D` 定义为 `undefined4[N]` 数组，读出各项 RVA，再 `Ctrl+G` 逐个跳过去看。

第3章练习 3 让你用 Python dump 跳转表，此处是它的工具版实现。

#### 5.5.5 建模的收益递减与止损

一个现实提醒：**不要试图把整个程序的类型都建完**。经验法则：

- 只对**你正在追的那条数据路径**上的变量建模；
- 建到"我能用一句话描述这个函数干什么"就停；
- 剩下 90% 的 `sub_XXXX` 保持原名——它们是 CRT、库代码、无关功能。

**判据**：如果你已经能写出 keygen 需要的公式，就不要再去美化别的函数了。第8章的限时节奏依赖这个止损能力。

### 5.6 控制流与数据流分析

**结论先行：控制流回答"能走到哪"，数据流回答"值从哪来"。前者帮你理解结构，后者帮你提取算法。**

#### 5.6.1 流程图视图

Listing 顶部的小图标（Function Graph）打开后，每个基本块是一个节点，边标注 `Jcc.T`/`Jcc.F` 或 `Fallthrough`。识别要点：

| 图形特征 | 语义 |
|---|---|
| 一个菱形块扇出 ≥3 条边 | switch 分发（5.5.4） |
| 有一条边指回上方的更早节点 | **循环**（回边） |
| 多条边汇入同一节点 | 共用出口 / 短路合流（5.4.3） |
| 孤立节点无任何入边 | 未被引用的死代码，或**隐藏的第二个入口**（TLS/SEH，第4章 4.6） |
| 大片区域互相缠绕难以分层 | 控制流平坦化（第8章题型三、第9章混淆） |

**"孤立节点无入边"这一条极其重要**：它常常意味着有个函数是被间接调用或被系统回调触发的，你在正常流程里永远走不到。第9章的反调试检测就藏在这种节点里。

#### 5.6.2 Trace Data Flow：反向切片

在伪代码或 Listing 里选中一个变量/地址，右键 → **Trace Data Flow**（或 Trace Function Data Flow）。Ghidra 会构建一棵"这个值的来源树"：

```
uVar5 (= 0x1F4)
├── from mov eax, 0x1F4                       @ 1400012a0
└── from add eax, ecx                          @ 1400012b8
    ├── ecx ← from xor ecx, edx                @ 1400012c0
    │   └── edx ← from [rbp-0x8]
    │       └── [rbp-8] ← WRITE by call decrypt_buf @ 140001300
    └── ...
```

**用途**：当你锁定"最终比较的那个常量/值"，反向切片能自动带你穿过所有中间变换，直达源头（通常是用户输入或某个解密函数）。这是第8章算法还原的主力操作，比手工回溯快得多。

对应的正向操作是 **Trace Pointer Backward / Forward**（针对指针，判断缓冲区边界，用于分析溢出型题目）。

#### 5.6.3 主动忽略两类噪声（第3章 3.8.3 的工具版）

1. **对齐填充**：Ghidra 有时会把 `nop` 滑进函数尾部。它们不影响语义，读代码时跳过即可。
2. **死分支**：`cmp 0,0` 后的 `jne`、或流程图里无入边的节点。处理方式：确认不可达后，在该处加注释 `/* dead code */` 并在心里划掉它。**不要因为一个走不到的分支好看就去研究它**——这是新手最常见的注意力黑洞。

#### 5.6.4 用 .pdata 补齐函数清单（清偿第4章 4.3.4）

若符号被 strip 且 Ghidra 的函数数量明显偏少，可以手工比对：

1. 用第4章练习 2 的 `pe_dump.py` 打印 Exception Directory（数据目录第 6 项）的内容，得到全部 `BeginAddress` 列表；
2. 在 Ghidra 里 Symbol Tree → Functions 数一下已有多少；
3. 差集就是漏识别的函数入口，逐个 `Ctrl+G` 跳过去按 `P` 建函数。

这是"工具偷懒时你来补"的典型协作。第7章 triage 报告里会把"函数数 vs `.pdata` 条目数"作为一个一致性指标。

### 5.7 脚本提效

**结论先行：点来点去很爽，但重复劳动会拖死你。凡是做过三遍的动作，都应该交给脚本。**

#### 5.7.1 Script Manager

Window → Script Manager（或工具栏按钮）。Ghidra 内置大量脚本（`Modify`、`Show`、`FunctionID` 等分类），也支持你自己写 Java / Jython(Ghidra 的 Python 桥) / PyGhidra。

常用内置脚本：
- `ShowAllSections.java` / `SetFrameType` 等小工具；
- `MatchCodeCompilers.java`：校验编译器签名；
- `FixupUtil` 系列：批量处理。

#### 5.7.2 三个立刻可用的脚本

**(a) 导出全部用户函数伪代码**（本章交付物 `tools/ExportPseudo.java`）

```java
// ExportPseudo.java —— 把所有非外部、非 thunk 函数的伪代码导出到目录
// 用法：Script Manager 里运行，arg 传输出目录绝对路径
import ghidra.app.decompiler.*;
import ghidra.program.model.listing.*;
import java.io.*;

String outDir = getScriptArgs()[0];
new File(outDir).mkdirs();

DecompInterface decomp = new DecompInterface();
decomp.openProgram(currentProgram);

Listing listing = currentProgram.getListing();
FunctionIterator it = listing.getFunctions(true);
int n = 0;
while (it.hasNext()) {
    Function f = it.next();
    if (f.isExternal() || f.isThunk()) continue;          // 跳过导入桩
    String name = f.getName();
    if (name.startsWith("FUN_") || name.startsWith("thunk")) continue; // 只要已命名的
    DecompileResults r = decomp.decompileFunction(f, 60, monitor);
    File fo = new File(outDir, sanitize(name) + "_" + f.getEntryPoint() + ".c");
    try (PrintWriter pw = new PrintWriter(fo)) {
        pw.println("/* func " + name + " @ " + f.getEntryPoint()
                 + "  size=" + (f.getBody()==null?0:f.getBody().getNumAddresses()) + " */");
        if (r.completedSuccessfully() && r.getDecompiledFunction() != null) {
            pw.println(r.getDecompiledFunction().getC());
        } else {
            pw.println("/* decompile failed: " + r.getErrorMessage() + " */");
        }
    }
    n++;
}
println("exported " + n + " functions to " + outDir);

String sanitize(String s) { return s.replaceAll("[^A-Za-z0-9_.-]", "_"); }
```

> ⚠️ 上面这段是**结构示意**。Ghidra 的脚本 API 在不同版本间有出入（例如成功判据在不同版本叫 `completedSuccessfully()` / `isCompleted()`，`getDecompiledFunction()` 可能返回 null），而且 Ghidra 的 Jython 桥与新版 PyGhidra 的方法命名风格也不一致。**本课程要求你亲手把它改到能在你的版本上跑通**——因为这个"改到能跑"的过程本身就是熟悉 Ghidra API 的最快路径。跑通后把可用版本提交进仓库。

**为什么要导出？** 伪代码变成纯文本之后：可以 `grep`（"哪个函数出现了 0x5A？"）、可以 `diff`（两次分析改了什么）、可以进 git（`.rep` 不能进，文本能进）、可以让 AI 助手帮你读。**这是把一次性劳动变成可积累资产的关键一步。**

**(b) 批量重命名未命名函数为编号**

```java
// NumberUnnamed.java —— 把 FUN_xxx 改成 q_001 q_002 ... 便于口头讨论
Listing l = currentProgram.getListing();
int i = 0;
for (Function f : l.getFunctions(true)) {
    if (f.getName().startsWith("FUN_")) {
        f.setName("q_" + String.format("%03d", ++i), SourceType.USER_DEFINED);
    }
}
println("renamed " + i);
```

**(c) 按字节模式搜索**（找特定指令序列，如所有 `xor reg,reg` 之后的比较）

```java
// FindPattern.java —— 搜索字节模式，"?? " 表示通配
byte[] pat = {(byte)0x3C,(byte)0x51};   // cmp al, 0x51 的后半
AddressSetResult r = findBytes(getAddressFactory().getImageBase(),
                               pat, "??", true, monitor);
for (Address a : r.addresses) println("hit @ " + a);
```

#### 5.7.3 命令行批量分析（headless）

真正的规模化靠 **`analyzeHeadless`**：

```bash
analyzeHeadless ./myproj ./importdir -import *.exe \
    -postExport decompiled -scriptPath ./scripts -postScript ExportPseudo.java
```

用途：一次导入一批 crackme 全部导出伪代码，再用 grep 筛"所有用到 `lstrcmp` 的样本"。第8章题库管理会用到它。

### 5.8 多架构与跨平台

**结论先行：Ghidra 的真正杀手锏不是 x86，而是它什么都能读。同一份 C 在不同架构下会长成完全不同的样子，认识这些差异才不会一见陌生架构就慌。**

#### 5.8.1 同一份 C 的三种面貌

以第3章的 `check(x)` 为例（概念对照，非本机 ARM 实测）：

| | x86 (32) | x64 (MS ABI) | ARM64 (AArch64) |
|---|---|---|---|
| 参数位置 | `[ebp+8]`（栈） | `ECX`（寄存器） | `W0`（寄存器） |
| 比较 | `cmp DWORD PTR [ebp+8],0x51` | `cmp DWORD PTR [rbp+0x10],0x51` | `cmp w0, #0x51` |
| 条件跳转 | `jne` | `jne` | `b.ne` |
| 返回值 | `EAX` | `EAX`/`RAX` | `W0`/`X0` |
| 帧 | `push ebp;mov ebp,esp` | `push rbp;mov rbp,rsp` | `stp x29,x30,[sp,#-0x10]!` |
| 立即数编码 | 任意 32 位 | 任意 | **受限**（需满足 movz/movk 的分片格式） |

**ARM 的两个必知差异**：
1. **没有 push/pop 的传统栈帧**，用 `stp`/`ldp`（load/store pair）成对存取，且支持**前索引带回写**（`[sp,#-0x10]!`）。
2. **大常数要拼**：`mov w0, #0x12345678` 编不出来，实际是 `movz w0,#0x5678` + `movk w0,#0x1234,lsl #16`。看到连续的 `movz`/`movk` 就是在装载一个大立即数——这是 ARM 逆向的第一个适应点。

#### 5.8.2 跨平台的实用价值

Ghidra 支持的架构覆盖 x86/x64、ARM/ARM64、MIPS、PPC、RISC-V、6502、Z80、Java 字节码等。这带来三类练习场景：

| 场景 | 工具组合 | 关键差异 |
|---|---|---|
| Android `.so` | Ghidra(ARM64) + `readelf` | ELF + PIE + GOT/PLT（第4章 4.7） |
| 路由器固件 | `binwalk` 抽取 → Ghidra(MIPS/ARM) | **大端**（第1章 1.4 的字节序知识兑现）、无符号、常有压缩 |
| MCU / IoT | Ghidra(ARM Thumb) | 地址空间小、向量表在 0 处 |
| VM 字节码题 | Ghidra 自定义处理器或手工建模 | 自定义指令集与 handler 表（第8章题型四） |

**大端提醒**：ARM/MIPS 可配置为大端。大端下 `0x1337` 在内存里是 `13 37`（顺序与直觉一致），而小端是 `37 13`。搜数据前先确认 `readelf -h` 的 `Data:` 字段（`little endian` / `big endian`）。

#### 5.8.3 什么时候不该用 Ghidra 反编译

三类情况反编译质量很差，应直接读汇编：
1. **非主流/自定义指令集**（VM 题的字节码）——反编译器根本不认识；
2. **大量 PIC/自修改代码**——它无法确定目标；
3. **强混淆后的平坦化控制流**——伪代码会变成 `goto` 地狱（第9章）。

这时第3章练的手工读汇编能力就是你的地板。**这也是本课程坚持"第3章最难最重要"的最终理由。**

---

## ④ 动手练习（基于统一工程增量开发）

全部在 `chapter/05-ghidra-static` 分支上。

### 练习 1：双轨导入与准确度自评【必做】

对第3章 `lab/asm/` 的五个样本（`cond_if`、`loops`、`switch_table`、`callconv`、`struct_pass`）各做两遍：

- **A 轨（开卷）**：直接导入带 `-g` 的 exe，Ghidra 能看到原始符号名；
- **B 轨（闭卷）**：`objcopy -strip-all` 处理后另存为 `_stripped.exe` 再导入，凭伪代码自己还原并重命名。

然后填一张自评表放进 `notes/05-accuracy.md`：

| 样本 | 我起的函数名 | 原名 | 参数个数对不对 | 类型对不对 | 循环识别对不对 | 得分 |
|---|---|---|---|---|---|---|

**目标不是满分，而是找出你的系统性偏差**（例如"总是把 `unsigned` 猜成 `int`"或"跳转表还原率 40%"），这个偏差会指导你后面复习哪一节。

### 练习 2：结构体建模全流程【必做，本章核心】

用 5.5.3 的 `ConfigRec` 例子：

1. 先在 Ghidra 里**只看不建**，抄下伪代码中出现的所有偏移与访问宽度；
2. 手工推算 padding（用第2章 2.3 的规则），写下你预测的结构体；
3. 在 Data Type Manager 里建出来，看 Ghidra 显示的 offset 列是否与你的推算一致；
4. 应用到函数参数上，**前后各截一张伪代码图**，直观感受"可读性跃升"；
5. 把 `sizeof` 与第2章练习 2 的实测表交叉验证。

### 练习 3：静态十步清单【必做，本章交付物】

写 `notes/05-workflow-checklist.md`，把你自己的标准动作固化下来。参考骨架（请用自己的话改写并补充踩坑）：

```markdown
# 拿到新样本的静态十步
1. 先看不是代码：位数/壳/编译器 → DIE + 第4章 4.9 五动作
2. 导入 Ghidra，默认 Auto Analyze，记下函数总数
3. 查 Entry Points：有无 TLS 回调？OEP 落在哪个节？
4. 扫字符串：min len 4，找人类语义词，逐个 L 看引用
5. 扫导入表：按 5.3.3 的分类表定性，重点 API 逐个 L
6. 从最可疑的函数开始 F5，先读结构不读细节
7. 起疑即下沉 Listing（5.4.6 三步），不信任 undefined/DAT_
8. 对追到的路径建类型（5.5.2/5.5.3），刷新伪代码
9. 用 Trace Data Flow 反向切出算法源头（5.6.2）
10. 每解开一处写两行"干了什么、卡在哪"，命名即思考
```

### 练习 4：跑通 ExportPseudo.java【必做】

按 5.7.2(a) 把脚本改到能在你的 Ghidra 版本上运行，输出目录 `decompiled/` 并提交进仓库。验收标准：

```bash
ls decompiled/ | wc -l              # 大于 0
grep -rl "0x51" decompiled/         # 能命中 check 函数
grep -rn "xor" decompiled/ | head   # 能定位异或运算
```

**然后在笔记里回答**：这个 grep 能力在第8章刷 12 道题时会怎样帮你？（提示：跨样本检索共同模式。）

### 练习 5：流程图判读【必做】

对 `switch_table.c` 与一个 `-O2` 编译的 `loops.c`，各截一张 Function Graph，在旁边标注：

1. 哪个节点是分发点？扇出几条边？与 case 数一致吗？
2. 哪条边是回边（构成循环）？
3. 有没有无入边的孤立节点？如果有，它是什么？
4. `-O2` 版本里"共用的收尾分支"对应展开循环的奇偶尾巴（第2章 2.6.2、第3章 3.7.2）——在图上把它圈出来。

### 练习 6：怀疑训练【必做，衔接第7章】

故意制造一次反编译器误判，体会"工具会骗人"：

```c
// lab/static/pun.c
#include <stdio.h>
typedef union { unsigned int u; float f; unsigned char b[4]; } V;
int main(void){ V v; v.u = 0x4048F5C3;   /* 这是 float 1.0f<<... 的位模式 */
  printf("%u %.3f %02X%02X%02X%02X\n", v.u, v.f, v.b[0],v.b[1],v.b[2],v.b[3]);
  return 0; }
```

导入后观察 Ghidra 把这 4 字节解释成了什么，然后：
1. 用 5.4.6 的三步流程，去 Listing 核对原始指令到底在读几个字节；
2. 手工 `Retype` 成 `float`，看伪代码如何变化；
3. 在笔记里写下："我第一次看到的 `undefined4` 为什么会误导我？"

（第2章 2.3.5 预告过的 int/float 歧义，在这里正面遭遇。$0x4048F5C3$ 作为 IEEE-754 单精度是 $3.14$ 附近——你可以用 `struct.pack` 或 PowerShell 的 `[BitConverter]::ToSingle` 验证。）

### 练习 7：章末考核【必做，本章验证点】

造一个"真样本"难度的靶：

```powershell
gcc -O2 -o build/blind.exe lab/serial.c
objcopy -strip-all build/blind.exe build/blind_stripped.exe
```

`blind_stripped.exe` 的特点：无符号、`-O2` 变形、提示串仍在但函数名全无。**不许运行它**，只用 Ghidra 完成：

1. 找到主校验函数（不许靠猜地址，必须给出你的切入路径与依据）；
2. 还原其等价 C 代码；
3. 写出正确答案（一个数字或一串字符）；
4. **最后**才允许运行验证你的答案；
5. 写一篇 `analysis.md` 记录切入路径、每一步的依据、以及你在哪里差点被骗。

达标标准：第 3 步的答案在第 4 步一次通过。若不通过，回到 5.4.6 检查你是否在某处轻信了伪代码。

---

## ⑤ 本章小结

回收本章开头的三层框架（原始视图 ↔ 推断视图 ↔ 结论，加上贯穿的导航），逐条对应正文：

**导入与分析流程（5.1）**
1. Ghidra 打开文件时做的就是第4章 4.9 的五个动作；Project→Program 模型里，你的所有修改存在 `.rep` 而**不改原文件**，故结论必须同步落到 `notes/` 与导出的文本里才能进版本控制。
2. Import 的三个决策点：Format（裸镜像必须手工指定 Loader 与加载地址）、Load Address、导入方式。
3. Auto Analyze 必开 Stack / XReferences / ASCII Strings / Call Convention ID；Aggressive Instruction Finder 默认关，只在"大量本该是指令却显示为 data"时启用。
4. 分析完先做三项体检：函数数量是否合理、**Entry Points 里有无 TLS 回调**（第4章 4.6.2 的兑现）、导入符号是否为空（空则说明导入表被破坏或隐匿）。
5. 带 `-g` 导入是**作弊模式**；真实分析必须配合 `objcopy -strip-all` 做双轨自测，用已知答案给工具和你的分析打分。

**视图与导航（5.2）**
6. 只需四个视图：Listing（绝对可信）、Decompiler（好读但会骗人）、Function Navigator、Data Type Manager。
7. 三条不变的导航肌肉记忆：`L` 看交叉引用、`F5` 反编译、`Ctrl+-` 回退。其余以右键菜单为准，别背旧版截图。
8. **交叉引用是静态分析的脊柱**，四种用法：字符串→引用→函数、API→调用点、全局变量→读写点（只看 WRITE 找"谁设置了标志位"）、函数→调用者（判断角色）。
9. Ghidra 按 `ImageBase` 显示地址而 ASLR 使运行时基址漂移，所以**记录与沟通一律用 RVA**（第4章 4.8.2 纪律的落地）。

**切入点（5.3）**
10. 优先级：**字符串 > 导入表 API > 入口点/TLS/导出 > 失败提示反推 > 结构与熵**。永远不要从入口一行行读。
11. 字符串三步链路：扫串（区分 ascii/unicode）→ 双击跳过去 → `L` 看引用 → `Ctrl+-` 回上下文。三个失效场景：串被加密、串被 strip、文字在 `.rsrc` 而非 `.rdata`。
12. 导入表分类速查能让你在读代码前就定性：`lstrcmp`/`strcmp`=直接比较最好破；`GetModuleHandleA`+`GetProcAddress` 独占=隐匿导入；`IsDebuggerPresent`=反调试；`time`/`GetTickCount`=时限题。
13. 全局变量路线兑现第2章判据：`.data`/`.bss` 里**写入点极少、读取点很多**的布尔量，几乎一定是"注册成功标志"。

**伪代码读法与怀疑（5.4）**
14. `DAT_`/`PTR_`/`undefinedN` 的密度 = 你未完成建模的程度；`switchD_` 是跳转表、`code` 是游离指令、`stack[]` 是栈变量。
15. 循环有三种还原形态，其中 `if (cond) goto 前面的LABEL` **就是循环**；多条 `goto` 汇入同一标签 = 共用出口/清理块。
16. `-O2` 的 slot reuse 会让一个栈槽承载多个变量、或把一个变量拆成多个 `uVar`；判据是**看寻址形式而非工具给的变量数**。
17. Ghidra 标的 `__cdecl` 在 x64 语境只是"默认寄存器序列"的意思，不代表 32 位 cdecl；猜错参数时用 Function Properties → Calling Convention 手工纠正，尺子是第3章 3.6.1 的清栈判据。
18. **怀疑—核对三步流程**：起疑（奇怪的 `undefined`/字符串索引/不合理运算）→ 下沉 Listing 用四抓手独立还原 → 修正输入（定类型、建结构、改约定、重命名）→ 刷新 F5。反编译质量取决于你喂给它的信息量。

**建模（5.5）**
19. **命名即思考**：起不出名字就说明还没真懂，这是最好的自检信号。
20. 结构体重建的完整链条已在本章兑现：从 `*(char*)p`、`*(int*)(p+4)`、`*(char*)(p+8)`、`*(double*)(p+0x10)` 四个访问，用第2章对齐规则推出 3 字节与 7 字节 padding，建出 `sizeof=0x18` 的结构体并应用——伪代码从数字偏移变成具名字段，**这就是"可读性跃升"的真实机制**。
21. 跳转表三种确认手段：流程图扇出数、伪代码 `switch`、手工把 `switchD_` 处定义为数组逐项跳。
22. **建模有收益递减**：只对正在追的路径建模，建到"能一句话说清这个函数干什么"就停；能写出 keygen 公式就别再美化其他函数。

**控制流与数据流（5.6）**
23. 流程图五种特征对应五种语义：≥3 扇出=switch、指回更早节点=循环、多边汇入=共用出口、**无入边的孤立节点=隐藏的第二入口（TLS/SEH/反调试）**、大面积缠绕=平坦化混淆。
24. **Trace Data Flow 是算法还原的主力**：锁定最终比较的值，反向切片自动穿过所有变换直达源头；指针类用 Trace Pointer Backward 判缓冲区边界。
25. 符号被 strip 且函数数偏少时，用 `pe_dump.py` 读 Exception Directory 的 `BeginAddress` 列表补齐（第4章 4.3.4 的兑现），差集逐个按 `P` 建函数。

**脚本与多架构（5.7–5.8）**
26. 做过三遍的动作就该脚本化。`ExportPseudo.java` 把伪代码变成**纯文本**，从而可 grep、可 diff、可进 git、可交给助手阅读——这是把一次性劳动变成可积累资产的关键；规模化用 `analyzeHeadless`。
27. 同一份 C 在 x86/x64/ARM64 下的差异集中在四点：参数去处（栈/`ECX`/`W0`）、帧建立（`push ebp`/`push rbp`/`stp x29,x30,[sp]!`）、跳转助记（`jne`/`jne`/`b.ne`）、**ARM 大立即数需 `movz`+`movk` 拼接**。
28. 跨平台场景（Android so、MIPS/ARM 固件、MCU）要注意**大端**：`0x1337` 在大端下是 `13 37`，小端下是 `37 13`（第1章 1.4 的兑现），先看 `readelf -h` 的 `Data:`。
29. 三类情况不要用反编译（非主流指令集、大量 PIC/自修改、强平坦化），直接读汇编——**第3章的手工能力是你的地板**。

**本章新留的黑盒**：伪代码只能告诉你"这里算出一个值"，**那个值到底是多少**要靠动态——第6章；运行时基址与模块视图的地址复核——第6章 + 第7章协同纪律。

下一章（第6章）我们让程序跑起来：把第3章纸面上的栈帧、标志位、调用约定变成屏幕上跳动的数值，并完成你人生第一次"改跳转"。
