# 课程修订说明 v2 · Java/LangChain4j → Python/LangGraph（面向 Java 背景的 Python 转型学习者）

> **修订日期**：应学习者要求。原 draft.json（v1，Java/LC4j 主栈）保留未动，本文件记录 v2 的全部变更，供后续章节改写对齐。

## 1. 变更总览

| 维度 | v1（原版） | v2（本版） |
|---|---|---|
| 动手主栈 | JDK21 + Spring Boot 3.5 + LangChain4j 1.20 | **Python 3.12 + LangGraph + LangChain 1.x（工具/RAG 层）** |
| 概念对照阅读 | LangGraph (Python) 只读不动手 | **LangChain4j / Spring AI (Java) 降为对照阅读**；新增 FastAPI/uvicorn 作为服务壳（薄层，带详细注释） |
| ADR-001（框架选型冻结） | LC4j 主栈、不因课程引入第二框架 | **反转**：LangGraph 主栈；理由与代价见 §3 |
| ADR-002~004 | OpenAI-compatible 逃生舱 / pgvector / Langfuse+OTel | **不变**——供应商无关抽象、pgvector、Langfuse 自托管在 Python 侧同样成立且生态更成熟 |
| 代码示例语言 | Java（record/装饰器链/Resilience4j/JUnit） | Python（dataclass·Pydantic/装饰器与中间件/tenacity·pybreaker/pytest），**除语法外均附教学性注释**（§4 规范） |
| 前置课程衔接 | goal1 第 1~5 章（LC4j 实现） | 概念全部复用，但**已完成的 ch1~ch9 讲义中的 Java 实现需按 §6 映射表重译**；goal1 的 RAG/检索结论（混合召回、ACL、评测思想）不依赖语言，直接沿用 |
| 每章新增环节 | 企业踩坑案例 | 保留，另增 **"Java↔Python 迁移笔记"** 小节（每章 ≤10 行，专治背景错位） |
| 学时 | ~202h | **~218h**（+16h：Python 工程化补课 8h 分摊进各章练习、生态迁移阅读 4h、讲义重译缓冲 4h） |

## 2. 不变的骨架（章节结构维持 9 章）

编排模式 → 工具与 MCP/A2A → 记忆与上下文 → 危险操作管控 → 评测 → 可观测性与成本 → 可靠性治理 → 整合冲刺的知识顺序**与语言无关**，九章标题、定位、踩坑案例、评测重心（57% vs 52% 市场缺口）、TicketAgent 实践载体设定全部保留。变的只是每一处"用什么实现"。

## 3. 新 ADR-001（修订版）：为什么主栈换成 LangGraph

**决策**：动手项目采用 Python 3.12 + LangGraph（编排）+ LangChain（工具/RAG 组件层）+ FastAPI（HTTP/SSE 壳）+ Pydantic（契约）。

**收益**（相对 LC4j）：
- Agent 生产化的第一梯队设施 LangGraph 原生就有：**checkpointer/interrupt**（审批挂起-恢复不再需要完整自建状态机）、**reducer**（并发写状态合并语义）、durable execution、LangSmith 深度观测（同时保留 OTel 出口）；第 2/5 章多处"LC4j 缺、需自建"的欠条直接由框架兑付，课程重心可上移到更值钱的设计判断；
- 招聘市场 agent 岗位 JD 中 Python/LangGraph 出现频率显著高于 LC4j，求职目标下曝光度更高；
- 评测/观测生态（LangSmith evals、DeepEval、promptfoo、τ-bench 复现）原生同语。

**代价与对策**（必须正视，也必须在简历里讲清）：
- **学习者的 Python 工程熟练度是真实瓶颈**——不是语法，而是虚拟环境/类型注解/asyncio/Pydantic/打包测试这些"工程母语"差异。对策见 §4/§5；
- 放弃 JVM 多年积淀的组织语境（Spring DI、Maven、线程模型）。对策：所有设计概念保留 Java 锚点类比（§4），并把"跨语言架构能力"本身升格为课程卖点——面试叙事从"为什么不选 LangGraph"翻转为"我从 Java 栈迁到 Python 栈做 agent，两边都懂，迁移成本清单我亲手做过"；
- LangGraph API 迭代快（版本锁定 + 升级回归纪律写入工程基线）。

**遗留资产处置**：已完成 ch1~ch9 的 Java 讲义不废弃——降级为"对照实现参考"，其架构决策、指标定义、案例、练习题设计全部沿用，仅实现层重译（§6 映射表指导重译次序）。

## 4. 面向 Java 背景学习者的写作规范（后续所有章节强制遵守）

1. **语法糖必须展开**：`@dataclass`、`async/await`、生成器、装饰器、`with` 上下文管理器、类型注解（`Optional/Union/Protocol`）、f-string、切片、推导式——首次出现时给一句"它等价于 Java 的什么/为什么这样设计"的括注；
2. **概念锚定 Java**：每个 Python 生态件给出对照（Pydantic≈Jackson+Bean Validation、pytest≈JUnit、poetry/uv≈Maven、tenacity≈Resilience4j Retry、FastAPI≈Spring MVC、dependency-injector≈Spring DI、contextvars≈ThreadLocal(但有正确传播语义)、asyncio event loop≈Netty 单循环多线程模型）；
3. **注释密度**：示例代码注释量约 25~40%，注释解释**工程意图与坑**（"这里为什么 await""忘 await 会怎样"），不复述语句字面意思；
4. **动态类型防御课**：每章至少一处"Java 编译器替你挡住的错，Python 里怎么活下来"的专门说明（mypy/pyright 配置、Pydantic 边界校验、duck typing 的接口纪律）；
5. **asyncio 专题前置**：Python 异步模型是全课程最大的背景错位点（Java 虚拟线程让阻塞代码"看起来同步"，Python async 是双色函数传染式的），因此在新的第 0 章集中讲透，后续章节引用之；
6. **迁移笔记小节**：每章末"Java↔Python 迁移笔记"≤10 行，记录本章出现的语言级陷阱（例：可变默认参数 `def f(x=[])`、闭包晚绑定、GIL 对 CPU 密集段的限制与 agent 场景为何基本无感）。

## 5. 新增第 0 章 · Python 工程桥接（8h，专为本次改栈而设）

不计入原九章编号，作为前置模块。大纲：
- 环境与包管理（uv/poetry、venv、pyproject.toml vs pom.xml 心智对照）；
- 类型注解 + mypy/pyright：把"失去编译器"的焦虑工程化对冲；
- dataclass/Pydantic：record 与 schema 校验的合体（agent 结构化输出的地基）；
- **asyncio 半日精读**：事件循环、await 传染性、TaskGroup、超时取消语义（`asyncio.timeout`）、与虚拟线程的模型对照表；
- pytest：fixture≈@BeforeEach、parametrize≈ParameterizedTest、conftest≈测试上下文装配；
- 装饰器与上下文管理器：读懂 LangGraph/LangChain 源码里满天飞的 `@tool`、`@entrypoint`、`with` 的语法学基础；
- 常见 Java 人写 Python 的十大反模式（getter/setter 恋物、手工 builder、忘了 with 关资源、可变默认参数…）。

## 6. 逐章变更映射（重译执行清单）

| 章 | 核心替换 | 受影响内容 | 重译优先级 |
|---|---|---|---|
| ch1 全景与心智 | 五层架构图不变；LC4j 落位表→LangGraph 落位表（StateGraph/节点/checkpointer/interrupt 归层，LangChain Runnable/Tool 归层）；docker-compose 基座复用（PG+pgvector/ollama/langfuse），仓库骨架从 Maven 多模块换 src 布局+pyproject | 1.5 表、1.7 ADR 引用、练习 3/4 | 高（ADR 措辞） |
| ch2 编排模式 | 手写 ReAct：LC4j ChatModel/ToolExecutionRequest → LangChain `init_chat_model` + bind_tools + messages 列表（原理同一张消息序列图）；计划-执行：record→Pydantic model + DAG 校验；supervisor：AgenticScope→**LangGraph State/reducer 原生承接**，自建黑板降级为"理解原理的教学实现"；agentic 四编排器速查表→LangGraph 图组合（sequence/parallel via fan-out/send/supervisor via Command） | 几乎全部代码节；2.6 对照方向翻转（改为 LC4j/Spring AI 对照） | **最高** |
| ch3 工具与 MCP | @Tool/@P→`@tool` 装饰器+docstring+Pydantic args schema；schema 生成链路重绘；ToolProvider 动态暴露→LangGraph tool node 过滤/bind_tools 子集；MCP client/server→**官方 python-sdk + langchain-mcp-adapters**（生态更成熟，实操部分重写）；错误四分类概念不变，异常类型换 Python 习惯 | 3.1~3.4 代码与 starter 名称 | 高 |
| ch4 记忆与上下文 | TokenWindowChatMemory→trim_messages/自定义 reducer；ChatMemoryStore(Redis/PG)→**checkpointer(SqliteSaver/PostgresSaver) 原生覆盖大半**，GDPR 删除仍有自建空间；长期记忆→**LangGraph Store 原生 namespace+语义检索**，自建 LongTermFact 变体；虚拟线程 ThreadLocal 一节→**contextvars 正确姿势 + asyncio 任务身份传递**（问题换了形态但同类）；ContextAssembler 预算表完全通用 | 4.1/4.2/4.4 大改，4.5/4.6 小改 | 高 |
| ch5 HITL 与沙箱 | pending_action 自建状态机→**interrupt()/Command(resume) + checkpointer 原生实现**（表设计仍展示——审批留痕与幂等列照旧，但"暂停/恢复"引擎换）；风险分级装饰器链→工具中间件/tool wrapper（概念同名）；step token/配额/dry-run 全通用；审批禁转译铁律不变 | 5.2 结构性简化（教学重点从"怎么造"移到"怎么配对语义与留痕"） | 中（工作量降，认知保留） |
| ch6 评测 | harness：JUnit ParameterizedTest→**pytest.mark.parametrize + LangSmith datasets/evaluate（双轨：自建为主、平台为辅）**；pass^k/三层模型/golden set/judge 校准全部概念不变；τ-bench 从"对照阅读"升级为"可直接跑通的公开基准"；消融矩阵代码重译 | 6.4 整节、练习 | 中 |
| ch7 观测与成本 | OTel GenAI semconv 不变；埋点位 ChatModelListener→**callbacks/instrumentation（LangChain 原生 OTel 导出 + LangSmith 双写）**；span 层级设计原则原样保留；Micrometer→prometheus_client/OpenTelemetry SDK；三级核算/两红线/采样策略通用 | 7.2 胶水层代码、练习 2/3 | 中 |
| ch8 可靠性 | Resilience4j→**tenacity(重试)+pybreaker/circuitbreaker(熔断)+asyncio.timeout/TaskGroup(超时取消)+anyio semaphore/bulkhead**；幂等/去重表/saga/progress 扫描全通用（SQL 不变）；SSE 断连止损→FastAPI StreamingResponse + request.is_disconnected + task cancel（语义更顺）；k6 剧本不变 | 8.1/8.5 代码、混沌注入工具 | 中 |
| ch9 整合 | DoD 清单换验收命令（uv run pytest -m eval、docker compose up）；README/ADR/简历 bullet 技术栈字样替换；跨框架论述表三列权重调整（LangGraph 主位、LC4j/Spring AI 成为"我会两种栈"的证据）；投递节奏不变 | 9.2~9.4 | 低（文字替换为主） |

**重译次序建议**：ch2 → ch3 → ch4 → ch5 →（ch1 局部补丁）→ ch6 → ch7 → ch8 → ch9。每章重译后保留原 Java 版关键片段作折叠附录（`<details>` 块），供对照复习与"两栈皆通"的面试素材。

## 7. draft.json 是否回写？

当前仅落此说明文件，**未改动 draft.json**。若确认按 v2 执行，下一步将更新 draft.json 的 overview/chapters（主栈表述、est_hours 微调、focus_points 中框架名词替换），并逐章重写 chapters/*.md。
