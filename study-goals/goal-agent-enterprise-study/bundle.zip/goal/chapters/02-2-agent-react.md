# 第 2 章 · Agent 编排模式：ReAct、计划-执行与多智能体

> **课程**：面向生产环境的 AI Agent 工程（Java / LangChain4j 实战）
> **前置**：第 1 章（五层架构视图、生产三特性）；goal1 第 2 章（`ChatModel`/`@AiService`/`ChatMemory`）、第 5 章（权限过滤）
> **建议学时**：30 小时
> **本章定位**：全课程的核心骨架。上一章你建立了"什么时候该用 agent"的判断力，这一章解决"决定要用之后，控制流到底长什么样"。三种主流编排模式——**ReAct、计划-执行、supervisor 多智能体**——全部在 TicketAgent 仓库上手写一遍，再对照框架内置能力，最终目标是建立一张刻在脑子里的**选型决策表**：每种模式会怎么输、什么时候不该用它。

---

## 本章学习目标

1. **手写 ReAct 循环**：用低层 `ChatModel` + `ToolExecutionRequest` 显式管理 Thought/Action/Observation 消息序列，实现终止条件、最大迭代数与 token 预算三重熔断；能诊断"模型反复调同一工具"的三类根因并对症下药；
2. 说清 **LC4j `AiServices` 自动工具循环替你做了什么**，以及哪些生产需求（超时注入、审计埋点、中途取消、护栏介入）会逼你拿回控制流；
3. 实现**计划-执行（plan-and-execute）**分离：planner 产出结构化步骤（映射为 Java record）、executor 逐步消费、replan 有明确触发条件；掌握它与纯 ReAct 在成本/质量/可测性上的三方权衡；
4. 在 TicketAgent 上落地 **supervisor-worker 多智能体**（分诊 → 查询/退款/升级子 agent），设计上下文隔离与共享状态传递；能识别"多 agent 只是把单体复杂度挪到通信协议上"的反模式；
5. 掌握 LC4j Agentic Services（`langchain4j-agentic` 模块：sequence/loop/parallel/supervisor/custom workflow）的**聚合语义与失败传播规则**，并知道何时应放弃框架编排、自写状态机；
6. 完成 LangGraph 概念对照：StateGraph/节点/条件边/interrupt/checkpoint ↔ LC4j 的什么、缺的是什么；准备好面试被问"为什么不直接用 LangGraph"时的完整答案；
7. 通过报销系统踩坑案例，理解 **worker 间自然语言传参的精度风险**，确立"agent 间通信必须是结构化契约"的工程纪律。

---

## 2.1 全景图：四种控制流形态

先把本章要走的路线摆出来。按"决策权交给模型多少"排序，是一根光谱：

```
决策权 ←──────────────────────────────────────→ 决策权
在代码手里                                        在模型手里

固定流水线        计划-执行          ReAct          supervisor 多agent
(sequential/     (planner 一次       (每步都由       (supervisor 动态
 parallel         规划出步骤，        LLM 决定)        分派给专家 worker，
 workflow)        executor 照单执行)                  worker 内部各自是 agent)
 goal1 已覆盖      本章 2.4           本章 2.2/2.3     本章 2.5
```

一个关键观察：**计划-执行是中间态**——它把"规划"这个全局决策一次性交给模型，把"执行"退回确定性代码。理解了这一点，三种模式的取舍逻辑就通了大半。

各模式的"会输在哪里"先立靶子（本章后面逐一兑现）：

| 模式 | 典型失败方式 | 对应小节 |
|---|---|---|
| ReAct | 死循环、轨迹漂移不可测、每轮成本递增 | 2.2/2.3 |
| 计划-执行 | 计划赶不上变化（基于错误假设规划到底）、planner 幻觉出不存在的工具步骤 | 2.4 |
| 多智能体 | 上下文在交接处丢失/失真、复杂度转移成通信协议税 | 2.5 |

---

## 2.2 手写 ReAct：把黑盒拆开给自己看

### 2.2.1 ReAct 是什么

ReAct = **Reasoning + Acting**（Yao et al., 2022）。纸面形式是让模型每轮输出：

```
Thought: 我需要先查工单状态才能决定下一步
Action: getTicket
Action Input: {"ticketId": "T-1024"}
Observation: {status: OPEN, priority: P3, warehouse: WH-3}   ← 你的代码回填
Thought: P3 但客户催办，需要查库存确认能否走换货……
...
Final Answer: ...
```

现代 function calling 模型不再靠文本解析——模型 API 直接返回结构化的 `tool_calls`，你的代码把它转成 LC4j 的 `ToolExecutionRequest`。**Thought 变成了模型的推理内容（或干脆没有），Action 变成真实的工具调用，Observation 变成你塞回消息列表的 `ToolExecutionResultMessage`。** 骨架没变，只是从"求模型按格式说话"升级为"API 级契约"。

### 2.2.2 消息序列就是控制流

手写循环前，先看清一轮迭代里 `messages` 列表如何生长（这是本节最重要的图）：

```
[system]   你是工单助手…… + [tools schema: getTicket, createTicket, checkInventory]
[user]     T-1024 升级到 P1，顺便看看仓库还有没有货
[assistant] tool_calls: [getTicket(T-1024)]                    ← 模型的第 1 次决策
[tool]     {status:OPEN, priority:P3, warehouse:WH-3}          ← 你执行后回填
[assistant] tool_calls: [updatePriority(T-1024,P1), checkInventory(WH-3)]  ← 并行 2 个
[tool]     {ok:true}
[tool]     {stock: 42}
[assistant] (无 tool_calls，携带文本)                           ← 模型判定任务完成
```

要点：

1. **每一轮请求都包含全部历史**——这就是第 1 章说的成本乘性放大的物理来源；
2. **"结束"不是一个信号而是"这一次没再要工具"**——你的循环退出条件是 `!response.aiMessage().hasToolExecutionRequests()`；
3. assistant 的 tool_calls 消息和对应的 tool 结果消息**必须成对出现且顺序正确**地追加进历史，多数 OpenAI-compatible 网关会对乱序/孤儿 tool 消息直接报 400——新手手写循环的第一号 bug。

### 2.2.3 核心实现（LC4j 低层 API）

```java
public class ReActLoop {

    private final ChatModel model;
    private final ToolRegistry registry;      // name -> (spec, executor)
    private final LoopPolicy policy;          // 熔断策略，见下文

    public String run(String userText) {
        List<ChatMessage> messages = new ArrayList<>();
        messages.add(SystemMessage.from(systemPrompt));
        messages.add(UserMessage.from(userText));

        var toolSpecs = registry.specifications();
        Budget budget = new Budget(policy.maxTokens());   // 本地 token 计数器

        for (int turn = 1; turn <= policy.maxTurns(); turn++) {
            ensureBudget(budget, policy.perRequestTimeout());   // ① 事前熔断

            ChatResponse resp = model.chat(ChatRequest.builder()
                    .messages(messages).toolSpecifications(toolSpecs).build());
            budget.add(resp.tokenUsage());                       // 累计花费

            AiMessage ai = resp.aiMessage();
            messages.add(ai);
            if (!ai.hasToolExecutionRequests()) return ai.text(); // ② 正常终止

            for (ToolExecutionRequest req : ai.toolExecutionRequests()) {
                String result = executeWithGuard(req, turn);      // ③ 唯一执行出口
                messages.add(ToolExecutionResultMessage
                        .from(req.id(), req.name(), result));
            }
        }
        // ④ 强制终止：迭代耗尽
        return escalateToHuman("达到最大轮数 " + policy.maxTurns()
                + "，最后一条助手消息: " + lastAiSummary(messages));
    }
}
```

注意三个编号点对应的三条**独立**熔断线，缺一不可：

```java
public record LoopPolicy(
    int maxTurns,              // 轮数上限（工单场景经验值 5~8）
    long maxTotalTokens,       // 单次任务的 token 硬顶
    Duration perRequestTimeout,// 单次 LLM 调用超时
    Duration totalDeadline,    // 整个任务的端到端预算
    int maxConsecutiveSameTool // 同一工具连续调用次数上限 —— 防踱步
) {}
```

`maxConsecutiveSameTool` 值得单独解释：模型在第 4 轮和第 9 轮各查一次同一工单是合理行为，但**连续**两三遍拿同样参数查同一个东西，几乎必然是陷入了自我怀疑循环——这是最便宜也最有效的死循环探测器。

### 2.2.4 工具执行侧：错误语义是你的第一次架构决策

`executeWithGuard` 里有一个立刻要做出的选择——工具抛异常时，往 `messages` 里回填什么？

```java
private String executeWithGuard(ToolExecutionRequest req, int turn) {
    audit.record(req, turn);                          // 埋点：谁、第几轮、什么参数
    try {
        Object out = registry.executor(req.name()).execute(req.arguments());
        return jsonCodec.toJson(out);                 // 成功：结构化结果
    } catch (ValidationException e) {
        return jsonCodec.toJson(Map.of(               // 可修正错误：回填给模型
            "error", "INVALID_ARGUMENT",
            "detail", e.getMessage(),                 // 例："priority 必须是 P1-P4"
            "hint", "请修正参数后重试"));
    } catch (BusinessException e) {
        return jsonCodec.toJson(Map.of(               // 业务性失败：给出路而非死胡同
            "error", "NOT_FOUND",
            "detail", e.getMessage(),
            "advice", "请告知用户工单不存在，不要重试"));
    } catch (Exception e) {                            // 系统性故障：别污染模型
        throw new FatalToolException(req.name(), e);   // 快速失败，跳出循环
    }
}
```

四条经验法则（第 3 章还会深化，这里先建立肌肉记忆）：

- **参数校验类错误回填给模型**，它有修正能力，且这比你在外面猜它意图再重跑便宜；
- **业务性失败要给 `advice`**——告诉模型此路不通的正确姿势是"告知用户"，否则它会自己发明出路（常见的是换个参数碰运气）；
- **系统性故障（超时、连接池耗尽）不要回填**——让模型看到一堆基础设施报错，它要么开始道歉复读要么继续重试烧钱，直接抛出走降级路径（第 8 章）；
- **错误信息本身是指令面**：回填给模型的字符串来自外部系统，可能被注入攻击利用（第 3/5 章），生产上要做模板化白名单，不裸传异常栈。

### 2.2.5 诊断"模型反复调同一工具"：三类根因

这是 ReAct 运维中出现频率最高的坏味道。`maxConsecutiveSameTool` 只能兜住后果，修因要靠分诊：

| 根因 | 症状特征 | 处方 |
|---|---|---|
| **① 工具描述歧义** | 选错工具或反复试探：两个工具描述语义重叠（`getTicket` vs `queryTicketDetail`）；描述里没说清输入输出边界 | 重写描述：动词开头、写明互斥关系、给一个使用示例；工具数量收缩（第 3 章的工具规模治理） |
| **② 结果不满意但不满的方式说不出口** | 同参数反复调用，每次 Observation 相同：返回值缺了它需要的字段，它怀疑是自己拿错了 | **改工具返回值而不是改 prompt**：让返回结构自解释（带 `status` 枚举含义、空结果的显式 `reason` 字段）；这是最高频真因 |
| **③ 缺少停止信号** | 任务其实已完成，但 system prompt 没说"何时可以收口"，或存在多个未决子目标互相拉扯 | 在 prompt 中显式定义完成标准（"拿到 X 且回答包含 Y 即可结束"）；必要时提供 `finish(answer)` 终结工具，把"宣布完成"变成一个显式动作 |

> **误区预警**：90% 的人第一反应是加一句"不要重复调用工具"到 prompt 里。没用——模型不是故意重复，是它的信息世界里"再来一次"是当前最优解。**永远优先改工具契约，其次才是 prompt。**

### 2.2.6 类比：这不就是状态机吗

多年后端经验的你会越写越眼熟：`for` 循环 + 消息列表 + 分支退出 = 一个**以 messages 为状态的隐式状态机**。区别只在于转移函数由 LLM 概率性地给出。这个视角在第 2.6 节读 LangGraph 时会带来顿悟——LangGraph 不过是把这个隐式状态机**显式化**成了图 DSL。

---

## 2.3 框架替你做了什么：AiServices 自动工具循环的得与失

写完手写循环，再看 LC4j 高层 API。给 `@AiService` 接口挂上工具后：

```java
interface TicketAgentService {
    @SystemMessage("你是工单助手……")
    String chat(@MemoryId String sessionId, @UserMessage String text);
}

var agent = AiServices.builder(TicketAgentService.class)
        .chatModel(model)
        .chatMemoryProvider(id -> TokenWindowChatMemory.withMaxTokens(4000))
        .toolProvider(toolProvider)          // 静态 tools() 或动态 provider
        .executionCalculator(reqs -> Duration.ofSeconds(20))  // 工具执行超时
        .build();
```

框架内部跑的正是你 2.2 刚写的那个循环（拉工具 spec → 发请求 → 反射执行 `@Tool` → 回填结果 → 再发请求……）。**声明式的收益巨大**：少写 200 行、天然兼容 streaming/RAG/结构化输出。那什么时候它不够用？

| 生产需求 | AiServices 内置支持 | 缺口与对策 |
|---|---|---|
| 轮数/token 预算熔断 | ❌ 默认无迭代上限保护（依赖模型自觉停止） | listener 里累计计数 + 超限抛异常中断；或降级到手写循环/自定义 handler |
| 工具执行超时 | ✅ `executionCalculator` 可按工具配置 | 够用，但超时后的错误文案仍受默认语义控制（见下） |
| 错误语义定制（2.2.4 的四分类） | ⚠️ 部分：`ToolExecutor` 返回值可控，但同步/异步路径的默认行为有差异（执行异常 vs 参数解析异常的处置不同，版本相关） | 把处置逻辑收敛进自己的 `ToolExecutor` 包装器，不依赖框架默认 |
| 审计埋点（谁在哪轮调了什么） | ⚠️ `ChatModelListener` 可见每轮请求/响应，但"第几轮"要自己维护关联 | listener + trace_id 方案在第 7 章统一落地 |
| HITL：高危工具挂起等审批 | ❌ 无此原语 | 工具返回 pending 状态 + 会话外状态机恢复（第 5 章整章展开） |
| 中途取消（客户端断连止损） | ⚠️ 非阻塞路径可取消 future，但要保证上游请求一并停 | 第 8 章流式韧性处理 |

结论公式：

> **AiServices = 你的手写循环去掉所有"生产钩子"之后的样子。** 教程止步于此；生产的差异恰恰是那些钩子。

两条实践路线都合法：**A. 高层起步 + 包装器补钩子**（`ToolExecutor` 装饰器链：audit → guard → idempotency → actual，日常推荐）；**B. 低层手写 + 复用组件**（需要完全控制消息序列的高级模式：动态 replan、轨迹级评测回放、跨供应商 diff）。本课程要求你 A/B 都实现——先 B（2.2 已完成一半）再 A，比较两者的代码差异本身就是练习。

---

## 2.4 计划-执行：把"想清楚"和"干活"分成两次决策

### 2.4.1 动机：ReAct 的"近视"问题

ReAct 每一步只看当前上下文做局部最优决策，副作用有二：

1. **轨迹漂移**：同一任务两次运行可能走完全不同的路——第 1 章实验你已经亲眼见过。对可测性是灾难；
2. **lost-in-the-middle 加剧**：第 8 轮的模型要从前 7 轮噪声里自己重建"我最初要干嘛"，经常重建歪。

计划-执行的解法：**让模型在信息最干净的时刻（第 0 轮，只有任务描述）做一次全局规划，把这份规划固化成代码可校验的结构，执行阶段逐条照办。**

### 2.4.2 Planner 输出必须是 Java record，不是散文

```java
public sealed interface Step {
    record CallTool(String tool, Map<String,Object> args, String bindsTo) implements Step {}
    record ReasonFrom(String contextKeys, String instruction, String bindsTo) implements Step {}
    record AskUser(String question) implements Step {}
}

public record Plan(List<Step> steps, String successCriteria) {}
```

用 LC4j 结构化输出（`Result<Plan>` + JSON schema 约束，goal1 第 2 章技能直接复用）拿到 plan 后，**先过三道静态校验再执行**——这一步是计划-执行模式的全部精髓：

```java
Plan plan = planner.plan(task);
validator.check(plan);   // ① 所有 CallTool.tool ∈ 注册表白名单
                          // ② args 满足该工具的 JSON Schema（类型/必填/枚举）
                          // ③ DAG 校验：bindsTo 引用不得成环、不得引用未来步骤
```

Planner 幻觉出一个不存在的工具名或非法参数？**在零成本的校验层拦下，而不是在执行层让 400 错误教育你。** 校验失败的处理是把具体错误回填给 planner 重规划一次，再失败则降级为 ReAct 或直接人工。

对比一下两种模式下"工具名幻觉"的发生位置：ReAct 里它在第 N 轮的花费是 N 轮 token；plan-and-execute 里它在第 0 轮的花费是一次规划调用。**错误越早暴露越便宜**——这条原则贯穿到第 6 章的 CI 门禁。

### 2.4.3 Executor 与 replan：什么时候允许推翻计划

执行器就是遍历 `plan.steps()` 的顺序消费者：`CallTool` 走 2.2.4 的执行+错误回填逻辑；`ReasonFrom` 才真正调 LLM（只喂绑定的上下文键，不喂全轨迹——这也是省 token 的大头）。

关键是**什么时候允许偏离计划（replan）**。无脑"每步失败都重规划"会让成本回到 ReAct 甚至更高。触发条件应该是白名单化的：

```java
enum ReplanTrigger {
    STEP_FAILED_UNRECOVERABLE,  // 步骤遭遇不可修正失败（工具下线/数据不存在）
    PLAN_STALE,                 // 世界变了：如 step2 发现工单已被他人关闭，step3 的升级失去意义
    BUDGET_OK                   // 且剩余预算足够支撑一次 replan（硬前提！）
}
```

配套纪律：**replan 次数设上限（通常 1 次）**，且 replan 时把"已完成步骤的摘要 + 失败原因"作为新规划的输入，而不是从头再来。

### 2.4.4 三方权衡表（面试标准答案骨架）

| 维度 | 纯 ReAct | 计划-执行 | 分析 |
|---|---|---|---|
| 成本 | 随轮数增长，均值高、方差大 | 规划 1 次 + 执行步近似线性 + 偶发 replan | 任务步数越多、越可预见，P&E 越省；步少且短的任务 P&E 反而多付一次规划费 |
| 质量 | 灵活纠错，擅长探索型任务 | 全局一致性好，但**基于错误前提的计划会一路执行到底** | 环境反馈丰富的任务（诊断类）偏 ReAct；流程清晰的复合任务（报表生成、多系统操作）偏 P&E |
| 可测性 | 轨迹不确定，只能性质断言 | plan 本身可断言（步骤集合/顺序/schema 合法率） | **P&E 把一半随机性推出了执行路径**，回归测试友好得多 |
| 延迟 | 每轮串行依赖前轮 | 计划在手，无依赖步骤可并行 | 结合 parallel executor 优势明显 |

> **什么时候不该用计划-执行**：任务本质是探索（不知道要几步）、或第 1 步的结果会颠覆性地改变问题定义（"帮我查查这个服务为什么慢"——查到一半发现是另一个服务的事）。强行规划 = 让模型装作它懂。

---

## 2.5 多智能体：supervisor-worker 与它的复杂度税

### 2.5.1 为什么会有人需要多个 agent

单个 agent + 20 个工具 + 5 页 system prompt 的退化路径几乎必然发生：工具选择准确率下降、prompt 里规则互相打架、一处修改处处回归。拆分逻辑是经典的**关注点分离**：

```
                 ┌─ QueryAgent   （只读工具×3，宽松预算，快模型）
用户请求 → 分诊 Supervisor ─├─ RefundAgent  （写工具×2，小金额上限，强模型+严格护栏）
                 └─ EscalateAgent（话术生成，不调工具）
```

三个真实收益来源：**上下文瘦身**（每个 worker 只看到自己领域的工具与指令）、**风险分区**（危险工具只注册给受控 worker——这是第 5 章权限设计的前置）、**模型分级**（分诊用小模型，退款判断用大模型，成本立省）。

### 2.5.2 在 TicketAgent 上落地

分诊层的正确实现往往**不是 agent**——意图分类是单次结构化输出调用（映射为 enum），路由是代码 switch。这不是偷懒，是第 1 章原则的执行："supervisor 的自主性预算应该花在其 worker 管不到的全局判断上"。只有当分诊本身需要查资料才能定夺时才给它工具。

worker 间协作的数据面设计是本节重点。反面做法 vs 正确做法：

```java
// ❌ 反面：自然语言接力（2.7 案例的原罪）
String summary = queryAgent.chat("总结一下 T-1024 的情况");
refundAgent.chat("根据以下情况处理退款：" + summary);   // 金额?币种?小数位?全凭转述

// ✅ 正确：结构化契约 + 只读黑板
record TicketFacts(String ticketId, BigDecimal refundableAmount,
                   Currency currency, OrderStatus status, Instant asOf) {}

class SharedBlackboard {                    // 即 LC4j AgenticScope 的手工版
    private final Map<String, Object> typedStore;
    <T> void write(String key, T value);    // 写入即校验类型
    <T> T read(String key, Class<T> type);
}
// supervisor 把 facts 的引用传给 worker；worker 输出的也是 record；
// 只有面向用户的最终文案才允许是自由文本。
```

规则一句话：**agent 之间传引用和事实，不传转述；LLM 生成的散文只允许出现在与人交互的边界上。**

### 2.5.3 反模式自检："复杂度搬家"

引入多 agent 前先做这个思想实验：把你原本要塞进单 prompt 的规则和要挂的工具，列一张清单。如果拆完之后，清单没有变短、只是从"prompt 里的规则"变成了"supervisor 的路由规则 + worker 间的契约定义 + 交接失败的兜底处理"——**你没有消除复杂度，只是把它从单体内部挪到了进程内的通信协议上**，而且新协议还没有编译器帮你检查（自然语言契约尤其如此）。

多 agent 的正当理由只有三种：**上下文窗口物理装不下、风险等级必须隔离、模型档位需要混用**。三者都不是，就用单 agent。

### 2.5.4 LC4j Agentic Services 速查：聚合语义与失败传播

`langchain4j-agentic` 模块（**官方标注 experimental，版本升级需回归验证**）提供了这套原语，与 2.5.2 手工版一一对照：

| 编排器 | 数据面 | 聚合语义 | 失败传播（重点背） |
|---|---|---|---|
| `AgenticServices.agentBuilder(X.class)` | `outputKey` 写入 `AgenticScope`；入参 `@V` 从 scope 读取 | 单 agent，等价于带共享变量的 AiService | 异常直接上抛 |
| `sequenceBuilder()` | 前序 `outputKey` 是后序输入；同名 key 会被**覆写**（文档示例里三个 agent 共用 `"story"` 逐级改写） | 最终输出取 sequence 自己的 `outputKey` | **任一子 agent 抛异常 → 整个 sequence 中断上抛**，无内置补偿 |
| `parallelBuilder()` | 并发执行子 agent，各写各的 outputKey | join 全部完成后一起可读 | 默认**任一失败拖垮整体**；`joinTaskResults(false)` 改为收集 `Map<key, CompletableFuture>` 自行处置部分失败 |
| `loopBuilder()` | `exitCondition` 是 `Predicate<AgenticScope>`（可读 `readState`），可 `testExitAtLoopEnd`，配 `maxIterations` | 迭代直到条件满足 | 子 agent 异常上抛；**maxIterations 必设**，否则条件永不满足即死循环 |
| `supervisorBuilder()` / `routerBuilder()` | supervisor 持有子 agent 的 description 做动态选择；router 走 `@Agent(action="X")` 注解匹配 | 选中者执行 | 路由不中/子 agent 失败均需自带兜底 |
| `SimpleWorkflowAgent`（custom） | `.next(a,b)` `.parallelExecutions(...)` `.conditionalExecutions(p, ...)` 组合 | 自定义图 | 组合语义自行保证 |

三个工程判断：

1. **`AgenticScope` ≈ LangGraph 的 State，但弱一档**：它是无类型的 `Map<String,Object>`——没有 per-key reducer（并发写同名 key 竞态谁赢未定义）、没有 checkpoint 持久化。跨重启恢复会话、时间旅行调试这些能力都要自建；
2. **失败传播默认全是"一损俱损"**。生产上你多半想要部分失败语义（三个 worker 挂了退款那个，其余结果照常交付+显式降级文案），这需要 `joinTaskResults(false)` 级别的手动接管或者干脆 custom workflow；
3. **何时放弃框架编排自写状态机**：当你需要（a）审批挂起/恢复这类跨请求生命周期（第 5 章必然撞上）、（b）持久化中间状态以支持重启续跑、（c）轨迹级的确定性回放测试（第 6 章评测需要）——这三件事任何一件占大头，自写的收益就超过框架便利。框架负责让你快，你的状态机负责让你稳。

---

## 2.6 LangGraph 对照阅读：术语映射与那个必被问的问题

> 本节为**阅读作业**（ADR-001：Python 只做概念对照，不动手部署）。材料：LangGraph 官方 docs 的 Workflows & agents、Graph API essentials、Persistence 三页。

### 2.6.1 术语映射表

| LangGraph 概念 | 本质 | LC4j 对应物 | 差距备注 |
|---|---|---|---|
| `StateGraph` | 把 agent 逻辑显式建模为（节点+边+共享 State schema）的图 | `SimpleWorkflowAgent` 的 next/conditional 组合 | LG 的图是声明式一等公民；LC4j 更接近命令式拼装 |
| Node 函数 | 干活的单元（可以是 LLM 调用或纯代码） | 一个 agent bean / `@Tool` 方法 | — |
| Conditional edges | 由上一节点输出决定下一跳的路由函数 | router 的 action 匹配 / custom workflow 的 `conditionalExecutions` / 你手写的 switch | LC4j 无集中式图定义，路由散落在代码各处——小项目无所谓，大图难 review |
| Send / map-reduce | 运行时动态 fan-out 不定数量任务 | `parallelBuilder` 只能静态并行 | LC4j 缺动态扇出原语 |
| Checkpointer（thread 概念） | **每步之后自动快照 State，可恢复/可时间旅行** | ❌ 无。ChatMemory 持久化的是消息历史，不是编排状态 | 这是两框架最大的架构差；第 5 章 HITL 恢复全靠它，LC4j 侧必须自建 |
| `interrupt` | 图中暂停等人、批准后从断点继续 | ❌ 无原生原语，需工具返回 pending + 外置状态机模拟 | 同上 |
| reducers | 并发节点写同一 state key 时的合并函数 | ❌ AgenticScope 无类型无 reducer | 竞态要自己防 |
| Command（goto+update） | 节点返回值同时决定"更新什么"和"跳去哪" | 相当于你循环里的 return/break 语义 | 概念可迁移 |

读 LangGraph 的正确姿势不是学语法，而是**用它照出 LC4j 缺什么**：上表四个 ❌ 就是你未来两个月要亲手补齐的生产设施（checkpoint→第 5 章审批状态机，reducer→第 4 章并发上下文）。

### 2.6.2 面试题预演："你们为什么不用 LangGraph？"

三层递进的标准答案（第 9 章还会打磨措辞）：

1. **组织适配层**：团队是多年 Spring/JVM 栈，agent 服务要和现有鉴权（SecurityContext）、事务、监控体系同进程集成；引入 Python 意味着跨语言运维两套 CI、值班链路割裂——ADR-001 评估过并冻结；
2. **能力对账层**：LangGraph 领先的 checkpoint/interrupt/reducer 三项，恰好是我们识别出的生产刚需，因此在 LC4j 上用显式状态机+持久化审批表自建（展示你对"缺什么"的清醒），而 LC4j 的强项是 Idiomatic Java、编译期类型、Spring Boot starter 生态；
3. **认知层（加分项）**：编排模式的正确性与框架无关——ReAct/P&E/supervisor 在任何框架都是那三件套；框架差异集中在状态持久化与图表达力，这属于可替换的基础设施细节。**"我们不是在两个框架间选宗教，是在两组架构属性间做权衡，并且把劣势项列成了待建清单。"**

---

## 2.7 企业踩坑案例：自然语言传参弄丢两位小数的报销系统

> 案例基于公开事故复盘与社区报告的合成改写，模式真实，细节已脱敏。

**背景**：某财务 SaaS 公司的智能报销审批系统，采用当时最"先进"的架构：supervisor 分诊 + 三个 worker（票据 OCR agent、合规审查 agent、打款执行 agent），全部用 LC4j AiServices 实现。worker 间协作方式是"把上一个 agent 的回答作为下一个的输入"——反正都是文本，接口最简单。上线前 demo 惊艳：员工拍发票照片，说一句"帮我报了"，全流程自动跑通。

**事故**：上线第 3 周，财务对账发现 4 笔打款金额与报销单不符，差额均为几十元级别——单笔不大，但性质是**资金错付**，触发合规上报流程。

**排查**（花了整整一周，因为没有任何一处代码"处理过金额出错"这个概念）：还原 trace 后发现链条是这样的：

```
OCR agent 输出:  "总金额 ¥1,234.56，其中交通 890.00、餐饮 344.56"
合规 agent 输出: "审核通过，可报销金额约 1234.5 元"        ← 四舍五入发生在转述里
打款 agent 参数:  amount="1234.5" → 实际入账 1234.50 没问题
另一单更糟:      "合计壹仟贰佰叁拾肆圆伍角陆分" 被下游模型解析成 1234.56 → 
                 但同批次的另一张票金额被合并转述时漏掉了尾差 0.06
```

根因：**每一跳的自然语言转述都是一次有损压缩**。中文数字、千分位、"约"字、多票合并——LLM 在转述时对金额的忠实度没有任何保证，而系统在每一跳都把这坨散文重新 parse 成数字，误差沿链累积。讽刺的是，最初的 OCR 结果里金额是对的。

**加重因素**（复盘会上真正的火力点）：

- 打款 agent 的输入校验器只检查"amount 是合法数字"，从不与源头 OCR 记录做**交叉核对**——防线形同虚设；
- supervisor 的 prompt 里写着"确保金额准确"——一条软约束被当成了硬保障（第 1 章教训的回声）；
- 三跳之间没有任何结构化契约，**测试团队根本没法为"交接"写用例**，因为交接物是散文。

**修复**：

1. **worker 间通信全面结构化**：定义 `ExpenseClaim` record（`BigDecimal amount`、`Currency`、`sourceDocumentIds`），JSON Schema 约束 LLM 输出并反序列化校验，schema 不过直接拒绝进入下一跳；金额字段打上"禁转述"标记——**任何 agent 的输出模板里不允许出现对该字段的自然语言复述，只允许透传引用**；
2. **数值不变量校验**：打款前执行 `assert claim.amount == sum(ocrItems.amount)`，用 `BigDecimal.setScale(2, HALF_EVEN)` 统一精度语义；不等则挂起转人工；
3. **打款工具强制幂等键**（claimId 派生），杜绝修复过程中担心的重复打款；
4. **为每跳契约补 golden test**：构造含中文大写金额/千分位/多票合并的对抗样本进评测集（这批样本后来成为他们第 6 章式评测体系的种子数据）。

**结果**：改造后 6 个月零资金差错；更重要的是，结构化契约使轨迹评测成为可能——修复前他们连"agent 到底哪一步错的"都无法自动化回答。

**带走的三条纪律**：

1. **精度敏感字段（金额/数量/ID/日期）禁止穿越自然语言通道**——要么全程结构化透传，要么传引用；
2. **每个 agent 间边界都值得一个校验器**，其成本远低于对账团队一个月的加班；
3. 本案例是 2.5.3"复杂度搬家"的具体形态：多 agent 把单体的 prompt 复杂度搬走了，但如果不做契约设计，搬来的是**语义失真**这种更难查的新复杂度。

---

## 动手练习

> 继续在 TicketAgent 仓库，`chapter02` 分支。三件套 mock API（`getTicket`/`createTicket`/`checkInventory`）+ 第 5 章预告用的 `updateTicketPriority` 作为本次实验工具面。

**练习 1 · 手写 ReAct 完整闭环（6h）**
基于 2.2.3 骨架完成 `ReActLoop`：三重熔断全部生效；错误回填按 2.2.4 四分类实现；单元测试用 mock ChatModel 脚本化三种剧本（正常收敛 / 连续同工具踱步 / 参数幻觉后自我修正），断言各自的退出路径与消息列表形状。**额外要求**：故意用真实模型跑一个诱导踱步的坏例子（比如让 `getTicket` 返回值缺一个 obviously 需要的字段），观察并记录它落入 2.2.5 的哪类根因、你的 `maxConsecutiveSameTool` 在第几轮救场。

**练习 2 · 双轨对比：手写 vs AiServices（4h）**
同一组 10 个测试任务分别跑练习 1 的手写循环和 AiServices 自动循环：记录轨迹一致性（10 次运行几种路径）、总 token、失败样本的处置差异；然后给 AiServices 侧加上 `ToolExecutor` 装饰器链补齐审计与错误分类。产出 `docs/ch02/handwritten-vs-aiservices.md`，用一段话回答："什么时候你愿意养两套代码？"

**练习 3 · 计划-执行改造（5h)**
实现 `PlannerAgent`（结构化输出 `Plan` record）+ `StaticValidator`（三道校验）+ `PlanExecutor`（含 `ReasonFrom` 的窄上下文调用）。设计 5 个任务（含一个"计划必然过时"的陷阱任务：执行中途 mock 数据被测试脚本改掉），验证 replan 触发器的白名单行为是否如预期。统计并与练习 1 对比：同样的 10 个任务，P&E 相对 ReAct 的成本/轮数/轨迹一致性变化。

**练习 4 · supervisor 多智能体 + 契约化（6h）**
搭建分诊（单次 enum 分类调用）→ QueryAgent/StockAgent/EscalateAgent 三 worker 的系统：worker 间用 `TicketFacts` record 经自建 `SharedBlackboard` 传递；随后用 `langchain4j-agentic` 的 `supervisorBuilder`/`sequenceBuilder` 复刻同一系统，对比两者代码量与失控行为差异。**对抗测试**：构造一笔金额为 `1234.565` 的数据流经全系统，证明你的契约设计不会像 2.7 案例那样丢精度（断言出口 `BigDecimal` 逐位相等）。

**练习 5 · 选型决策表（2h）**
不看书写一张表：四种形态（单工具循环 ReAct / P&E / supervisor 多 agent / 混合）× 六列（适用任务特征、成本曲线、可测性、典型失败模式、切换到此模式的信号、**不该用的信号**）。用第 1 章练习 2 的 5 个真实场景套一遍这张表。这张表是你第 6 章消融实验的假设清单，也是面试白板题的弹药库。

**练习 6 · LangGraph 对照笔记（3h，阅读）**
精读 LangGraph 文档三页（2.6.1 所列），把其 quickstart 的 ReAct 示例逐行翻译为"这在 LC4j 里是哪一行/哪个缺失"；重点回答一个问题并写成 200 字以内论述：**"如果给你的 supervisor 加上 interrupt + checkpointer，你的第 5 章审批设计会变成什么样？"**——带着这个问题进入下一章。

**练习 7 · 成本日志（贯穿）**
以上所有真实模型运行的 token 消耗记入 `docs/cost-log.csv`（日期/实验/模型/轮数/总 token/估算费用）。第 7 章的可观测性建设将从"手动记账的痛苦"讲起。

---

## 本章小结

- **ReAct 的祛魅**：它就是"以 messages 为状态的隐式状态机"。手写一遍的价值不在替代框架，而在于从此你看任何 agent 框架的源码都不再有秘密——循环、消息配对、终止判定，仅此三件事。三条熔断线（轮数/token/连续同工具）是活下来的底线。
- **反复调工具 ≠ 模型犯傻**：三类根因（描述歧义/返回值欠自解释/缺停止信号）里，改**工具契约**的收益远大于改 prompt。
- **AiServices 的真相**：它是去掉了生产钩子的你。超时之外的一切——预算熔断、错误语义定制、审计、HITL、取消——都要靠装饰器链或低层控制流补回。这正是本课程与教程的分岔口。
- **计划-执行买的是确定性**：把全局决策提前到信息最干净的瞬间，用零成本的 schema 校验拦截幻觉步骤，代价是应对变化的迟钝——所以 replan 要有白名单触发器和次数上限。步数可预见的复合任务选它，探索型任务别硬套。
- **多智能体的三种正当理由**：上下文装不下、风险要隔离、模型要分级；除此之外引入的都是通信协议税。**agent 间只传结构化事实与引用，散文只许出现在人机边界**——2.7 案例用真金白银背书这条纪律。
- **框架编排的边界**：LC4j agentic 模块（experimental）给了 sequence/loop/parallel/supervisor 的积木，但无类型 scope、无一损俱损之外的失败语义、无 checkpoint——需要跨请求生命周期、持久化恢复、轨迹回放时，自写状态机。
- **LangGraph 之问的答案不在框架，在架构属性**：它能显式化状态机、快照每一步；你需要的是这些能力本身，在哪个 JVM 生态里实现是组织约束下的工程选择。
- **下一章预告**：工具层深潜——@Tool schema 生成的暗坑、几十上百个工具时的选择性暴露、把 TicketAgent 反向暴露为 MCP server、以及 tool poisoning 与间接注入的攻防。你的 agent 已经会思考了，接下来要看清它伸出去的那只手有多脆弱。
