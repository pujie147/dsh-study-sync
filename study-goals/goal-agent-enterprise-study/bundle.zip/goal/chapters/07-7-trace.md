# 第 7 章 · 可观测性与成本治理：trace、指标与预算熔断

> **课程**：面向生产环境的 AI Agent 工程（Java / LangChain4j 实战）
> **前置**：goal1 第 1 章（Langfuse docker-compose 基座）、第 2 章（`ChatResponse.tokenUsage()` 与 `ChatModelListener`）、第 9 章规划（RAG 侧观测）；本课程第 1 章（成本乘性放大模型）、第 2 章（轨迹漂移——观测对象）、第 4 章（降级事件留痕的约定）、第 5 章（审计≠日志的分界、审批等待时长概念）、第 6 章（评测 harness 与观测共用 span schema 的伏笔）
> **建议学时**：20 小时
> **本章定位**：把 agent 从黑盒变成玻璃盒。上一章评测回答"系统整体好不好"，本章回答两个运维级问题：**"这一次请求为什么这样？"（任意一次调用可在 Langfuse 回放完整决策树）与"钱花在哪、超了怎么办？"（三级成本核算+预算熔断）**。ADR-004 已冻结 Langfuse 自托管 + OTel GenAI 语义约定的选型，本章不选型、只施工：span 层级设计、属性规范、双写管道、指标体系、成本模型、隐私边界。7.7 的案例会告诉你：没有这章内容时，事故复盘只能靠猜。

---

## 本章学习目标

1. 设计 **agent 特有的 span 层级**（run → step → LLM call / tool call / retrieval），说清循环型工作流的父子关系与"span 切错=没有诊断价值"的判断标准；解决 trace_id 跨异步/虚拟线程传播；
2. 掌握 **OTel GenAI 语义约定**（`gen_ai.*` 属性族）的核心字段，用 LC4j `ChatModelListener` 打通到 OTel span 的对接层，实现 Langfuse/Jaeger 双写与采样策略；
3. 建立 **agent 指标体系**：延迟分解（端到端 P95 与各步贡献）、token 计数族（prompt/completion/cached）、错误率、工具失败率、平均循环步数、人工确认等待时长，配 Prometheus+Grafana 看板与告警阈值；
4. 实现 **per-request/per-user/per-tenant 三级成本核算**与**预算熔断**（超限降级链：小模型→缩工具面→只读模式→转人工），完成 prompt caching 与检索复用的省钱实测；
5. 掌握 **trace 隐私边界**：PII 不落原文、哈希+回源指针模式、Langfuse 自托管保留期设置——与第 5 章审计库的职责分工；
6. 通过一夜 $8k 的循环烧钱案例，内建两条红线：**per-run token 硬顶 + 连续同类失败快速熔断**，并能设计出"成本异常归因"的日常运营方法。

---

## 7.0 从三个凌晨三点的电话说起

可观测性的需求规格说明书，其实就写在故障电话里。三种典型来电，对应本层的三个交付物：

| 电话 | 你被问到的问题 | 现有手段能否回答 | 本章交付 |
|---|---|---|---|
| "用户投诉 agent 胡说八道" | 那次请求它看到了什么上下文、查了什么资料、为什么这么答？ | ❌ 应用日志只有文本流水 | **trace 决策树回放**（7.1–7.3） |
| "老板问 P95 怎么从 6s 变 14s 了" | 慢在检索、模型排队、还是多绕了两轮工具？ | ❌ 只有一个总耗时 | **延迟分解指标**（7.4） |
| "财务问这个月 API 账单为何翻倍" | 哪个租户、哪类任务、哪个工具最烧钱？ | ❌ 只有供应商月度总额 | **三级成本核算**（7.5） |

多年后端的直觉完全适用：这三件事在传统微服务里叫 logging/tracing/metrics 三板斧，agent 时代只是把"服务间调用"换成了"模型步与工具步"。**真正的新东西只有一条：观测对象里多了'概率性决策过程'，以及账单一侧第一次成为一等公民指标。**

---

## 7.1 Agent trace 的层级设计：切错一刀，满盘皆糊

### 7.1.1 参考层级模型

```
trace: ticketagent.request                       ← 一次用户请求的全生命周期
└─ span[agent.run]  (tags: session, user, tenant, mode=supervisor)
   ├─ span[context.assemble]                     ← 第4章装配器：各区段配额与实际占用
   │    ├─ event: budget.downgrade(S8裁剪/RAG topK 4→2)   ← 降级事件必须可见！
   │    └─ span[retrieval]  (attrs: query_hash, top_k, scores[], doc_ids[])
   ├─ span[llm.call #1]                          ← 每次模型往返一个 span
   │    attrs: model, temperature, prompt_tokens, completion_tokens,
   │           cached_tokens, finish_reason, ttft_ms
   ├─ span[tool.call getTicket]                  ← 每个工具执行一个 span
   │    attrs: tool, args_hash, risk_level, validation.outcome, duration
   ├─ span[approval.pending]                     ← HITL：挂起即开 span，回调时关闭
   │    （人等 3 天，span 就跨 3 天 —— 见 7.1.4 的处理）
   ├─ span[llm.call #2] ...                      ← 循环体：step 是重复出现的兄弟节点
   └─ span[guard.check refundTicket] → REJECTED
```

四条切分原则，每条都对应一种"切错了就没有诊断价值"的病：

1. **一切外部 I/O 独立成 span**（LLM 调用、工具、检索、DB）——否则延迟分解无从谈起，P95 恶化永远只能归因于"agent 慢"；
2. **循环的每一轮显式编号**（`step.index` 属性 + span 名带序号）——"平均循环步数"这个指标要求每步可枚举；轨迹评测（第 6 章 L2/L3）直接消费这些字段，**这就是"评测与观测共用 schema"伏笔的兑现**；
3. **决策依据要挂在 span 上而不是藏在文本里**：检索命中了哪些 chunk_id、装配器实际放了哪些区段进 prompt、judge 用了哪个版本——出问题时你要能回答"它当时*看到*了什么"，这是 agent trace 区别于普通 APM trace 的灵魂；
4. **护栏动作是一等事件**：校验拒绝、风险闸挂起、幂等去重命中、预算熔断触发——每一次"系统拦下了什么"都必须留下痕迹。第 5 章穿透矩阵的验证数据、越权拦截率指标，全部从这里取数。

### 7.1.2 记录内容的规范：入参出参记不记？

两难：全记则隐私与存储爆炸，不记则无法回放。裁决表（按数据类型定策略，全局一致）：

| 数据 | 进 trace? | 形式 |
|---|---|---|
| 用户原始提问 | 默认否 | hash + 长度 + 语言标签；开启"调试采样"的会话才存原文（受保留期约束） |
| 工具入参 | 是 | **args_hash 必录**；值默认脱敏后截断（金额/ID 这类业务关键参数保留，PII 字段掩码） |
| 工具返回值 | 摘要化 | 大小、状态码、错误类别、关键字段白名单（如 `status=P1`）；大 payload 落 artifact 存储只留引用（第 4 章 L3 外部化的同款思路用于观测） |
| RAG 片段 | 是（仅元数据） | doc_id/chunk_id/score——够回放"它看到了什么"，不含正文 |
| system prompt | 版本号 | prompt_registry 的版本戳 + hash（第 2 章 goal1"prompt 当代码管理"的闭环点） |
| 模型输出全文 | 同用户提问策略 | 采样开启才存 |

这份表同时就是 7.6 隐私节的内容清单——**先设计好"记什么"，再谈存哪里**。

### 7.1.3 trace_id 传播：老问题的新战场

传统链路里 trace context 随 HTTP header/MQ 消息流动，Micrometer Tracing/OTel agent 基本自动搞定。agent 服务有三个破坏自动传播的点：

1. **虚拟线程 + 异步 SDK**：LC4j 非阻塞路径的回调可能在与请求不同的线程（甚至不同载体线程）上执行——ThreadLocal 形态的 OTel Context 断了。对策：显式 `Context.current().wrap(callback)` 传递（OTel 的标准姿势），或统一经 Micrometer context-propagation 装饰 executor——**与第 4 章 SecurityContext 是同一场战争的两个战线，用同一套装饰器基础设施解决**；
2. **进程外往返**：MCP stdio server 是子进程、HITL 审批回调是隔天的新 HTTP 请求——trace 连续性必须由**业务键接力**：出站时把 trace_id 塞进 MCP `_meta` / pending_action 表（第 5 章已有此列！），回调进来时以 `Link` 而非 child 挂接（跨时间/进程的关联用 link 语义，避免制造"一个 trace 活三天"的怪物）；
3. **批处理/定时任务发起的 agent run**（记忆提取、评测回放）：没有入口 HTTP，需手动 startSpan 并打上 `trigger=cron|eval` 标签——**评测 harness 的流量必须在 trace 上与生产流量可区分**（否则成本统计和 SLO 都被污染）。

### 7.1.4 长挂起 span 的处理

HITL 那种"等人三天"的等待不要做成活的 span（超时告警、trace 存储、火焰图全遭殃）。拆法：`approval.pending` span 只覆盖**挂起动作本身**（毫秒级），等待时长作为**指标**记录（直方图 `agent.approval.wait.duration`），恢复执行是新 span 以 link 关联。第 5 章说的"人工确认等待时长"指标由此而来——注意它对 SLA 的意义：**很多"agent 响应慢"的投诉，瓶颈根本不是模型而是审批人午睡**。

---

## 7.2 OTel GenAI 语义约定：说标准的方言

### 7.2.1 为什么要遵守 semconv

各家观测平台（Langfuse/Grafana Tempo/SigNoz/云厂商 APM）都在逐步支持 OpenTelemetry 的 GenAI 语义约定（`gen_ai.*` 属性族，规范仍在演进、版本敏感）。自造属性名的代价：换平台=重写仪表盘、跨服务聚合分析失效、招聘交接全靠口传。**约定优先于聪明**——这正是当年 micrometer 命名规范教过的课。

核心字段速览（以官方 registry 当前版为准，教学记忆这几组就够开工）：

```
gen_ai.operation.name     = chat | execute_tool | embeddings ...
gen_ai.provider.name      = deepseek | openai | ...
gen_ai.request.model / gen_ai.response.model
gen_ai.usage.input_tokens / gen_ai.usage.output_tokens / (cache 读取字段)
gen_ai.conversation.id    ← 会话关联锚点
gen_ai.tool.name / gen_ai.tool.call.id / gen_ai.tool.call.arguments
span kind: CLIENT(模型调用) / INTERNAL(编排步骤)
事件: gen_ai.client.inference.operation.details（含输入输出的可选记录，
      —— 是否启用由 7.1.2 的规范裁决，默认关）
```

MCP 也已有独立属性族（registry 里的 MCP 分组）——第 3 章的 MCP 调用打标准化标签，跨 server 的工具失败率分析才有统一口径。

### 7.2.2 LC4j 侧对接：listener → span 的胶水层

LC4j 的 `ChatModelListener`（onRequest/onResponse/onError）是天然的埋点位，goal1 第 2 章准备的东西今天接线：

```java
public class OtelChatModelListener implements ChatModelListener {
    private final Tracer tracer;

    @Override public void onResponse(ChatModelResponseContext ctx) {
        var usage = ctx.chatResponse().tokenUsage();
        Span span = tracer.spanBuilder("chat " + ctx.chatRequest().model())
            .setParent(ctx.parentContext())                 // 7.1.3 的传播在此收口
            .setAttribute("gen_ai.operation.name", "chat")
            .setAttribute("gen_ai.provider.name", provider)
            .setAttribute("gen_ai.request.model", ...)
            .setAttribute("gen_ai.usage.input_tokens", usage.inputTokenCount())
            .setAttribute("gen_ai.usage.output_tokens", usage.outputTokenCount())
            .setAttribute("agent.step.index", currentStep(ctx))
            .startSpan();
        span.end();
    }
    // onError: 记 exception + finish_reason 分类（限流/超时/内容过滤分开打 tag —— 7.5 熔断要吃这个）
}
```

工具与检索侧同理：第 3 章的 `GuardedToolExecutor` 装饰器链里加一个 tracing 环（记录 `execute_tool` span + tool 属性族）——**装饰器链的第 N 环终于集齐：tracing → audit → idempotency → validator → risk-gate → delegate**。如果你前面章节的作业都做了，这一步只是插一根线。

### 7.2.3 双写与采样：一条流水线两个出口

```
App(OTLP) ──▶ Collector ──┬──▶ Langfuse   (决策树回放/评分标注/prompt 版本，采样: 错误与高危 100%，正常 x%)
                           ├──▶ Tempo/Jaeger (与 JVM/HTTP 基础设施 trace 统一视图，全量 head-based)
                           └──▶ 成本核算旁路 (只抽 token 属性的轻量流 → ClickHouse/PG 聚合表)
```

要点：**trace 全量、内容采样**——结构（span 骨架+数值属性）便宜且诊断必需，永远全采；内容（prompt/输出正文）贵且敏感，按策略抽样或仅错误样本保留。head sampling 在 SDK 端做会丢"后来才知重要"的样本，推荐 tail-based（Collector 端按属性决定：含 guard.rejected / error / 成本超阈值的 trace 强制保留全文）。Langfuse 侧另有它的 ingestion 队列语义（批量异步、不阻塞业务线程——观测系统永远不能成为故障源，SDK 满了丢数据也不能让请求排队）。

---

## 7.3 指标体系：给玻璃盒装上仪表盘

### 7.3.1 四大族与黄金样例

**① 延迟族**（Histogram，单位 ms）

```
agent.request.duration{bucket, intent_class}          端到端
agent.step.duration{kind=llm|tool|retrieval|assemble} 分步贡献 ★
agent.llm.ttft                                        首 token（流式场景）
agent.approval.wait                                   人审等待（7.1.4）
```

★ 是本章的心气所在：**"P95=14s"没有可操作性，"P95 中 llm 占 9s（其中排队 4s）、tool 占 3s、assemble 占 1s"才有**。做法：run 级 histogram 由 step 级求和构成，Grafana 堆叠面积图一眼看出病灶迁移。

**② Token/成本族**（Counter，多维标签）

```
agent.tokens{direction=prompt|completion|cached, model, tenant, task_type}
agent.cost.chf{...}                    ← 由 tokens × 价格表换算（价格表版本化！）
agent.steps.per_request                Histogram：平均循环步数及其分布
```

**③ 质量代理族**（在线版的"廉价近似指标"，与第 6 章 judge 离线分互相印证）

```
agent.tool.error_rate{tool}            工具失败率（分类: validation|business|system）
agent.hallucinated_tool.rate           幻觉工具名率（第3章防线统计 → 漂移哨兵）
agent.refusal.rate                     拒答率 ★
agent.guard.blocked.rate{rule}         护栏拦截率 ★
agent.budget.downgrade.rate{section}   上下文降级频率（第4章事件）
agent.finish_reason{stop|length|budget_exhausted} 终止原因分布
```

★ 这两个是"质量告警"的主角，用法见下节。

**④ 资源族**：并发 in-flight runs、连接池、虚拟线程 pinning 计数（goal1 第 8 章续篇）——略。

### 7.3.2 质量告警的艺术：比错误率更难的是"没报错的坏"

传统告警盯 5xx 和延迟；agent 会**成功地做错事**。三条实操规则：

- **拒答率的两侧都要告警**：骤升=知识库/检索坏了或模型行为漂移（过度保守）；**骤降同样危险**——可能是护栏被绕过或 prompt 变更让模型变得有求必应。单侧报警等于没报警；
- **护栏拦截率突变是最灵敏的安全哨兵**：某条风控规则拦截数一夜从 3 涨到 400，要么攻击来了，要么上游数据变了让模型集体"想歪"——两种都值得立刻看 trace；
- **比率类告警要设最小分母**：凌晨低流量时段 2 个请求错 1 个=50% 错误率的假警报，规则里永远带 `and request_count > N`。

告警分级示范：`burn rate` 思路（SLO 误差预算消耗速率）用在 token 预算与错误率上，比静态阈值少 80% 的误报——具体公式练习 4 推导。

### 7.3.3 Grafana 看板的信息架构（一张主板的布局）

```
行1 [今日大盘] pass^1 代理分 | P95 分解堆叠图 | 成本燃尽 vs 预算线 | 护栏拦截瀑布
行2 [异常聚焦] 错误率×工具热力 | 拒答/接管率双线 | 步数分布箱线图 | 降级事件流
行3 [下钻入口] 任一异常点 → annotated link 直达 Langfuse 对应 trace 列表 ★
```

★ 指标到 trace 的深链（exemplars 机制：histogram 桶里存几个代表性 trace_id）是"看到数字→点开案发现场"的最后一公里——没有它，前 15 分钟排障还是要靠 grep。

---

## 7.4 成本治理：把账单变成产品参数

### 7.4.1 三级核算模型

```
L-a per-request : 每次 run 的 Σ(token×单价)，写入 trace 属性 + 聚合缓冲
L-b per-user/day: Redis HyperLogLog 不需要——直接 PG 事实表
                  fact_cost(day, tenant, user, task_type, tokens_in/out/cached, cost)
L-c per-tenant/month: 报表 + 对外计费/内部分摊的基础
```

实现上 L-a 就在 listener/executor 装饰器里顺手记账（数据现成：7.2 的属性），异步批量落库；关键是**task_type 维度**——没有它，"哪个功能烧钱"的问题无解。粗粒度意图分类（第 2 章分诊器的副产品）在这里第二次创造价值。

**价格表的坑**：模型单价、缓存折扣率、各档 max 价都是配置不是常量；供应商调价频繁——**cost 计算引用带生效日期的价格表版本**，历史账单才能正确重算。财务系统味的细节，恰是面试里"真做过"的信号。

### 7.4.2 预算熔断：三层闸门与降级阶梯

第 1 章说过"成本是架构问题"，今天落成三道闸：

```
闸1 per-run 硬顶        LoopPolicy.maxTotalTokens（第2章已有）→ 触顶立即收尾：
                        返回已完成部分 + "任务未完成"显式声明 + budget_exhausted 计数
闸2 per-user/日预算     接近 80% 触发降级阶梯 ↓，100% 进入只读模式
闸3 per-tenant/月预算   运营告警 + 自动限流（该租户并发 run 数减半）
```

**降级阶梯**（闸 2 的具体动作序列，每一级都可独立开关并上报事件）：

```
Level 0 正常: 旗舰模型 + 全工具面 + 宽裕上下文
Level 1: 路由到经济模型处理简单意图（分诊器判断，复杂任务仍走旗舰）
Level 2: 工具面收缩到 core 集（第3章 ToolProvider 动态能力）
Level 3: 上下文降级加速（第4章预算表激进模式）+ prompt caching 最大化利用
Level 4: 只读模式（写工具禁用，引导人工渠道）
Level 5: 熔断转人工（保通话术："当前智能服务暂停"）
```

设计评审时的自检问题：**你的降级链路上有没有任何一步依赖"模型配合"？**（比如"请模型自己控制字数"）——有的话那一步不存在。每一级都是服务端确定性开关。

### 7.4.3 省钱的三板斧与实测方法论

1. **Prompt caching**：多数供应商对"与前次请求完全相同的前缀"给 10~50% 计价折扣。工程要点恰好与第 4 章装配顺序呼应：**稳定内容前置**（system+核心工具描述放最前，动态内容后置），缓存命中率才会高。实测：工单场景多轮对话中，前缀稳定的装配让缓存命中率达 60%+，综合成本降约三成（各供应商机制差异大，以实测为准——练习 5 就是你的实测）；
2. **检索结果复用**：同会话相似查询的 RAG 结果短 TTL 缓存（语义指纹而非字符串精确匹配），省 embedding+检索+生成三路；
3. **模型分级路由**：消融实验（第 6 章）给你数据授权——"退款政策问答用经济模型 pass^3 无显著差异"这类结论，每一条都是砍向旗舰模型调用量的刀。

**方法论**：任何省钱手段上线前，先在评测集跑质量回归（省钱省出质量回退是本末倒置），上线后盯 `finish_reason=length` 率与拒答率一周——**成本优化的终点是"帕累托改进"，判据来自第 6 章的仪器**。

### 7.4.4 成本异常归因：烧钱案的侦探手册

账单突增的排查 SOP（背下来）：

```
1. 按维度切片找增量归属: tenant? task_type? model? tool? 时间曲线形状(阶跃=发布,
   斜坡=流量自然增长, 尖刺=重试风暴)?
2. 拉该切片的 trace 样本 20 条看步数分布 → 平均步数暴涨 = 循环失控
3. 看每步 finish_reason 与错误类型 → 同类错误反复出现 = 7.7 案例模式
4. 定位到具体工具/prompt 版本 → feature flag 止血 → 修复 → 对抗回归入集
```

---

## 7.5 隐私边界：观测系统的合规姿态

第 5 章立过审计与日志的分界，这里补第三类——**观测数据的身份**：它是排障素材，既不是证据也不是产品数据，因此有自己的保留纪律：

- **默认不存原文**（7.1.2 裁决表执行到位的话，这里只剩验收）；开启内容采样的 trace 打 `pii=true` 标签，走更短的保留期；
- **回源指针模式**：trace 里放 `audit_ref: pending_action#uuid` 之类的指针，需要原文时凭权限回源第 5 章审计库——**调阅动作本身产生一条审计**（观测消费证据链，而不是复制一份证据）；
- **Langfuse 自托管的红利兑现**（ADR-004）：数据不出域；本项目设置：trace 保留 30 天、score/dataset 长期、内容采样项 7 天；过期自动清理任务要有测试（删除逻辑没人测，GDPR 审计时才发现清不掉）；
- **导出纪律**：截图分享是最大漏点——团队群里的 Langfuse 截图经常整段暴露 prompt 与用户数据；UI 侧脱敏显示选项+水印追责是组织级配套（技术管不住的事写进制度）。

常见误区点名：**"反正是内网自托管就多存点"**——保留期与访问面才是风险函数，存储位置不是。多存三个月原文，泄露半径与合规负债就乘以三。

---

## 7.6 LangGraph 对照阅读：observability 一节的差距与补偿

读 LangGraph 文档 Observability/Agent Server 相关页（30 分钟），抓三点：

| 主题 | LangGraph 侧 | 我们（LC4j+自建） |
|---|---|---|
| 自动 instrumentation | LangSmith 深度绑定：图每一步自动 trace，含 state diff 可视化 | 手工装饰器链换来供应商中立（OTel 标准出口）与 JVM 生态统一（和 Micrometer/现有 APM 同一条管道）——**成本是多写 300 行胶水，收益是不被平台绑架+全栈一张图** |
| checkpointer 与 trace 的关系 | 状态快照天然可回放（trace 缺信息时回到那个 state 重跑） | 我们没有 state checkpoint（第 2/5 章欠条），trace 必须**自带更多上下文**才能补救——所以 7.1.2 的"决策依据挂 span"对我们权重更高 |
| time-travel/重放 | 从任意快照 fork 重放 | 等价物≈第 6 章的评测回放（固定输入重跑），无中间态 fork——诚实认知差距，别在面试吹 |

面试加分表述："LangSmith 的 trace 是框架亲儿子级的开箱体验；我们用 OTel semconv 自建达到了九成的诊断力，代价是初装工时，收益是观测栈与应用栈的同构（一个 collector、一套告警、零平台锁定）。"

---

## 7.7 企业踩坑案例：一夜 $8,412——限流、重试与一个不设防的循环

> 案例基于多起公开的"API 账单事故"社区复盘（含知名 AI 产品团队的自述）合成改写，机理真实。

**背景**：某 B2B 公司的合同审查 agent（内部法务提效工具），架构上颇有几分本课味道：ReAct 循环挂 9 个工具（条款抽取、法规检索、风险标注……），接了外部法规数据库的 API 作为主力工具。上线两个月相安无事，账单稳定在每月 $4k 上下。

**事发**：某个周四夜里，值班手机没响（没有任何成本类告警），周五早上财务系统邮件炸锅：**昨日单日 API 费用 $8,412**，其中模型费 $6.1k、法规 API 费 $2.3k。而当天流量与平日持平。

**排查**（因为没有 trace 上的成本维度，全程靠翻网关日志拼凑，花了六小时）：

还原出的死亡链条堪称教科书级连锁反应：

1. 当晚 21:40，法规数据库供应商维护窗口，其 API 开始返回 `429 Too Many Requests`（带 `Retry-After: 30`，但——）；
2. agent 的 HTTP client 层配了通用重试策略（Resilience4j 默认风格：指数退避重试 3 次）——**没读 Retry-After，且对 429 与 5xx 一视同仁**；
3. 重试耗尽后抛出异常，被回填进模型上下文（当时的错误处置不分四类，一律回喂）；
4. 模型看到"查询失败"，判断"换个条款关键词再试一次也许能行"——**它不知道这是配额问题而不是查询问题**；
5. 于是循环继续：第 9 轮、第 10 轮……**maxTurns 配的是 25**（为复杂合同定的），每轮携带越来越长的上下文重新计费；
6. 单个请求的峰值成本 ≈ 25 轮 × 平均 18k prompt tokens × 重试 3 倍放大。当晚 340 个并发任务撞上这个模式，四个小时内把年度预算的 1/6 点了出去。

**复盘认定的四条根因**（火力对准"缺失"而非"错误"）：

- **没有 per-run token 硬顶**：maxTurns 限制了轮数，却没限制单轮体积——25 轮×巨量上下文的组合成本上限从未被计算过。**轮数上限是弱约束，token 硬顶才是强约束**；
- **没有连续同类失败熔断**：同一个工具以同一个错误码连续失败 N 次，理应判定"此路今晚不通"直接短路（circuit breaker 的经典语义），但当时的熔断器只包住了 HTTP 层瞬时抖动，**模型驱动的"智能重试"完全绕过了它**——因为每次重试在模型眼里都是"新的一次尝试"；
- **成本没有实时性**：账单次日邮件才知道，观测体系里压根没有 `agent.cost` 这个一等指标（更别提 7.3 的成本燃尽告警）；
- **错误语义未分类**（第 2/3 章四分类的反面教材）：429 属系统性故障，应上抛走降级，却被回喂给了一个只会"更努力尝试"的模型。

**修复**（该公司事后确立的两条红线，即本节标题的出处）：

1. **红线一：per-run token 硬顶**。所有 agent run 强制携带 `max_total_tokens`（按任务类型的 P99 成本画像设定，超出即优雅收尾并标记 `budget_exhausted`），并在闸 2/闸 3（用户日预算/租户月预算）上加**小时级**成本燃尽告警——"发现烧钱"的时延目标从次日改为 15 分钟；
2. **红线二：连续同类失败快速熔断**。观测侧新增 `tool.consecutive_failures{code}` 计数器，同一工具同错误类别连续 ≥3 次 → 该工具对本次 run 直接下线（返回"暂不可用勿再试"），同错误模式跨 run 高频出现 → 全局熔断该工具+触发降级阶梯；
3. 配套三项：429 处理尊重 Retry-After 并进退避计算；系统性错误不再回喂模型（对齐四分类）；trace 增加 cost 维度让 7.4.4 的归因 SOP 十分钟走完。

**结果**：此后两年未再发生单夜五位数事故；最有价值的副产品是那套"成本燃尽 vs 预算线"看板——它把成本从财务话题变成了每日站会的一行绿色数字。

**带走的三条教训**：

1. **模型的"坚持"是你的成本放大器**：它会用一切办法完成你交代的任务，包括对着一个明确死掉的接口持续敲门——**系统性故障必须物理隔断在模型决策之外**；
2. 限额要设在**乘法维度**（token×轮数的联合上限）而不是加法维度（单独限轮数）；
3. 没有实时成本观测的系统，事故规模=`发现时延 × 燃烧速率`——本案里这个乘积是 $8k，如果告警在 15 分钟内，是 $300。

---

## 动手练习

> TicketAgent 仓库 `chapter07` 分支。docker-compose 基座里已有 langfuse，本章把它喂饱，并把 OTel Collector 加进 compose。

**练习 1 · Span 层级施工（5h）**
按 7.1.1 参考模型完成 agent.run/step/llm/tool/retrieve/assemble 全层级埋点（listener+装饰器链 tracing 环）；`gen_ai.*` 属性对齐 semconv；实现 7.1.3 的三处传播修复（虚拟线程 wrap、pending_action 的 link 关联、评测流量的 trigger 标签）。验收：随机挑一条线上 trace，能在 Langfuse 里回答"它第 3 步为什么选了 closeTicket 而不是 updatePriority"（含当时可见的上下文清单）。

**练习 2 · 双写管道与采样（3h）**
compose 加 OTel Collector：一条 OTLP 管道分发 Langfuse + Tempo；实现 tail-based 策略（含 guard.blocked / error / cost>阈值的 trace 保留内容，其余只留结构）。压测验证观测开销：埋点前后 P95 差 <5%、业务线程零阻塞（kill Collector 进程演示"观测系统挂了业务照常"）。

**练习 3 · 指标与告警（4h）**
Micrometer 实现 7.3 四族指标 + Grafana 三板块看板（含 exemplar 深链到 Tempo/Langfuse）；配五条告警：延迟分解突变、工具失败率、拒答率双侧、护栏拦截率突变、成本燃尽。每条告警做一次**注入演练**（人为制造异常数据）验证真的会响。

**练习 4 · 成本核算与熔断（5h）**
三级核算落地（价格表版本化+事实表+租户月报）；三道闸+五级降级阶梯实装（每级独立 feature flag）；混沌演习：mock 供应商 API 返回 429，复现 7.7 死亡链条的前半段，展示你的两条红线如何分别在"第 3 轮"和"第 1 小时"掐灭它——演习报告含修复前后的模拟账单对比。

**练习 5 · 省钱实测（3h）**
prompt caching 命中率实验：构造装配顺序稳定/不稳定两版，各跑 100 次多轮会话，记录 cached_tokens 占比与综合成本；检索复用缓存的 TTL 敏感性测试（太短无收益/太长吃新鲜度，结合第 4 章 asOf 机制给出折中值）。产出《成本优化备忘录》：每项手段的质量回归结果（引第 6 章 harness）+ 净节省估算。

**练习 6 · 隐私验收（2h）**
按 7.1.2 裁决表逐类抽查 trace 内容（grep 手机号/身份证正则扫 Langfuse 导出数据，断言零命中）；实现回源指针调阅流程并证明"调阅产生审计"；配置保留期清理任务并写测试。

**练习 7 · 对照阅读（1h）**
读 LangGraph Observability 文档 + OTel GenAI semconv registry 页，写 15 行笔记：他们自动 trace 了什么、state diff 可视化为什么有用、我们的手工方案在哪个具体场景会追不平（诚实清单）。

---

## 本章小结

- **trace 的价值密度在切分层级时就决定了**：外部 I/O 独立成 span、循环步显式编号、决策依据上挂、护栏动作一等事件——四条原则保证你的玻璃盒能回答"它当时看到了什么、为什么这么选"，并与第 6 章评测共用同一套 schema。
- **说标准方言**：`gen_ai.*` semconv + OTel Collector 双写（Langfuse 回放 + Tempo 全栈视图）；trace 全量、内容采样、tail-based 优先；观测系统自身绝不能成为故障源。
- **指标要能分解到可操作**：P95 拆到步、token 分到方向与租户、质量代理指标（拒答率双侧、护栏拦截率突变）盯住"没报错的坏"；exemplar 打通"数字→案发现场"的最后一公里。
- **成本是一等公民**：三级核算+价格表版本化；三道闸的限额设在 token×轮数的乘法维度；降级阶梯每一级都是服务端确定性开关、不赌模型配合；省钱手段必须过质量回归才算数。
- **两条红线来自真金白银**：per-run token 硬顶 + 连续同类失败快速熔断——7.7 案例证明了它们的反面教材版本：轮数限额挡不住巨型上下文、HTTP 层熔断挡不住"智能重试"。发现时延×燃烧速率=事故规模。
- **观测数据有自己的合规人格**：默认不存原文、哈希+回源指针、保留期自动化测试、截图文化制度化——自托管不等于免罪金牌。
- **下一章预告**：玻璃盒造好了，看得见了——但看见故障不等于扛得住故障。第 8 章把 Resilience4j 的武器库对准 agent 的三个不稳定源（模型/工具/网络），把本章"发现"的一切变成"自愈"的动作：重试的正确语义、多级降级的自动化、幂等的最后拼图，以及 k6+混沌演练的韧性验收。
