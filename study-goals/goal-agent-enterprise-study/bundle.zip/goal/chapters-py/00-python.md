# 第 0 章 · Python 工程桥接（Java 背景专属前置）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **读者画像**：多年 Java 后端经验，写过 Spring/MyBatis/JUC，但 Python 只停留在"能看懂脚本"的水平。
> **建议学时**：8 小时（可压缩到周末两天）
> **本章定位**：不计入主线九章编号的补课模块。**你缺的不是语法，是"工程母语"**——虚拟环境、类型注解、asyncio、Pydantic、pytest 这些在 Java 里由 Maven/Jackson/虚拟线程/JUnit 默默承担的角色，Python 里需要你亲手选型并配置。本章只讲后面九章会反复用到的那 20%，按二八原则严格裁剪：不讲爬虫、不讲 Django、不刷 LeetCode。
> **阅读约定**：本章每个概念都带「☕ Java 锚点」对照；代码注释密度约 30%，注释解释**工程意图与坑**，不复述语句字面意思。

---

## 本章学习目标

1. 建立 Python 工程基建肌肉记忆：uv + pyproject.toml + venv 的工作流，等价于你熟悉的 Maven 心智；
2. 用类型注解 + mypy/pyright 把"失去编译器"的焦虑对冲掉 80%——理解 Python 类型系统是**渐进式**的（可选标注），以及为什么 agent 项目必须全量标注；
3. 掌握 Pydantic v2：它 = Jackson（序列化）+ Bean Validation（校验）+ OpenAPI schema 生成器 三合一，是本课程所有结构化输入输出的地基；
4. **asyncio 半日精读**（本章核心）：事件循环模型、`await` 传染性、TaskGroup、超时与取消语义——并与 JDK21 虚拟线程做逐条对照，这是你背景错位最大的一处；
5. 会用 pytest：fixture、parametrize、标记分组——第 6 章评测 harness 直接建在这上面；
6. 认识装饰器与上下文管理器的语法学（读懂 `@tool`、`@entrypoint`、`with` 满天飞的框架源码的前提）；
7. 过一遍"Java 人写 Python 十大反模式"，从第一天就写出能被同事接受的 Python。

---

## 0.1 环境与包管理：把 Maven 心智平移过来

### 0.1.1 概念对照表

| Java 世界 | Python 世界 | 说明 |
|---|---|---|
| Maven/Gradle | **uv**（推荐）或 poetry | uv 是 Rust 写的新锐工具，快得离谱，一个工具管齐 venv/依赖/锁文件/Python 版本 |
| pom.xml | **pyproject.toml** | 项目元数据+依赖声明+各工具配置（ruff/mypy/pytest 都住在这里，类似 pom 里塞插件配置） |
| dependencyManagement + 传递依赖仲裁 | **uv.lock** | 锁定全部传递依赖的精确版本+哈希——比 Maven 更彻底（Maven 只锁直接依赖版本，lockfile 文化是 Python 补上的课） |
| `~/.m2/repository` | site-packages（每项目独立 venv） | **关键差异**：Java 全局仓库共享，Python 每个项目一套隔离环境。新人最常见困惑"我装了包怎么 import 不到"=装错环境 |
| `mvn verify` | `uv run pytest` / `uv run ruff check` / `uv run mypy` | "run" 前缀保证命令在项目 venv 里执行 |
| JDK 版本管理 (sdkman) | `uv python pin 3.12` | uv 可以直接代管 Python 解释器版本 |

### 0.1.2 三分钟工作流（动手）

```bash
uv init ticketagent && cd ticketagent     # ≈ mvn archetype:generate，生成骨架+pyproject.toml
uv add langgraph langchain-openai fastapi # ≈ 往 pom.xml 加 <dependency>，自动更新 lock
uv add --dev pytest ruff mypy             # --dev = scope=test 的依赖组，不进生产包
uv run python -c "import langgraph; print('ok')"   # 在正确的 venv 里执行
uv sync                                   # CI/新同事入职：按 lock 精确复现环境（≈ mvn install 的确定性侧）
```

> **⚠️ 坑 1**：IDE（VSCode/PyCharm）右下角要手动选对解释器（`.venv/Scripts/python.exe`），否则红线满屏。这相当于 IDE 没认出你的 JAVA_HOME。
> **⚠️ 坑 2**：Windows 上路径分隔符和换行符偶尔搞事，git 配 `core.autocrlf=input`、代码里永远用 `pathlib.Path` 不用字符串拼路径（见 0.7 反模式 #7）。

---

## 0.2 类型注解与静态检查：重建你的编译器安全感

### 0.2.1 语法速览（对着 Java 记）

```python
from typing import Optional, Protocol, Literal, TypeAlias

def find_ticket(ticket_id: str, limit: int = 10) -> list["Ticket"]:
    # 参数名: 类型 = 默认值   -> 返回类型
    # 对照 Java: List<Ticket> findTicket(String ticketId, int limit)
    ...

ticket: Optional[Ticket] = None        # ≈ @Nullable Ticket ticket（None 是单例，不是 null！）
tier: Literal["GOLD", "SILVER"]        # ≈ enum 的轻量替身：限定字面量，mypy 能查
Priority: TypeAlias = Literal["P1","P2","P3","P4"]   # type 别名 ≈ 给类型起短名

class Auditable(Protocol):             # Protocol ≈ interface，但是【结构性】子类型：
    def audit_log(self) -> dict: ...   # 不需要 implements——长得像就算实现（鸭子类型的静态化）
```

三条 Java 人最需要校准的认知：

1. **注解是提示不是强制**：运行时完全无视类型标注，传错照样跑——直到某处炸出 AttributeError。所以静态检查必须进 CI（下节）；
2. **没有泛型擦除的心跳感**：`list[Ticket]` 就是 `List<Ticket>`，但它是可变的（append 随便调），想要不可变用 `tuple[Ticket, ...]`（≈ `List.stream().toList()` 的结果）；
3. **`None` ≠ null**：它是单例对象，比较用 `is None` 不用 `== None`；Optional 链式调用不存在（没有 `Optional.map().orElse()`），惯用法是海象运算符与真值判断：

```python
if (t := repo.find(tid)) is not None:      # := 边赋值边判断，≈ var t = ...; if (t != null)
    return t.status
return "NOT_FOUND"
```

### 0.2.2 mypy / pyright：CI 里的隐形 javac

```toml
# pyproject.toml —— 工具配置集中营（对照：pom.xml 里的插件段落）
[tool.mypy]
strict = true            # 打开全部检查：漏标注、Any 滥用、未处理的 None……
                         # 【本课程纪律】agent 项目一律 strict——动态类型的自由是原型阶段的蜜糖、
                         # 生产阶段的砒霜；你花了二十年让编译器替你干活，别轻易放弃这个外挂

[tool.ruff]              # ruff = ESLint+Spotless+半个 SonarQube，Rust 写的，秒级全仓扫描
line-length = 100
lint.select = ["E", "F", "I", "UP", "B"]   # B=bugbear：抓"可变默认参数"这类经典坑（0.7 #1）
```

日常：保存即有 pyright 红线（VSCode 内置），提交前 `uv run ruff check --fix && uv run mypy .`，CI 跑同一套。**这套组合拳打完，你丢掉的编译期安全大约回来八成**——剩下两成靠 Pydantic 边界校验（下一节）兜住。

---

## 0.3 Pydantic v2：本课最重要的第三方库

### 0.3.1 一句话定位

> **Pydantic = Jackson（JSON⇄对象）+ Bean Validation（@NotNull/@Min）+ JSON Schema 生成器** 的合体，纯声明式。

Agent 工程里它出现在每一处边界：LLM 的结构化输出、工具的参数 schema（第 3 章）、LangGraph 的 State 定义（第 2 章）、FastAPI 的请求响应（0.6）、审批表的 args_json（第 5 章）。现在多花一小时，后面九章处处受益。

```python
from decimal import Decimal            # 【注意】金额永远用 Decimal，float 会在转述中漂移——
from datetime import datetime          #  这正是第 2 章报销事故案例的语言级注脚
from pydantic import BaseModel, Field, field_validator

class RefundArgs(BaseModel):           # 对照：record + @Valid + @JsonProperty 三合一
    ticket_id: str = Field(min_length=2, description="工单号，如 T-1024")
                                        #       ↑ description 会被导出进 JSON Schema——
                                        #         这就是 LLM 看到的"参数文档"（第 3 章主角）
    amount: Decimal = Field(gt=0, le=Decimal("5000"))
    currency: Literal["CNY", "USD"] = "CNY"
    reason: str = Field(default="", max_length=500)

    @field_validator("ticket_id")
    @classmethod
    def ticket_must_exist_shape(cls, v: str) -> str:
        if not v.startswith("T-"):
            raise ValueError("工单号必须以 T- 开头")     # ≈ @Pattern 之外的自定义 ConstraintValidator
        return v

# ---- 边界校验：LLM 吐出的任何 JSON 先过这里 ----
try:
    args = RefundArgs.model_validate_json(llm_output)   # 解析+校验一步到位
except ValidationError as e:                             # 错误信息自带字段路径与原因，
    feed_back_to_model(e.errors())                       # 回喂模型自我修正（第 2/3 章错误语义的基础设施）
```

三个高频决策：

- **BaseModel vs dataclass**：跨网络边界（LLM 输出/API/DB JSON 列）→ Pydantic（要校验和 schema）；进程内纯数据结构 → `@dataclass`（轻且快，≈ Lombok @Value）。LangGraph 的 State 两者都有用法，课程统一 Pydantic 起步；
- **model_dump_json() 而非 json.dumps(obj)**：前者走 Pydantic 序列化管线（处理 Decimal/datetime/嵌套模型），后者会把 Decimal 甩给你看；
- **frozen=True**：需要 record 那种不可变语义时加上（`model_config = ConfigDict(frozen=True)`），同时获得 hashable。

---

## 0.4 asyncio 半日精读：与虚拟线程分道扬镳的地方

> 本节是全章重心。你在 JDK21 世界的直觉——"业务代码写成同步阻塞的样子，平台负责伸缩"——在这里**部分失效**，必须先立正确模型再写第一行异步代码。

### 0.4.1 一张对照表立骨架

| 维度 | JDK21 虚拟线程 | Python asyncio |
|---|---|---|
| 编程模型 | 阻塞式 API（代码看不出异步） | **显式 async/await，双色函数**：`async def` 与普通函数是两个物种，互相不能直接调用 |
| 调度单位 | 数百万 VT，内核线程被 park/unpark 隐藏 | 单个事件循环线程 + 协程（coroutine），协作式让出 |
| 让出时机 | JVM 在任意阻塞 IO 处自动挂起 | **只在 `await` 处**让出——一次 `time.sleep(1)` 卡死整个循环（要用 `await asyncio.sleep(1)`） |
| 并行度 | 多载体线程可真并行 | 单循环线程**永不并行执行 Python 字节码**（GIL 的另一面；CPU 密集要 multiprocessing，但 agent 场景几乎全是 IO，无感） |
| 取消传播 | interrupt() / Future.cancel，语义松散 | **取消是一等公民**：`task.cancel()` 向 await 点注入 CancelledError，可清理可屏蔽（第 8 章断连止损的地基） |
| 生态适配 | 任意阻塞库直接用 | **分裂**：httpx/asyncpg/aiofiles 是 async 系，requests/psycopg2 是 sync 系——混用要把阻塞调用扔进线程池 `asyncio.to_thread()` |
| 结构化并发 | StructuredTaskScope（preview） | **TaskGroup（成熟）**：组内一败俱败、不留孤儿任务——语义反而更完整 |

**心智重设的一句话**：虚拟线程是"骗过阻塞"，asyncio 是"承认异步并要求你明说"。好消息：agent 服务的主循环（等 LLM、等工具、等审批回调）本来就是异步形态，asyncio 是顺水推舟；坏消息：双色传染意味着**从入口到叶子要么全 async，要么设计好边界转换**。本课程策略：**全链路 async-first**（FastAPI 端点开始一路 await），同步库调用统一经 `to_thread` 下沉。

### 0.4.2 最小可运行解剖

```python
import asyncio

async def call_llm(prompt: str) -> str:
    await asyncio.sleep(1)              # 占位：真实场景是 await model.ainvoke(...)
    return f"echo:{prompt}"             # 注意：async def 函数【调用】它得到的是 coroutine 对象，

async def main() -> None:
    # ❌ call_llm("a")                  #    忘了 await = 拿到一个从没执行的 coroutine + RuntimeWarning
    r = await call_llm("a")             # ✅ await 才真正驱动它运行

    # 并发两个请求（对照 CompletableFuture.allOf）：
    results = await asyncio.gather(call_llm("b"), call_llm("c"))   # 总耗时≈1s 非 2s

    # 结构化并发（推荐形态，对照 StructuredTaskScope.join_on_failure）：
    async with asyncio.TaskGroup() as tg:
        t1 = tg.create_task(call_llm("d"))
        t2 = tg.create_task(call_llm("e"))
    # 离开 with 块时二者必已结束；任一抛错 → 另一个被 cancel → 聚合为 ExceptionGroup
    print(results, t1.result())

asyncio.run(main())                     # 程序入口：建循环、跑到完成、关循环。一个进程通常只有一个 run()
```

### 0.4.3 超时与取消：第 8 章的预备课

```python
async def with_budget(coro, seconds: float):
    try:
        async with asyncio.timeout(seconds):     # 3.11+ 的标准姿势（对照 orTimeout 但作用于代码块）
            return await coro
    except TimeoutError:                          # 注意：内建 TimeoutError，asyncio.TimeoutError 是其别名
        return FALLBACK                           # 超时≠失败已发生——写操作要查证（第 8 章铁律）

async def cancellable_tool():
    try:
        while True:
            await asyncio.sleep(0.1)              # 只有 await 点可被 cancel——长 CPU 段是"不可取消区"
    except asyncio.CancelledError:
        await flush_audit()                       # 清理后【必须 re-raise】：吞掉取消 = 破坏结构化并发契约
        raise
```

> **⚠️ 三大新手事故**（每个都值一次实验，见练习 3）：① 忘 await（协程静默不执行）；② 在 async 函数里调阻塞库（整个服务假死，监控显示"CPU 空闲但零吞吐"）；③ 裸 `create_task()` 不持引用——任务可能被垃圾回收凭空消失（官方文档明确警告），要么 TaskGroup 托管，要么自己存集合。

### 0.4.4 contextvars：ThreadLocal 的正确进化体

第 4 章身份传递的答案提前埋点：

```python
from contextvars import ContextVar
current_principal: ContextVar[str] = ContextVar("principal")     # ≈ ThreadLocal，但……

async def handle(req):
    tok = current_principal.set(req.user)
    try:
        await chain_of_calls()          # ✅ 协程创建时【自动拷贝】上下文快照：
    finally:                            #    每个 task 天然隔离，虚拟线程时代的 ThreadLocal 碎裂问题
        current_principal.reset(tok)    #    在这里根本不存在——语言层面就设计对了
```

结论：Java 里我们骂了十年 ThreadLocal + 线程池的组合拳，Python 用 contextvars 给出了正解——**记住这个对比，面试聊到异步模型时是现成的加分素材**。

---

## 0.5 装饰器与上下文管理器：读懂框架源码的钥匙

### 0.5.1 装饰器 = @Around 切面的函数版

```python
import functools, time

def timed(fn):                                  # 接收函数、返回包装函数——就这么朴素
    @functools.wraps(fn)                        # 保留原函数 __name__/__doc__（不加=反射取名字时哭）
    async def wrapper(*args, **kwargs):         # async 版切面包 async 函数（同色原则）
        t0 = time.perf_counter()
        try:
            return await fn(*args, **kwargs)
        finally:
            metrics.observe(fn.__name__, time.perf_counter() - t0)   # 观测环（第 7 章的原型）
    return wrapper

@timed                                          # ≈ @Around("execution(*)")——但没有 AOP 代理魔法，
async def call_search_api(q: str): ...          #   就是函数当参数传。@tool/@entrypoint 全是这个套路
```

看懂这一节，第 3 章的 `@tool`、第 7 章的 middleware、第 8 章的 tenacity `@retry` 对你就不再是黑盒语法。

### 0.5.2 with：try-with-resources 的正统继承者

```python
from contextlib import asynccontextmanager

@asynccontextmanager
async def db_tx(pool):
    async with pool.acquire() as conn:          # 获取连接（对照 HikariCP getConnection）
        async with conn.transaction():          # 开事务
            yield conn                          # ← with 块内的代码在 yield 处"插入执行"
        # 异常穿透时自动 rollback，正常退出自动 commit——transaction() 内部就是这么实现的

async with db_tx(pool) as tx:                   # 使用侧干净如 Java try-with-resources
    await tx.execute("INSERT INTO pending_action ...")
```

---

## 0.6 FastAPI 三十分钟：你的 HTTP 壳

只学到"够用"深度（第 8 章流式韧性时还会回来补课）：

```python
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel

app = FastAPI(lifespan=lifespan)                # lifespan≈@PostConstruct/@PreDestroy 容器钩子

class AskIn(BaseModel):                          # 请求体 schema——同一个 Pydantic 复用（0.3 的回报）
    session_id: str
    text: str = Field(min_length=1)

@app.post("/api/ask")
async def ask(body: AskIn, user: Principal = Depends(auth)):   # Depends≈@Autowired+拦截器合体，
    ...                                                        # 但可测试性完胜 ThreadLocal 取用户
    return await agent_graph.ainvoke(...)        # 直接 await LangGraph（全栈同色，asyncio 无缝）
                                                 # 注意：FastAPI 会自动把同步 def 端点扔线程池——
                                                 # 别依赖这个暗梯，我们的规矩是全 async 到底
```

对照记忆：路由≈Spring MVC 注解、Depends≈DI+过滤器、自动 OpenAPI 文档≈springdoc（但原生免费）、uvicorn≈内嵌 Tomcat 命令行版。

---

## 0.7 Java 人写 Python 十大反模式（每条一行药方）

| # | 反模式 | 药方 |
|---|---|---|
| 1 | **可变默认参数** `def f(items=[])`——默认值在 def 求值时创建一次，所有调用共享同一个列表（隐蔽级 bug 之王） | `items=None` + `items = items or []`；ruff B006 会抓 |
| 2 | getter/setter 恋物：给每个属性写 `get_x()` | 直接访问属性，要控制时 `@property` 升级，接口不破 |
| 3 | 手搓 Builder 模式 | 关键字参数 + 默认值 + Pydantic 已经覆盖 95% 场景 |
| 4 | 万物皆类：三行逻辑也要 AbstractFactoryManager | 函数是一等公民；模块≈包级别的命名空间，singleton 常以模块级变量形式存在 |
| 5 | `try: ... except Exception: pass` 大网兜底 | EAFP 但要窄捕获；至少 `logger.exception` 留痕（对照：别吞 InterruptedException 的同款家训） |
| 6 | 字符串拼路径 `"a\\" + b` | `pathlib.Path("a") / b`，跨平台免疫 |
| 7 | 手写连接重试循环 | tenacity `@retry`（第 8 章正式讲），别重复发明退避算法 |
| 8 | 用 `type(x) == dict` 做分支 | `isinstance` / Protocol 结构化类型；更好的答案是重新设计避免分支 |
| 9 | 在 async 函数里 `print` 大对象调试阻塞事件循环 | logging + `to_thread`；开发期用 `uvicorn --reload` |
| 10 | 忽略 `__init__.py` 与导入路径玄学（ModuleNotFoundError 地狱） | src 布局 + `uv pip install -e .`（可编辑安装），照抄 0.8 目录 |

---

## 0.8 目标仓库骨架（后续九章共用）

```
ticketagent/
├── pyproject.toml            # 依赖+工具配置（ruff/mypy/pytest 全在此）
├── uv.lock
├── docker-compose.yml        # 复用 goal1 基座：postgres+pgvector / ollama / langfuse
├── src/ticketagent/
│   ├── config/               # Settings(pydantic-settings)、功能开关
│   ├── api/                  # FastAPI 路由与 SSE（ch8）
│   ├── orchestration/        # LangGraph 图定义（ch2）
│   ├── tools/                # @tool 与 MCP（ch3）
│   ├── memory/               # checkpointer/store 装配（ch4）
│   ├── guardrails/           # 风险分级/HITL/审计（ch5）
│   ├── evals/                # golden set + judge + harness（ch6）
│   ├── observability/        # tracing/metrics/cost（ch7）
│   └── resilience/           # 重试/降级/幂等（ch8）
├── tests/                    # unit/ integration/ eval 三层，pytest marker 区分
└── docs/                     # ADR、cost-log.csv、各章实验产物
```

对照 Java 的多模块 Maven：Python 用**单包+子模块目录**即可（打包粒度需求低），src 布局防止"当前目录意外可导入"的经典坑。

---

## 动手练习

> 本章练习的唯一目的：把工具链踩熟。产出物进 `chapter00` 分支。

**练习 1 · 工程基建（1h）**
`uv init` 搭出 0.8 骨架（本阶段 orchestration 等目录放空 `__init__.py`）；配好 ruff+mypy strict+pytest markers；写一个 `hello` 模块与其测试证明三件套全绿；故意制造一个可变默认参数 bug 让 ruff B006 抓到并截图。

**练习 2 · Pydantic 边界实验室（1.5h）**
实现 `RefundArgs`（含 Decimal/Literal/自定义 validator）；写 10 个畸形 JSON 样本（类型错/枚举越界/嵌套缺失/多余字段）喂 `model_validate_json`，把 `ValidationError.errors()` 的结构整理成表格——这份结构将在第 2 章作为"回喂模型的纠错提示"素材原样复用。

**练习 3 · asyncio 事故复现三件套（2h）**
(a) 忘 await：观察 RuntimeWarning 与"函数没执行"现场；(b) 在 async 端点里 `time.sleep(3)`，用两个并发 curl 证明事件循环被卡（第二请求排队 3s），改 `asyncio.sleep` 后复测对比；(c) TaskGroup 内一任务抛错，打印兄弟任务的 CancelledError 传播轨迹。写 10 行复盘进 `docs/ch00/asyncio-notes.md`。

**练习 4 · 超时/取消/contextvars（1.5h）**
实现 0.4.3 的 `with_budget` 并用它包裹一个 2s 假任务验证 1s 超时生效；给 cancellable_tool 发 cancel，断言 cleanup 执行且 CancelledError 未被吞；用 contextvars 在三层嵌套 async 调用间传递 principal，并证明两个并发 task 互不串值（对照第 4 章将讲的 ThreadLocal 事故）。

**练习 5 · pytest 与 FastAPI 冒烟（1.5h）**
为一个 echo 端点写三类测试：纯单元（直接调函数）、`AsyncClient` 集成测试（fixture 管理 app 生命周期）、`@pytest.mark.parametrize` 表驱动 5 组输入；体验 fixture 依赖注入与 marker 分组（`pytest -m "not eval"`）。

**练习 6 · 迁移笔记（0.5h）**
写 10 行《我的 Java→Python 冲击清单》：哪些瞬间感到爽（uv 速度？repl？）、哪些感到失控（没有编译检查？IDE 重构弱？），贴到 `docs/ch00/impressions.md`——这份主观记录在第 9 章写迁移博客时是独家一手素材。

---

## 本章小结

- **工具链**：uv/pyproject/lockfile 是"更严格的 Maven"，venv 隔离是心智转换第一关；ruff+mypy strict 进 CI 后，编译期安全找回八成。
- **Pydantic 是本课程的通用语**：模型输出、工具 schema、State、API 契约全靠它——Field(description=...) 的一行文字会原样抵达 LLM 眼前（第 3 章展开），所以"类型即文档即校验"在 agent 时代权重更高了。
- **asyncio 是与虚拟线程的分岔口**：双色函数、只在 await 让出、取消是一等公民、TaskGroup 结构化并发优于裸 create_task；策略定死为全链路 async-first，阻塞库经 to_thread 下沉。contextvars 顺手解决了 Java 阵营的老毛病（ThreadLocal 跨线程碎裂），值得在面试里对比着讲。
- **装饰器/with 是语法学而非魔法**：看懂 0.5 两页纸，`@tool`/`@entrypoint`/middleware 链条从此透明。
- **十大反模式**贴在显示器边上一个月，比读一本《流畅的 Python》更快形成手感（后者仍建议列入 M3~M4 的睡前读物）。
- **下一章预告**：工具链就绪，进入主线——Agent 工程全景与生产化心智模型。五层架构图将第一次以 LangGraph/create_agent/middleware 的面貌重绘，ADR-001 修订案（为什么从 LC4j 迁到 LangGraph）由你亲手写下第一稿。
