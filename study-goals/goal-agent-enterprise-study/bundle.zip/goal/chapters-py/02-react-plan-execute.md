# 第 2 章 · Agent 编排模式：ReAct、计划-执行与多智能体（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：第 0 章（asyncio/Pydantic/装饰器）、第 1 章（三要素定义、五层架构、ADR-001r）；v1-Java 版第 2 章作为对照阅读材料保留
> **建议学时**：32 小时
> **本章定位**：全课程的核心骨架。三种主流编排模式——**ReAct、计划-执行、supervisor 多智能体**——全部亲手实现一遍再交给框架：先用 `model.bind_tools()` 手写循环吃透"思考-行动-观察"的控制流，然后拆解 `create_agent` 替你做了什么，最后用 `StateGraph` 的显式图表达计划-执行与 supervisor。v1 里"LC4j 缺什么要自建什么"的多处欠条（无类型 scope、无 reducer、无动态扇出），本章开始由 LangGraph 原生设施兑付——教学重点相应从"造引擎"上移为"**懂原理、配对语义、知道框架仍然不管什么**"。每种模式依旧要求回答"什么时候不该用它"。

---

## 本章学习目标

1. **手写 ReAct 循环**：显式管理 messages 序列（AIMessage.tool_calls / ToolMessage 配对规则），实现轮数/token/连续同工具三重熔断；诊断"模型反复调同一工具"的三类根因；
2. 说清 **`create_agent` 自动循环的黑盒**：它的内部就是一个预置图；middleware 钩子（before_model/wrap_tool_call）能覆盖哪些生产需求、哪些仍必须拿到显式 `StateGraph` 自己做；
3. 用 **Pydantic discriminated union 建模 Plan**（CallTool/ReasonFrom/AskUser），实现三道零成本静态校验与白名单化 replan；掌握与纯 ReAct 的成本/质量/可测性四维权衡；
4. 落地 **supervisor-worker 多智能体**：分诊（单次结构化分类）→ 查询/退款/升级 worker；掌握 State+reducer 的共享状态语义、subgraph 上下文隔离、Send 动态扇出；识别"复杂度搬家"反模式；
5. 建立 **LangGraph 心智模型**：State/节点/边/条件路由/编译产物（Pregel 运行时）——以及它与你熟悉的"以 messages 为状态的隐式状态机"之间的显式化关系；
6. 完成跨栈对照：v1 的 LC4j Agentic Services 五种编排器 ↔ LangGraph 对应物，能说清两边各自"仍然不管什么"；
7. 通过报销系统案例，内建"**agent 间只传结构化事实，散文只许出现在人机边界**"纪律，并理解 Decimal 类型在其中的作用。

---

## 2.1 全景光谱与本章路线

决策权从代码到模型的排序不变：固定流水线 → 计划-执行 → ReAct → supervisor 多 agent。各模式的典型失败方式表沿用 v1（ReAct 死循环漂移 / P&E 计划赶不上变化 / 多 agent 交接失真）。

Python 版路线图的差异项标注：

```
2.2 手写 ReAct        —— 与语言无关的原理课，用 model.bind_tools() 重做
2.3 create_agent 黑盒 —— 取代 v1 "AiServices 得失表"的位置，但多了 middleware 这层新答案
2.4 计划-执行          —— Plan 用 Pydantic Tagged Union；校验逻辑原样平移
2.5 supervisor        —— LangGraph 原生主场：State/reducer/subgraph/Send 首次齐装上阵
2.6 跨栈对照          —— 方向翻转：现在是 "LC4j/Spring AI 有什么、缺什么"
```

---

## 2.2 手写 ReAct：把 create_agent 拆开给自己看

### 2.2.1 消息序列就是控制流（这张图全球通用）

```
[messages 列表随轮次生长]
 SystemMessage  你是工单助手…… + [tools schema: get_ticket, create_ticket, check_inventory]
 UserMessage    T-1024 升级到 P1，顺便看看仓库 WH-3 有没有货
 AIMessage      tool_calls=[{"name":"get_ticket","args":{"ticket_id":"T-1024"},"id":"call_1"}]
 ToolMessage    call_1 → {status:OPEN, priority:P3, warehouse:WH-3}          ← 你执行后回填
 AIMessage      tool_calls=[{update_priority…}, {check_inventory…}]           ← 一轮可并行多个
 ToolMessage    call_2 → {ok:true}
 ToolMessage    call_3 → {stock:42}                                           ← 每个 call_id 必有回音
 AIMessage      (tool_calls 为空，content="已升级 P1，库存 42 件")             ← 终止信号
```

三条铁律（v1 原话保留，Python 语境重新表述）：

1. **每轮请求携带全部历史**——成本乘性放大的物理来源；
2. **"结束" = 这一轮的 AIMessage 没有 tool_calls**——你的循环退出判据是 `not ai.tool_calls`；
3. **AIMessage(tool_calls) 与其全部 ToolMessage 必须成对且按 call_id 配齐**——漏一个，多数 OpenAI-compatible 网关直接 400。这是新手手写循环的第一号 bug，也是 0.4 之后第二个"编译器不帮你"的重灾区（对策见练习 1 的契约测试）。

### 2.2.2 核心实现

```python
import asyncio, json
from dataclasses import dataclass, field
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage
from langchain.chat_models import init_chat_model

@dataclass(frozen=True)
class LoopPolicy:                        # ≈ v1 的 record LoopPolicy；frozen≈不可变 record
    max_turns: int = 8                   # 工单场景经验值 5~8
    max_total_tokens: int = 60_000       # 单次任务 token 硬顶（第 7 章红线一的前身）
    per_request_timeout: float = 20.0    # 单次 LLM 调用超时（秒）
    total_deadline: float = 90.0         # 端到端预算
    max_consecutive_same_tool: int = 3   # 防踱步探测器

class ReActLoop:
    def __init__(self, policy: LoopPolicy, tools: dict[str, "ToolDef"], model=None):
        self.model = (model or init_chat_model("deepseek:deepseek-chat")) \
                         .bind_tools([t.spec for t in tools.values()])
                         # ↑ bind_tools：把工具 schema 挂进每次请求（对照 LC4j 的 ToolProvider）
        self.tools, self.policy = tools, policy

    async def run(self, user_text: str) -> str:
        messages = [SystemMessage(self.system_prompt), HumanMessage(user_text)]
        spent = 0; streak_name, streak_n = None, 0
        loop_deadline = asyncio.get_running_loop().time() + self.policy.total_deadline

        for turn in range(1, self.policy.max_turns + 1):            # ① 轮数熔断
            remaining = loop_deadline - asyncio.get_running_loop().time()
            if remaining <= 0: break                                 # ② 总时限熔断
            try:
                async with asyncio.timeout(min(remaining, self.policy.per_request_timeout)):
                    ai: AIMessage = await self.model.ainvoke(messages)   # ③ 单请求超时
            except TimeoutError:
                return self._escalate("模型调用超时", messages)
            messages.append(ai)
            spent += ai.usage_metadata["total_tokens"]               # 累计花费（usage 随行即取）
            if spent > self.policy.max_total_tokens:                 # ④ token 硬顶熔断
                return self._escalate(f"超预算 {spent}", messages)
            if not ai.tool_calls:                                    # ⑤ 正常终止
                return ai.content

            for call in ai.tool_calls:                               # ⑥ 逐个执行并回填
                if call["name"] == streak_name:
                    streak_n += 1
                else:
                    streak_name, streak_n = call["name"], 1
                if streak_n >= self.policy.max_consecutive_same_tool:
                    return self._escalate(f"{call['name']} 连续 {streak_n} 次，疑似踱步", messages)
                messages.append(await self._execute_with_guard(call, turn))
        return self._escalate(f"达到最大轮数 {self.policy.max_turns}", messages)

    async def _execute_with_guard(self, call, turn: int) -> ToolMessage:
        audit.record(call, turn)                          # 埋点：谁/第几轮/什么参数（第7章消费）
        tool = self.tools.get(call["name"])
        if tool is None:                                  # 幻觉工具名兜底（第 3 章三层防线之①）
            content = json.dumps({"error": "UNKNOWN_TOOL",
                "detail": f"工具 {call['name']} 不存在",
                "advice": f"可用工具: {list(self.tools)}；或直接用文本回答"})
        else:
            content = await tool.safe_execute(call["args"])   # 错误四分类在 2.2.3
        return ToolMessage(content=content, tool_call_id=call["id"], name=call["name"])
```

> **☕ Java 锚点**：`asyncio.timeout` ≈ try-with-resources 包住一段代码的执行时限；`LoopPolicy` frozen dataclass ≈ record；整个类没有任何 DI 框架——构造函数注入，朴素但透明（Python 世界的 Spring 就是"你在 main 里自己 new"，第 8 章见工厂形态）。

> **⚠️ Python 坑**：`for call in ai.tool_calls` 里若某个执行抛了未捕获异常而你没有 append 对应 ToolMessage，messages 就出现孤儿 call_id，下一轮请求必 400。**规矩：`_execute_with_guard` 永远返回 ToolMessage，异常也在内部转成 error JSON**——让"配对完整"成为函数签名保证的性质。

### 2.2.3 工具执行的错误语义：四分类平移 + middleware 预告

v1 的四条法则原样成立（参数错回喂、业务败给 advice、系统故障上抛别污染模型、错误信息本身是指令面要做模板化）。Python 实现的两点更新：

- 落点从"内联在循环里"改为**独立的可复用单元**：`wrap_tool_call` middleware（2.3 节正式见面）——写一次，手写循环与 create_agent 两条路都能挂上；这正是 v1 "错误处置收敛进自己的装饰器链"思想在框架里的原生归宿；
- 参数校验天然长在 Pydantic 上：`ArgsModel.model_validate(args)` 抛 `ValidationError`，其 `.errors()` 结构（0.3 练习 2 整理过的那张表）直接序列化为回喂内容——**纠错提示的质量比 v1 高一档，因为字段路径/原因/期望类型全结构化**。

### 2.2.4 诊断"反复调同一工具"：三类根因表（概念照抄 v1）

① 工具描述歧义 → 重写 docstring/互斥声明（第 3 章规范）；② 结果不满意但说不出口 → **改工具返回值而不是改 prompt**（最高频真因：返回值缺字段，模型怀疑自己拿错了）；③ 缺少停止信号 → prompt 显式完成标准 / 提供 `finish(answer)` 终结工具。重申那条误区：**90% 的人第一反应是加"不要重复调用"进 prompt——没用，先改工具契约。**

---

## 2.3 create_agent 黑盒解剖：harness 给了什么，middleware 补什么

### 2.3.1 等价关系

```python
agent = create_agent(model, tools, system_prompt=..., checkpointer=..., middleware=[...])
# 展开 ≈ 一张预置的最小两节点图：
#   model 节点(LLM 调用) ⇄ tools 节点(执行 tool_calls)，条件边 = "有 tool_calls 就去 tools，没有就 END"
# ——你在 2.2 手写的 for 循环，被摊平成了图上的一条环。
```

这就是 LangGraph 生态最重要的认知：**高层 harness 不是另一套东西，它是你自己会画的那张图的官方预制件**。由此获得两个实惠：(a) `create_agent` 跑不动的场景不用换框架，退一步用 `StateGraph` 手工搭同款环再加料；(b) trace 结构完全一致，第 7 章观测一套管道通吃两种写法。

### 2.3.2 middleware：护栏与治理的标准挂点

```python
from langchain.agents.middleware import wrap_tool_call, wrap_model_call, before_model

@wrap_tool_call                                   # 洋葱模型（≈Servlet Filter / Spring Interceptor）
async def guard_and_audit(request, handler):      # request 含 tool_call 与已解析 args
    audit.record(request)                          # 进：审计埋点
    if request.tool.destructive and not request.approved:
        return interrupt({"kind": "approval", "tool": request.tool.name,
                          "args_json": request.raw_args})     # ← 第 5 章 HITL 的原生入口！
    result = await handler(request)                # 放行：进入真正的工具执行
    metrics.observe_tool(request.tool.name, result)
    return result                                  # 出：指标与改写

agent = create_agent(model, tools, middleware=[guard_and_audit, summarization_mw])
```

v1 那张"AiServices 得失对照表"在此逐行翻新：

| 生产需求 | v1-LC4j 的答案 | v2-LangGraph 的答案 | 仍需自建的 |
|---|---|---|---|
| 轮数/token 预算熔断 | listener 计数+抛异常 | recursion_limit（轮数）+ middleware 累计 usage 掐表 | **token 硬顶仍在 middleware 里自己写**（recursion_limit 只是弱约束——乘法维度限额依然是你的） |
| 工具执行超时 | executionCalculator | wrap_tool_call 内 `asyncio.timeout` | 半自建（机制现成，策略归你） |
| 错误语义定制 | 自定义 ToolExecutor | ToolNode 的 handle_tool_errors 开关 + middleware 改写 | 四分类路由逻辑仍是你写 |
| 审计埋点 | ChatModelListener | callbacks/middleware 双选择 | 审计 schema 与 sink 自建 |
| HITL 挂起恢复 | ❌ 全自建 | **interrupt()+checkpointer 原生** | 审批业务表/双人复核/哈希绑定自建（第 5 章） |
| 中途取消 | ⚠️ 非阻塞路径部分支持 | task.cancel 沿 await 点传播（0.4.3） | 断连检测与止损链路（第 8 章） |

结论公式也翻新：

> **v1：AiServices = 你的手写循环去掉所有生产钩子之后的样子。**
> **v2：create_agent = 手写循环 + 一半生产钩子的挂点。挂点免费，挂什么上去仍是你的架构。**

### 2.3.3 何时必须放弃 harness 用显式图

三个信号（任一命中即升格 StateGraph）：**(a)** 控制流不再是"LLM⇄tools 一条环"——需要人在环节外插确定性步骤（如 plan 校验失败重试规划、执行前 dry-run 预览节点）；**(b)** 需要 subgraph 组合与状态映射（多 agent 章节必然走到）；**(c)** 需要在模型调用之间做非 LLM 的条件分支/并行扇出（Send）。诚实说明：`create_agent` 的 middleware 表达能力在快速进化，今天的边界清单半年后可能收缩——**所以本课程坚持先学底层图，再用高层件**：知道预制菜怎么做的，才敢在宴会上用。

---

## 2.4 计划-执行：Plan 是 Pydantic 的主场

### 2.4.1 结构化建模（对照 v1 的 sealed interface）

```python
from pydantic import BaseModel, Field
from typing import Annotated, Literal, Union

class CallTool(BaseModel):
    kind: Literal["call"]                          # ← discriminated union 的判别标签
    tool: str
    args: dict = Field(default_factory=dict)        # 【注意】可变默认必须 factory（0.7 反模式#1！）
    binds_to: str | None = None                     # 输出写入 state 的键名

class ReasonFrom(BaseModel):
    kind: Literal["reason"]
    context_keys: list[str]
    instruction: str
    binds_to: str

class AskUser(BaseModel):
    kind: Literal["ask"]
    question: str

Step = Annotated[Union[CallTool, ReasonFrom, AskUser], Field(discriminator="kind")]
                                        # ≈ sealed interface + pattern matching 的静态类型版
class Plan(BaseModel):
    steps: list[Step]
    success_criteria: str

plan = planner.with_structured_output(Plan).invoke(task)   # LLM 输出直接反序列化为强类型对象；
                                                            # 不合法 → ValidationError → 带 errors() 重问一次
```

### 2.4.2 三道零成本静态校验（原样平移）

```python
def validate_plan(plan: Plan, registry: dict[str, ToolDef]) -> None:
    for s in plan.steps:                                   # ① 工具白名单
        if isinstance(s, CallTool) and s.tool not in registry:
            raise PlanError(f"未知工具: {s.tool}")
        if isinstance(s, CallTool):                        # ② 参数 schema 校验
            registry[s.tool].args_model.model_validate(s.args)
    _assert_dag(plan.steps)                                # ③ bindsTo 引用不成环、不引用未来步骤
```

Planner 幻觉出不存在的工具/非法参数，**在第 0 轮以零 token 成本拦下**——"错误越早暴露越便宜"原则不变。校验失败处理：把 `PlanError` 明细回填 planner 重规划一次，再失败降级 ReAct 或人工。

### 2.4.3 Executor 与 replan

执行器遍历 `plan.steps`：`CallTool` 走 2.2.3 的错误语义管线；`ReasonFrom` 才真正调 LLM 且**只喂绑定的 context_keys**（窄上下文=省 token 大头）。replan 触发器白名单（STEP_FAILED_UNRECOVERABLE / PLAN_STALE / BUDGET_OK 三前提）、次数上限 1、输入为"已完成步骤摘要+失败原因"——全部沿用 v1 设计，仅实现位置变成图上的 `replan` 节点 + 条件边回 `planner`。

LangGraph 表达（体会一下"计划-执行是中间态"的图形态——执行段是确定性的）：

```python
g = StateGraph(PlanState)
g.add_node("plan", plan_step)          # LLM 调用①
g.add_node("validate", validate_node)  # 纯代码（失败→回 plan 修复一次）
g.add_node("execute", execute_next)    # 纯代码循环消费步骤；CallTool 走工具、ReasonFrom 走 LLM
g.add_conditional_edges("execute", decide_next,   # 决定函数是普通 python 函数：
    {"next_step": "execute", "replan": "plan", "done": "synthesize"})
```

### 2.4.4 四维权衡表与"何时不该用"

成本/质量/可测性/延迟的分析框架照抄 v1（P&E 买的是确定性：把全局决策提前到信息最干净的瞬间、schema 校验拦截幻觉步骤，代价是应对变化的迟钝）。**步数可预见的复合任务选它，探索型任务别硬套**——环境反馈丰富的诊断类任务，强行规划=让模型装作它懂。

---

## 2.5 多智能体：supervisor-worker 与它的复杂度税

### 2.5.1 拆分逻辑与三种正当理由

单 agent + 20 工具 + 5 页 prompt 的退化路径不变；三种正当理由（上下文物理装不下/风险等级必须隔离/模型档位需要混用）与"复杂度搬家"自检三问全部沿用 v1。LangGraph 的新注脚：**worker 可以是 subgraph**——父图只见它的输入输出映射，内部轨迹独立成子 trace，上下文隔离是拓扑性质而非约定纪律。

### 2.5.2 State + reducer：v1 欠条的兑付现场

```python
from typing import Annotated
import operator
from langgraph.graph import MessagesState

class TicketState(MessagesState):              # 自带 messages 通道(add_messages reducer)
    facts: Annotated[list[TicketFacts], operator.add]   # ← reducer 声明：并发写=追加合并
    tier: str | None                            # 无注解 = 后写覆盖（last-write-wins）
    pending_approval: InterruptPayload | None
```

对照 v1 记下的三笔账：AgenticScope 是无类型 Map（现在 State 是 Pydantic/TypedDict，mypy 全程可查）；并发写同名 key 竞态未定义（现在 reducer 明确合并语义——`operator.add` 列表追加、自定义函数任意裁决）；无 checkpoint（现在 compile(checkpointer=...) 一行获得持久化+恢复+时间旅行）。**但注意兑付的代价**：reducer 概念有学习曲线（channel/superstep/Pregel 执行模型），团队新人上手期比 LC4j 的"就是个 Map"长——如实写进 ADR 代价栏。

### 2.5.3 结构化契约：Decimal 与禁转述纪律

v1 的正反面代码对照在此升级——Python 没有 record，但 Pydantic 更强：

```python
class TicketFacts(BaseModel):                  # worker 间的通行货币：结构化事实
    ticket_id: str
    refundable_amount: Decimal | None          # ← Decimal！float 参与的钱会在任何一次
    currency: Literal["CNY","USD"]             #   json.dumps/str()/摘要中转述里丢精度
    status: OrderStatus                        # enum 而非字符串
    as_of: datetime

# supervisor 传引用与事实，不传转述：
facts = query_worker.invoke({"ticket_id": tid})["facts"]      # subgraph 输出强类型
refund_decision = refund_worker.invoke({"facts": facts})       # 下游拿到的与源头逐位相等
```

规则一句话不变：**agent 之间传引用和事实，散文只允许出现在与人交互的边界上。** 2.7 案例会给这条纪律配上 Python 版的事故细节。

### 2.5.4 Send 动态扇出与 supervisor 的两种实现

v1 指出 LC4j 缺动态 fan-out（parallelBuilder 只能静态并行）——LangGraph 的 `Send` API 补上这一课：

```python
async def dispatch(state: TicketState):        # 运行时决定扇出数量（如：工单涉及 N 个仓库就派 N 个）
    return [Send("inventory_check", {"warehouse": w}) for w in state.warehouses]
g.add_conditional_edges("triage", dispatch)    # N 个并行 worker，结果经 reducer 汇入同一 State
```

supervisor 的实现姿势二选一：**(a)** 官方 `langgraph-supervisor` 库（handoff 模式：supervisor 用工具调用的形式"移交"控制权给专家 agent）——快糙猛，适合起步；**(b)** 自建分诊：单次结构化输出映射 enum + 条件边路由（1.8 的混合架构示例）——**本课程主推 (b) 打底**，理由与 v1 一脉相承："supervisor 的自主性预算应花在 worker 管不到的全局判断上，意图分类这种封闭决策不值得 handoff 的自由度"。(a) 留作对照实验（练习 4 两组对比）。

---

## 2.6 跨栈对照（方向翻转）：LC4j / Spring AI 眼里的 LangGraph

v1 时代的面试题"为什么不直接用 LangGraph"翻转为"**迁过来得到了什么、丢了什么**"——后者才是值钱的答案。

| 主题 | LangGraph (现主栈) | LangChain4j (对照) | Spring AI (对照) |
|---|---|---|---|
| 控制流表达 | 显式 StateGraph+条件边+Send | 声明式为主，agentic 模块命令式拼装(experimental) | Advisor 拦截链，编排基本靠手写 |
| 状态与并发 | 类型化 State+reducer | AgenticScope 无类型 Map，竞态自理 | ChatMemory 抽象，无编排态 |
| 持久化/恢复 | checkpointer 一行接入 | ❌ 自建（v1 第 5 章方案） | ❌ 自建 |
| HITL | interrupt/Command(resume) 原生 | ❌ 自建 | ❌ 自建 |
| 护栏扩展 | middleware 体系（活跃演进中） | 装饰器链自建（稳定但全靠自觉） | Advisor 链（同思路，生态更薄） |
| 类型安全 | mypy+Pydantic（可选强制） | javac 全程护航 | javac 全程护航 |
| MCP | python-sdk+adapters，生态最全 | 内置 starter，成熟度意外地高 | 官方推进中 |
| 组织语境 | 需自建 FastAPI/DI/部署件 | Spring Boot 全家桶无缝 | Spring 原生体验最优 |

**迁移得失的诚实清单**（写进 ADR-001r 附录）：

- 得到：checkpoint/interrupt/reducer/Send 四大件、评测生态主场、JD 曝光度；
- 失去：javac 级编译期保障（用 mypy strict+Pydantic 边界对冲回来八成）、Spring 的容器/事务/监控一体化（FastAPI 世界里这些要自己攒）、以及 JVM 在高并发 CPU 侧的既有优势（agent 服务 IO 密集，影响有限——GIL 对本场景基本无感，但要在压测报告里给出证据，第 8 章兑现）；
- 不变：五层架构、三特性、四分类、预算表、幂等纪律——**本课程的概念资产 100% 跨栈存活**，这个事实本身就是最好的面试论据。

---

## 2.7 企业踩坑案例：自然语言传参弄丢两位小数的报销系统（Python 复述版）

> 案例骨架同 v1 §2.7（OCR→合规→打款三 worker，转述丢精度，4 笔资金差错），此处聚焦 Python 栈的两个特有细节，证明教训如何落成语言级纪律。

**细节一：float 是共犯**。原事故复盘时有人提出"用 float 存金额至少不会写出'约 1234.5 元'"——恰恰相反：`1234.565` 经 `float()` 得 `1234.5649999999999`，`json.dumps(float)` 再截到 `1234.565` 看似复原，但 `round(2)` 的银行家舍入又吞一分。**Python 侧的制度化修复**：金额字段 lint 级禁用 float（ruff 自定义 rule 或 review checklist），全链路 `Decimal` + `quantize(Decimal('0.01'), ROUND_HALF_EVEN)` 统一精度语义——0.3 节那句"金额永远 Decimal"的伏笔在此回收。

**细节二：dict 传参是隐形帮凶**。worker 间最初用裸 dict 接力（`{"amount": "一千二百三十四元五角六分"}`——没人规定 dict 里必须有什么键），迁移到 Pydantic 后这类事故在**结构上不可能发生**：`TicketFacts.refundable_amount: Decimal` 要么解析成功要么 ValidationError 拒绝进入下一跳。复盘金句因此可以升级：

> **"摘要丢数据不可怕，可怕的是它丢的正好是你不能丢的，而你不知道。结构化契约让'丢'变得编译可见。"**

四条修复（结构化契约/数值不变量交叉核对/打款幂等键/对抗样本入 golden set）与三条带走纪律原样有效，不再赘述。

---

## 动手练习

> TicketAgent Python 仓库 `chapter02` 分支。工具面：mock 三件套（ch1 练习 3 产物）+ `update_ticket_priority`（写工具，为第 5 章埋点）。

**练习 1 · 手写 ReAct 完整闭环（6h）**
实现 2.2 的 `ReActLoop`：五道熔断全部生效；`_execute_with_guard` 永不产生孤儿 ToolMessage（用 property-based 风格测试验证：随机注入工具异常/慢响应后断言 messages 配对完整性）。真实模型侧：故意让 `get_ticket` 返回值缺 obviously 需要的字段，复现踱步行为，记录 `max_consecutive_same_tool` 在第几轮救场、落入 2.2.4 哪类根因。

**练习 2 · 双轨对比：手写 vs create_agent（4h）**
同一组 10 任务分别跑手写循环与 `create_agent`（挂 guard_and_audit middleware 补齐审计+错误四分类）：对比轨迹一致性（10 次运行几种路径）、总 token、失败处置差异。产出 `docs/ch02/handwritten-vs-create-agent.md`，回答："middleware 覆盖了 v1 得失表的几行？哪三行仍然必须显式图？"

**练习 3 · 计划-执行改造（5h）**
按 2.4 实现 Planner(with_structured_output)/validate_plan/图化 executor。设计 5 任务含一个"计划必然过时"陷阱（执行中途 mock 数据被改），验证 replan 白名单行为。统计并与练习 1 对比：10 任务集上 P&E vs ReAct 的成本/轮数/轨迹一致性三元组。

**练习 4 · supervisor 双实现对照（6h）**
(a) 自建版：分诊 enum + 条件边路由 + QueryWorker/StockWorker/EscalateWorker 三 subgraph，State 含 `facts: Annotated[list, operator.add]`；(b) langgraph-supervisor 库版。同一 15 任务集跑双版本，重点测两类对抗：并发双 worker 写 facts 的 reducer 合并正确性（asyncio.gather 制造真并发）；`1234.565` 金额流经全系统出口逐位相等断言（Decimal 纪律验收）。结论写进选型备忘录。

**练习 5 · Send 动态扇出实验（3h）**
构造"一张工单涉及 N 个仓库"的任务（N∈{1,8,32}），用 Send 扇出 inventory_check 并聚合；测量 N 对延迟/成本曲线的形状，找出供应商 RPM 限流的撞墙点（为第 8 章容量画像采集第一批数据）。

**练习 6 · 选型决策表（2h）**
沿用 v1：四形态×六列（适用特征/成本曲线/可测性/典型失败/切换信号/**不该用的信号**）默写后校对；用 ch1 练习 6 的 5 个场景套用一遍，每场景指定"裸 create_agent / 显式图 / P&E 图 / supervisor 图"四选一及理由。这张表是第 6 章消融实验的假设清单。

**练习 7 · 迁移笔记（1h）**
本章末「Java↔Python 迁移笔记」由你亲笔完成（≤10 行）：sealed interface→discriminated union、record→frozen dataclass/Pydantic、Stream 并行→TaskGroup/Send、AOP→装饰器洋葱……写得越具体，第 9 章博客素材越好。

---

## 本章小结

- **祛魅完成**：ReAct = 以 messages 为状态的隐式状态机；`create_agent` = 这张状态机的官方预制图。手写一遍的价值是让 middleware/条件边每一个挂点你都知道底下跑的代码——从此看任何 agent 框架源码不再有秘密。
- **熔断的正确维度**：recursion_limit 只管轮数（加法约束），token 硬顶必须自己在 middleware 里累计（乘法约束）——第 7 章红线的原型今天已立。
- **错误语义四分类找到了原生之家**：wrap_tool_call 洋葱链；Pydantic ValidationError 让"回喂纠错"从字符串艺术升级为结构化科学。
- **计划-执行买确定性**：Pydantic tagged union 建模 Plan、三道零成本校验、replan 白名单——把一半随机性推出执行路径；探索型任务别硬套。
- **多智能体的三大红利与一张账单**：上下文隔离（subgraph 拓扑保证）、风险分区（工具只注册给受控 worker）、模型分级（分诊小模型）；账单是通信协议税——所以 State+reducer+Decimal+禁转述纪律是上岗条件，不是可选项。
- **跨栈对照的方向翻转**：从"防御为什么不用 LangGraph"变为"讲清迁来得到了哪四大件、失去了 javac 与 Spring 容器、概念资产为何 100% 存活"——这份双面账本是两栈皆通者的署名作品。
- **下一章预告**：编排稳了，该看清 agent 伸出去的那只手了——@tool 的 docstring 如何变成模型眼中的法律、args_schema 生成的暗坑、几十上百工具的规模治理、以及把工单 API 反向暴露为 MCP server 的双向实操。你的 agent 已经会思考，接下来检验它的手套够不够厚。
