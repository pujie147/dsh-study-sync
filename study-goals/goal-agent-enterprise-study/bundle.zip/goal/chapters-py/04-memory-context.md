# 第 4 章 · 会话记忆与上下文工程（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：第 0 章（asyncio/contextvars）、第 2 章（State/reducer/checkpointer 初体验）、第 3 章（工具 schema 的 token 税）；goal1 第 2/4 章（ChatMemory 两窗口策略、检索管道）
> **建议学时**：22 小时
> **本章定位**：把"往窗口里放什么"当成有指标的工程项目。v1-Java 版的四大主题（短期记忆细节、持久化、压缩谱系、长期记忆、预算装配）全部保留，但实现层发生一次重要的**职责重划**：会话消息持久化从自建 `ChatMemoryStore` 升级为 **checkpointer 原生承担**、跨会话事实库从手搓 pgvector 表升级为 **Store 原生 namespace+语义检索**——框架接走了"存储引擎"，留给你的全是最值钱的部分：**裁剪配对纪律、摘要失真量化、写入时机判断、冲突裁决、预算表宪法**。GDPR 删除、身份传递（ThreadLocal→contextvars 的正确进化）、虚拟线程事故的 asyncio 变体，一节不少。

---

## 本章学习目标

1. 用 checkpointer 管理生产级会话状态：thread_id 复合键设计、Postgres saver 选型、pending writes 一致性、跨重启恢复语义；说清它比 v1 自建 ChatMemoryStore 多管了什么（编排态）；
2. 掌握消息窗口的三枚魔鬼：tool-call 配对完整性裁剪、SystemMessage 装配时注入（不进存储）、被裁消息的摘要回填（summarization middleware 的阈值与固定模板 digest）；实现指代消解双路线；
3. 建立**压缩谱系四级模型**（截断→滚动摘要→分层+事实卡片→外部化）及各级失真剖面，用探针回放测试量化"压缩偷走了什么"；
4. 用 Store 建长期记忆工程：namespace 分区、写入时机四级触发器、召回阈值与冲突显式化、记忆投毒三道闸与周期卫生；
5. 交付 TicketAgent 的 **ContextAssembler 全局预算表**（S1~S9 配额/降级次序/降级事件进 trace），并用 lost-in-the-middle 位置实验论证组装顺序；
6. 处理合规暗面：GDPR 删除的六处痕迹清单（含 digest 这类衍生数据）、contextvars 在异步链路的身份传播验收；
7. 通过电商摘要吞价格案例，内建"**关键事实走结构化旁路，绝不穿越有损压缩通道**"铁律。

---

## 4.0 四种失忆失败（开场案例原样保留）

"第 14 轮问'它现在是什么优先级'" 的四种失败——失忆/张冠李戴/精度蒸发/成本雪崩——与四条对策线的映射关系完全沿用 v1 §4.0（这是行为规律不是语言现象）。OS 内存管理类比重述一遍仍有必要：**窗口是 RAM，外部存储是磁盘，摘要是换页压缩，ContextAssembler 是页表+调度器**——而 Python/LangGraph 世界的更新是：checkpointer 相当于给你配了一块"带写前日志的持久化内存"，你不再手写刷盘，但**页表算法依然全是你的**。

---

## 4.1 短期记忆：checkpointer 时代的消息窗口

### 4.1.1 职责重划：先看清框架接管了什么

```python
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

pool = await AsyncConnectionPool("postgresql://...").open()
saver = AsyncPostgresSaver(pool)
await saver.setup()                                   # 自动建表：checkpoint/checkpoint_writes/blobs

agent = create_agent(model, tools, checkpointer=saver)  # ← 一行，会话持久化完成
graph = builder.compile(checkpointer=saver)             #    显式图同理

# 调用侧：thread_id 就是会话主键
config = {"configurable": {"thread_id": f"{tenant}:{user}:{session_uuid}"}}
result = await agent.ainvoke({"messages": [HumanMessage(text)]}, config)
```

对照 v1 那张自建 RedisChatMemoryStore 方案，checkpointer 多做了四件事：**(a)** 存的不只是消息列表，而是**整个编排状态**（走到哪个节点、各 channel 值、待执行任务）——重启后能从中断处续跑而非从头再来（第 5 章 HITL 的地基今天打好）；**(b)** 每个 superstep 一个快照版本，天然支持历史分支查询（time travel）；**(c)** 并发写的 pending writes 有协议保证（部分节点结果先落盘再合并）；**(d)** messages reducer 自动做追加合并，不会丢消息。

**仍然归你的三件事**（别高兴太早）：窗口裁剪策略（checkpointer 只忠实存储，不替你遗忘）、digest 生成质量、以及下面这个 thread_id 设计。

### 4.1.2 thread_id 即租户边界：服务端派生纪律

v1 的 `@MemoryId` 教训原样平移且更尖锐——checkpointer 的 API 决定了**拿到 thread_id 就能读写那个会话的全部状态**：

```python
# ❌ 灾难：thread_id 直接采信客户端
config = {"configurable": {"thread_id": body.session_id}}

# ✅ 正确：复合键服务端派生（对照 v1 SessionKey record）
def derive_thread_id(user: Principal, session_uuid: uuid.UUID) -> str:
    return f"{user.tenant_id}:{user.user_id}:{session_uuid}"
    # 租户前缀 → saver 层可按前缀统计活跃会话/配额计数/批量删除（注销即删前缀全部 thread）
```

隔离、配额、批量删除三个抓手全靠这个键式设计——这是 goal1"身份贯穿"课题在记忆侧的镜像，一字不改。

### 4.1.3 裁剪配对完整性与 SystemMessage 钉住

两条 v1 定律在 Python 侧的实现件：

- **配对完整性**：LangChain 提供 `trim_messages(token_counter=..., max_tokens=...)`，较新版本已理解 tool-call 配对（AIMessage+其 ToolMessages 作为原子单元）——但**版本敏感，写测试钉死**：构造恰好卡边界的序列，断言任何裁剪结果不含孤儿 ToolMessage（v1 练习原样回归）；自定义 counter 记得算上工具的 schema tokens，否则"按 token 裁剪"名不副实；
- **SystemMessage 移出存储**：checkpointer 会把 messages 全存——若 system prompt 也在消息列表里，prompt 改版后存量会话会带着僵尸规则复活。纪律同 v1 终态：**system 属"装配时注入"不属"记忆存储"**——用 `create_agent(system_prompt=...)` 参数形态（每请求现拼）或 before_model middleware 注入，threads 里只滚对话事实。改 prompt 立即对存量会话生效 + 审计可记版本戳，两个红利照单全收。

### 4.1.4 摘要回填：summarization middleware 与其改造点

官方内置件负责"溢出即压缩"的粗活：

```python
from langchain.agents.middleware import SummarizationMiddleware

summ = SummarizationMiddleware(
    model=init_chat_model("deepseek:deepseek-chat"),      # 小模型干压缩（成本纪律 L1）
    trigger=("tokens", 6000),                             # 溢出阈值
    keep=("messages", 6),                                 # 近期保真条数
    summary_prompt=OUR_DIGEST_TEMPLATE,                   # ★ 换成我们的固定模板 digest
)
```

★ 处是本课的主张：默认模板产的是自由散文摘要，我们要 v1 定义的**结构化 digest**——必填槽位「背景/诉求/已决事项/**未决承诺**/明确否决项」，尾部那句"无未决事项"必须存在（防模型脑补延续性任务）。改造方式即自定义 summary_prompt + 输出经 Pydantic DigestModel 校验（生成物也要过类型关——摘要本身可能是幻觉载体，4.3 细讲）。重写频率降档（攒一批再压）与"禁改区"概念（4.6 案例处方）一并在此挂上。

### 4.1.5 指代消解双路线（概念平移）

A 线 query rewriting：`QueryTransformer` 思想的 LangChain 原生表达（小模型 Runnable：输入近期原文+digest，输出自包含问题）；B 线实体焦点轨：在 State 加 `focus_entities: Annotated[list[Entity], merge_ledger]` reducer，每轮从消息抽取活跃实体，装配时以 `[会话焦点]` 注入。**组合策略不变：A 打底，高价值会话开 B**；B 的可测性优势（焦点命中率=纯字符串比对）也不变。

---

## 4.2 持久化的合规与身份暗面

### 4.2.1 GDPR 删除：checkpointer 改变不了清单的恐怖

框架接管存储后，删除义务反而更需要全景图——v1 六处痕迹表基本保留，两处更新：

| 存储位 | v2 删除手段 | 备注 |
|---|---|---|
| 会话消息+编排态 | `saver.delete_thread(thread_id)`（较新版本提供；无则按 checkpoint 表前缀 DELETE——**先写测试证明真删干净**） | 备份轮换期残留的合规口径仍要写明 |
| digest/摘要 | 在 checkpoint blobs 里随 thread 删；独立缓存的另删 | "摘要是衍生数据"教训保留 |
| Store 长期记忆 | `store.delete(namespace=(tenant,user))` 整 ns 删除 | v1 手搓 SQL 变原生 API |
| trace/观测 | Langfuse 按 user tag 删+匿名化 | 自托管红利不变 |
| 审计日志 | **假名化非删除** | 依法保留例外，法务口径前置 |
| 检索语料中的用户内容 | 按 doc_id 删向量行 | pgvector 行删即可（ADR-003 红利） |

新增一栏警示：**checkpointer 的历史快照意味着"同一份个人数据有多个时间版本"共存**——删除必须覆盖该 thread 的全部 checkpoint 而非最新指针。这条查起来极隐蔽（框架升级都可能悄悄改表结构），给删除编排服务写集成测试时用"翻遍所有行找手机号正则"的暴力验证。

### 4.2.2 身份传递：从 ThreadLocal 碎裂到 contextvars 正解

v1 那道"虚拟线程下 SecurityContext 偶发丢失"的题，在 Python 栈以三种新形态出现，逐条给验收动作：

1. **忘传 config 的裸调用**：某些辅助 Runnable 没带 `configurable.thread_id` 就静默用了新会话——表现为"工单办到一半失忆"。对策：RunnableConfig 统一由入口中间件注入，lint 级禁止绕过工厂函数直接 `.invoke()`；
2. **TaskGroup 子任务的上下文**：好消息，contextvars 在 task 创建时自动拷贝快照（0.4.4），principal 天然隔离不串——**但要实测**（练习 4：并发双租户流量断言零串号）；
3. **fire-and-forget 后台任务的身份过期**：`asyncio.create_task` 里跑的收尾工作（记忆提取、通知发送）拿着已登出的 step token（第 5 章）去调 API——401 幽灵。对策：后台任务入队时携带显式的操作凭证副本与有效期声明，不依赖 ambient context 的长生幻想。

> **☕ Java 锚点**：这节的整体叙事可以概括为一句面试可用的话："JVM 用二十年没治好 ThreadLocal 的池化碎裂病，Python 拿 contextvars 一步到位——代价是双色函数逼你把每条链路写清楚。两种哲学，各有账单。"

---

## 4.3 压缩谱系：每一级都在偷东西，标好价签（全节概念保留）

L0 截断→L1 滚动摘要（漂移+幻觉注入两大病）→L2 分层+事实卡片→L3 外部化（artifact 引用+回捞工具）的四级剖析、失真剖面表、"存活率×成本"探针回放测试法——**方法论 100% 沿用 v1 §4.3**（那是信息论层面的事，与栈无关）。本版给三处实现更新：

- **L3 外部化有了官方样板**：deepagents 的文件系统抽象（长工具输出自动 offload 到虚拟 FS，上下文只留引用，agent 可用 read_file 回捞）就是 L3 的产品化——本课仍要求手写最小版（State 里存 artifact_ref + 一个 `read_artifact` 工具），因为懂原理的人才能诊断"模型想不起去看 artifact"这种病；
- **探针框架 pytest 化**：埋事实→脚本拖轮次→回收提问的参数化测试矩阵，天然适配 `@pytest.mark.parametrize`（第 6 章 harness 的同族兄弟，今天先建雏形）；
- **对抗探针升级**：专杀"摘要吞精度"的样本这次带上 Decimal 陷阱（`1234.565`、中文大写金额、千分位混排）——0.3/2.7 埋的线在这里收。

选型拐点经验保留：会话平均 >30 轮或跨天续聊 → L1 漂移债不划算，上 L2+L3 混合。

---

## 4.4 长期记忆：Store 给了抽屉，纪律还是你的

### 4.4.1 原生设施速览

```python
from langgraph.store.postgres import PostgresStore

store = PostgresStore(pool, index={                      # index=语义检索配置：
    "configs": {"embeddings": embedder},                  #  embedder 复用 ADR 冻结的 BGE-M3
    "dims": 1024, "fields": ["value", "$"]})              # fields=$ 表示全文都参与向量化

facts = await store.abatch_get_search(
    [("ticketagent", "facts", user_id)],                  # namespace ≈ v1 的 (tenant,user) 复合分区
    query="退款额度", limit=4, filter={"type": "SCOPE"})   # 命名空间+语义+元数据过滤三合一
```

对照 v1：手搓 LongTermFact 表+pgvector 索引+检索器的活儿，Store 一层 API 收编——**但注意它收编的全是"不值钱的部分"**。写入时机、冲突裁决、污染防御这些 4.4.2~4.4.4 的内容，Store 一个字都没替你决定。

### 4.4.2 写入时机四级触发器（表原样保留）

用户明说"记住…"直写 / 会话收尾批量结构化提取 / 重复模式计数阈值 / 工具执行产生的系统事实——四类高置信时刻；✗ 不做每轮即时提取（成本×噪声双杀）。提取产物仍是强类型：

```python
class LongTermFact(BaseModel):
    type: Literal["PREFERENCE","SCOPE","COMMITMENT","PROFILE"]
    value: str
    evidence_quote: str          # 防腐回溯：当初凭什么写的这条
    confidence: float
    expires_at: datetime | None  # 大部分长期记忆应有保质期；COMMITMENT 单独强校验
```

### 4.4.3 检索克制与冲突显式化

小 k（3~5）、高阈值（错召回的记忆会被模型当真——它对进窗口的"关于自己的事实"毫无防御心）、优先序裁决（新 writtenAt > 来源等级 > **矛盾摆进上下文让模型向用户核实**）三条全保留。Store 的相似度分数正好喂阈值参数（v1 还要自己算 cosine，今天白送——又一个"框架接管不值钱部分"的例子）。

### 4.4.4 记忆投毒三道闸

攻击剧本（伪造"提高退款上限"指令借提取器驻留）与三闸（来源分级：仅用户本人陈述/本系统 API 返回值可入写入通道；高危 fact_type 进人工复核队列；周期卫生任务：过期清理/聚类去重/突增告警/抽样体检）原样有效。实现挂钩更新：闸①落在提取器的 evidence 校验（evidence 出自检索文档一律拒收），闸②直接复用第 5 章审批队列（一套 HITL 基建两处开花），闸③做成定时 cron graph（LangGraph 应用结构里的标准件）。

---

## 4.5 Context Assembler：预算表是宪法（全节资产平移）

S1~S9 预算表、降级次序（S8→S5→S7→S6→S4→S2→熔断转人工）、永不降级项（S1/S9）、**降级事件写进 trace 不许藏**、"分不清答错还是没看到，一切调参都是玄学"——v1 §4.5 整段是本章含金量最高的设计工件，与语言零冲突，直接搬进 `memory/assembler.py`。

Python 实现的落点更新：装配发生在 **before_model middleware**——它在每次 LLM 调用前拿到完整 State，正是"现拼本次请求视图"的标准舞台：

```python
@before_model
async def assemble(request, handler):
    view = assembler.build(                       # 预算表驱动，纯确定性代码
        system=request.state.system_versioned_prompt,     # S1 装配注入（不入存储，4.1.3）
        tools=tool_governor.for_this_turn(request.state), # S2 第 3 章动态工具面在此合流
        facts=await memory_store.top_facts(request.state.user_id),  # S4
        rag=await retriever.budgeted(request.state.query, cap=S5),  # S5
        history=trim_pair_safe(request.state.messages, cap=S6),     # S6 配对安全裁剪
        digest=request.state.digest,                              # S7
    )
    trace.record_assembly(view.budget_report)      # 各区段实际占用与降级事件 → 第 7 章消费
    return request.override(messages=view.messages)
```

lost-in-the-middle 位置实验（同一事实置 5%/50%/95% 各测回收率）方法与"供应商换代须重测"的纪律保留——Python 侧连实验脚本都用同一套 pytest 参数化骨架。

---

## 4.6 企业踩坑案例：摘要器吃掉的那两位小数（案例通用，修复件换装）

v1 §4.6 全文有效（滚动摘要灰度指标漂亮→促销价在 digest 里蒸发→重查遇世界变化→300 单双向资损；三重叠加失误与"均值型指标对尾部失真免疫"的排查教训）。四条修复在 v2 的实现落点：

1. **关键事实结构化旁路** → State 的 `SessionFacts` 通道（reducer 只允许追加不允许摘要触碰）+ assembler 把它列为 S3 禁裁区；
2. **摘要禁改区** → DigestModel 固定 schema，数值字段以引用标记 `[价格承诺: F#77-A]` 形式保留，SummarizationMiddleware 的 prompt 模板强制之；
3. **可变事实带新鲜度** → fact.as_of/ttl 由 assembler 检查，过期即注入警示行（"该价格获取于 11 轮前，请先刷新"）——把"要不要重查"从模型自觉变成系统提示；
4. **探针回归进 CI** → 4.3 的存活率测试矩阵挂 `-m eval` marker，压缩策略变更必须全绿才可发布。

复盘金句照抄："摘要丢数据不可怕，可怕的是它丢的正好是你不能丢的，而你不知道。"

---

## 动手练习

> `chapter04` 分支。产出物（预算表/存活率曲线/探针测试）将被第 6 章直接引用。

**练习 1 · checkpointer 底座（4h）**
AsyncPostgresSaver 接入（compose 加 PG 实例或复用 pgvector 库）；thread_id 复合键派生中间件；孤儿 ToolMessage 边界测试；time-travel 体验作业：取某 thread 的第 3 个 checkpoint 从那里 fork 重放一次，写 5 行观察（这个能力 v1 完全没有——记录你的第一反应）。

**练习 2 · 摘要管线（4h）**
改造 SummarizationMiddleware 用 DigestModel 固定模板（含"未决承诺"槽位）；实现 L0~L3 四级策略类 + 探针回放框架（50 通脚本会话×8 类探针事实，Decimal 对抗组在内），产出"存活率×成本"曲线并写 5 行选型 ADR（预期 L2+L3 混合）。

**练习 3 · 身份与合规（3h）**
contextvars 三事故验收（串号并发测试/漏传 config 检测/后台任务凭证过期复现）；GDPR 删除编排服务（六处痕迹一键删+暴力正则扫库证明删净，含 checkpoint 历史版本）。

**练习 4 · Store 长期记忆闭环（4h）**
PostgresStore+BGE-M3 index 上线；收尾批量提取器（结构化输出+evidence 校验闸）；冲突裁决测试（新旧额度矛盾→断言"矛盾显式化"文案出现）；记忆投毒攻防（伪造提额指令样本流经全链路，断言被来源分级闸拦下——与第 3 章注入样本库共用弹药）。

**练习 5 · Assembler 与位置实验（4h）**
before_model 装配器按预算表现拼；降级次序故障注入（超长 RAG+大历史逼逐级降级，断言顺序严格且事件进 trace）；lost-in-the-middle 三位置×20 次实验，据结果修订摆放策略并回填 BudgetPolicy 常量。

**练习 6 · 阅读对照（1.5h）**
读 deepagents 的 context management 源码片段（文件系统外脑如何实现 L3）+ LangGraph Memory 概念页（Store vs checkpointer 分层），写 12 行笔记回答：**"store/checkpointer 的双层设计与 v1 时代我们自建的两套设施相比，哪笔账框架替你还了、哪笔仍欠着？"**

---

## 本章小结

- **职责重划是本章的最大新闻**：checkpointer 接管消息+编排态持久化（含并发协议与 time-travel 赠品），Store 接管事实库的存储与检索——框架还走的都是"不值钱的部分"；窗口纪律（配对裁剪/system 装配注入/digest 模板）、失真量化、写入判断、冲突裁决、预算宪法，一件不少地留在你手里。
- **thread_id 即租户边界**：服务端派生复合键的老教训换了马甲依然致命（拿到 id 即拿到全部会话状态）；GDPR 删除因"多版本快照"变得更难而非更容易。
- **压缩没有免费午餐**：L1 漂移+幻觉、L2 调度复杂度、L3"有而不用"；先划不可压缩物禁改区（价格/数量/ID/时限/承诺），再谈压缩——探针存活率曲线是唯一可信的选型依据。
- **长期记忆三分法原样成立**：写入纪律、检索克制（小 k 高阈值矛盾显式化）、卫生机制（来源分级抗投毒）——Store 给了抽屉，往里面放什么、什么时候不放，仍是治理问题。
- **预算表是宪法，降级要留痕**：before_model 是它的执行舞台，trace 是它的执法记录仪。
- **下一章预告**：记忆的欠条已还清，剩最后一张——跨请求生命周期的"人在环节点"。第 5 章把 interrupt()+checkpointer 这对原生搭档配上审批业务表，交付真正的危险操作管控：风险分级、参数哈希绑定、幂等贯穿、沙箱限爆与红队穿透矩阵。
