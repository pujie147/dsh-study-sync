# 第 7 章 · 可观测性与成本治理：trace、指标与预算熔断（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：ch2/3（middleware 洋葱链——埋点的标准挂点）、ch4（降级事件留痕约定）、ch5（审计≠日志分界、审批等待时长概念）、ch6（评测与观测共用 span schema 的伏笔）；ADR-004 冻结项（Langfuse 自托管 + OTel GenAI semconv）
> **建议学时**：20 小时
> **本章定位**：把 agent 从黑盒变成玻璃盒。v1-Java 版的观测治理体系（span 四原则、记录裁决表、双写采样、四族指标、三级核算、三道闸、隐私边界）**全量继承**；换栈改变的是施工方式：LC4j 时代手写的 `OtelChatModelListener` 胶水层，现在由 **LangChain callbacks 体系 + 原生 OTel instrumentation** 供料，且出现"双轨制"的真实处境——**LangSmith（框架亲儿子级自动 trace，含 time-travel）与 Langfuse+Tempo（中立自托管，ADR-004 冻结项）并存**。本章教你把两条轨道都接上、划清各自的数据边界，并借 v1 攒下的全部治理直觉完成一次"开箱体验 vs 供应商锁定"的清醒评估。一夜 $8k 案例的两条红线照常实装验证。

---

## 本章学习目标

1. 设计 agent 特有的 **span 层级**（run→assemble→llm.call#N→tool.call→interrupt），掌握循环步编号、决策依据上挂、护栏动作一等事件三原则；处理跨进程（MCP）与跨天（审批回调）的 trace link 语义；
2. 掌握 **OTel GenAI 语义约定**（`gen_ai.*` 属性族）核心字段；打通 callbacks/middleware → OTel span 的管道；配置 Collector 双写（Langfuse+Tempo+成本旁路）与 tail-based 内容采样；
3. 客观评估 **LangSmith ∥ 自建 OTel 双轨**：各自看什么、数据边界怎么划、锁定风险怎么对冲——形成"平台便利性与中立性"的成熟选型论述；
4. 建立 **agent 四族指标**：步级延迟分解、token/成本计数族、质量代理族（拒答率双侧/幻觉工具名率/护栏拦截率突变）、资源族；Grafana 三板块+exemplar 深链；
5. 实现 **per-request/per-user/per-tenant 三级成本核算**（价格表版本化/task_type 维度）与**三道预算闸×五级降级阶梯**（每级服务端确定性开关）；
6. 完成 prompt caching/检索复用/模型分级三板斧的**省钱实测**（质量回归背书后才算数）；
7. 守住 **trace 隐私边界**：默认不存原文、哈希+回源指针、保留期自动化测试、Langfuse 自托管分区设置；
8. 通过 $8k 烧钱案例实装并演练**两条红线**：per-run token 硬顶 + 连续同类失败快速熔断。

---

## 7.0 三个凌晨三点的电话（原样保留）

"用户投诉胡说八道→那次请求看到了什么？"/"P95 怎么变 14s→慢在哪一步？"/"账单为何翻倍→哪个租户哪类任务最烧钱？"——三种来电对应三件交付物（trace 回放/延迟分解/三级核算）的诊断逻辑与语言无关。重申那句总评：**agent 观测的新东西只有两处——观测对象多了概率性决策过程，以及账单第一次成为一等公民指标。**

---

## 7.1 Span 层级设计（四原则不变，参考树换标注）

```
trace: ticketagent.request
└─ span[agent.run]  (tags: thread_id, tenant, mode=supervisor)     ← LangGraph 自动建根
   ├─ span[context.assemble]                                        ← before_model middleware
   │    └─ event: budget.downgrade(S8裁剪/RAG topK 4→2)             ← ch4 降级事件在此收编
   ├─ span[llm.call #1]                                             ← callbacks 自动+补属性
   │    attrs: gen_ai.model, usage.input/output/cached_tokens, finish_reason, ttft_ms
   ├─ span[tool.call get_ticket]                                    ← wrap_tool_call middleware
   │    attrs: tool, args_hash, risk_level, guard.outcome, duration
   ├─ span[guard.blocked refund_ticket rule=daily_cap]              ★ 护栏动作一等事件
   ├─ span[interrupt approval#a47f]                                 ← 只记挂起动作(毫秒级)，
   │                                                                     等待时长走指标(ch5 5.2 呼应)
   └─ span[llm.call #2] ...                                         ← step.index 显式编号
```

四条切分原则逐条保留（外部 I/O 独立成 span/循环步显式编号/决策依据挂 span 而非藏文本/护栏动作一等事件），每条的"切错病症"论证照旧——尤其第二条：**step.index 是 L2/L3 轨迹指标的取数字段，ch6 引擎直接消费它**，这是"评测观测同源"的物理接口。

### 7.1.2 记录裁决表（全表平移）

args_hash 必录+值脱敏截断、工具返回摘要化+大 payload 落 artifact 引用、RAG 片段只存 doc_id/chunk_id/score、system prompt 存版本号+hash、用户原文默认 hash（调试采样会话例外，短保留期）——v1 表一字不换。新增一行 Python 特有：**State channel 快照**（LangGraph 每 superstep 的状态 diff 是免费的诊断金矿——checkpointer 里本就有，trace 里放 checkpoint_id 指针即可按需回查，别复制进 span 属性）。

### 7.1.3 trace 传播：老问题在 asyncio 里的新形态

三条战场更新：**(a)** contextvars 让 trace context 随 task 自动拷贝（0.4.4 红利——v1 的虚拟线程 wrap 胶水在这里基本消失），但 **fire-and-forget 后台任务与跨进程 MCP stdio 仍需业务键接力**（trace_id 塞 MCP `_meta`/pending_action 表列，隔天审批回调以 **Link** 而非 child 挂接——避免"一个 trace 活三天"的怪物，v1 结论原样有效）；**(b)** 评测/cron 流量打 `trigger=cron|eval` 标签与生产隔离（ch6 纪律的观测侧执行）；**(c)** LangGraph 子图（subgraph）自动生成嵌套 run——父子关系免费，但**跨 subgraph 的 step 全局编号要在 State 里自己带计数器**（否则 supervisor 下两个 worker 都冒出"#1 llm.call"，L3 归因会迷路）。

---

## 7.2 双轨制：callbacks → OTel → LangSmith ∥ Langfuse

### 7.2.1 数据流全景

```
LangChain/LangGraph 运行
   ├─▶ [轨道A] LangSmith：LANGSMITH_TRACING=true 即全自动 trace（含 state diff/time-travel）
   │            —— 适合：开发调试、prompt 迭代、评测集互转(ch6)、事故第一现场
   └─▶ [轨道B] OpenTelemetry：官方 instrumentation 产出 gen_ai.* 语义 span
                └─▶ OTLP ─▶ Collector ─┬─▶ Langfuse(自托管：生产看板/评分关联/成本归集)
                                       ├─▶ Tempo/Jaeger(与 JVM? 不——与 FastAPI/PG 基础设施同图)
                                       └─▶ 成本旁路(轻流→聚合表)
      ★ 数据分区纪律：生产真实用户流量默认只走轨道B(自托管不出域)；
        轨道A 仅接收脱敏样本与开发环境流量 —— ADR-004 中立性主张的具体执行
```

对照 v1 的变化一句话：**当年是"listener 手搓胶水对接 OTel"，今天是"两条现成轨道各取所需"**——但"开箱有自动"不等于"不用懂"：自动 span 的粒度（一次 model 调用一个 run）恰好满足 LLM call 层，而 assemble/guard/interrupt 这些**你的架构私有概念**仍要 middleware 手工补 span——7.1 的四原则一条都没被自动化消灭，只是自动化帮你完成了机械部分。

### 7.2.2 semconv 对齐速查（表沿用 v1）

`gen_ai.operation.name / provider.name / request.model / response.model / usage.input_tokens / usage.output_tokens / conversation.id / tool.name / tool.call.id`；MCP 有独立属性组（ch3 的 server 失败率分析靠统一口径）。**约定优先于聪明**的理由保留：换平台=重写仪表盘，自造属性名=交接靠口传。

middleware 补私有 span 的最小样例：

```python
@wrap_tool_call
async def traced_tools(request, handler):
    with tracer.start_as_current_span(f"tool.call {request.tool_call['name']}") as sp:
        sp.set_attribute("gen_ai.tool.name", request.tool_call["name"])
        sp.set_attribute("agent.args_hash", sha256(canonical(request.tool_call["args"]))[:16])
        try:
            out = await handler(request)
            sp.set_attribute("agent.guard.outcome", "ok")
            return out
        except GuardRejected as e:
            sp.set_attribute("agent.guard.outcome", f"blocked:{e.rule}")   # ★ 拦截也成事件
            raise
```

### 7.2.3 采样与"观测不得成为故障源"

trace 全量、内容采样的裁决保留；tail-based（Collector 端按属性决定全文保留：含 guard.blocked/error/成本超阈）优先于 head sampling 的理由保留。Python 侧新增两检查：**BatchSpanProcessor 队列满丢弃策略要显式配置并监控 drop 计数**（默认静默丢让你以为没发生）；kill Collector 演练证明业务零阻塞（v1 练习 2 的验收仪式原样继承——这条不分语言）。

---

## 7.3 指标体系（四族与告警艺术全保留）

延迟族（run 级由 step 级求和构成，堆叠面积图找病灶迁移）、token/成本族（direction/model/tenant/task_type 四维标签）、质量代理族（**拒答率两侧都告警**——骤升=检索/行为漂移，骤降=护栏可能被绕过；**护栏拦截率突变是最灵敏安全哨兵**；幻觉工具名率=漂移哨兵；finish_reason 分布突变=供应商改参前兆）、资源族（in-flight runs/bulkhead 拒绝数/队列深度）——v1 §7.3 完整有效，比率告警最小分母规则保留。

burn rate（SLO 误差预算消耗速率）替代静态阈值少八成误报的实操、Grafana 三板块信息架构（大盘/异常聚焦/exemplar 下钻入口）、"指标到 trace 最后一公里"的 exemplars 机制——全部平移。Python 件：prometheus_client 或 OTel metrics exporter 二选一（推荐后者，与 span 同一 SDK 一套属性词表）。

---

## 7.4 成本治理（三级核算/三道闸/五阶梯/侦探手册——全保留）

S1~S9 预算表管"每次请求花多少"，本节管"整体花得值不值、失控怎么办"。以下内容 v1 §7.4 整节资产原样继承，此处仅列核对清单：

- **三级核算**：per-request（listener 顺手记账→异步批量落库）/ per-user-day / per-tenant-month 事实表；task_type 维度靠 ch2 分诊器副产品；**价格表带生效日期版本化**（财务味细节=真做过信号）；
- **三道闸**：闸1 per-run token 硬顶（ch2 LoopPolicy 的正牌落地）→ 触顶优雅收尾+budget_exhausted 计数；闸2 用户日预算→降级阶梯；闸3 租户月预算→运营告警+并发减半；
- **五级降级阶梯**（L1 经济模型路由→L2 缩工具面→L3 上下文激进模式+caching 最大化→L4 只读模式→L5 熔断转人工）：**每一级都是服务端确定性开关，不赌模型配合**；降级事件全部进 trace 与告警；
- **省钱三板斧**：prompt caching（稳定前缀前置——与 ch4 装配顺序联动的实测，缓存命中率与综合降幅用数据说话）/检索结果语义指纹短 TTL 复用/模型分级路由（消融表授权才砍）；**任何省钱手段先过 ch6 质量回归，裂口报警即回滚**；
- **归因侦探 SOP**：维度切片找增量归属→曲线形状定性（阶跃=发布/斜坡=自然增长/尖刺=重试风暴）→trace 样本看步数分布→错误类型定位→flag 止血→对抗回归入集。

---

## 7.5 隐私边界（三分法与操作清单保留）

观测数据的第三种合规身份（既非证据亦非产品数据）、默认不存原文、回源指针+**调阅动作本身产生审计**的套娃设计、保留期清理要有自动化测试、截图文化的制度配套、"自托管≠免罪金牌——保留期与访问面才是风险函数"——v1 §7.5 全节有效。双轨制补充一条分区纪律（7.2.1 已画）：**出域到商业平台的样本必须经脱敏管线，且该管线自身有测试与变更评审**——它是新的单点。

---

## 7.6 LangSmith 对照阅读（方向翻转的一节）

v1 此节是"LangGraph 有什么我们没有"；v2 翻转为"**平台便利 vs 中立自建**"的双面账，作为 ch9 跨框架论述的观测篇素材：

| 维度 | LangSmith 开箱 | 自建 OTel+Langfuse |
|---|---|---|
| 初装工时 | ≈0（一个环境变量） | 1~2 人日（Collector 管道+属性对齐） |
| 独有诊断力 | state diff 可视化、time-travel fork 重放、prompt 实验对比 UI | 无等价物（checkpoint 手动 fork 勉强追平七成） |
| 数据主权 | SaaS（有自托管企业版但另一笔账） | 完全出域可控，GDPR 分区清晰 |
| 锁定面 | trace 格式/dataset 生态黏性强 | semconv 标准出口，换后端=改 collector 配置 |
| 成本 | 订阅费+席位 | 服务器+维护人力 |

本课立场（写进 ADR-004 附录）：**双轨并用、职责分区**——开发/调试/评测迭代吃平台红利，生产流量与敏感数据留在自托管轨道；每季度做一次"假设明天不能付钱给 LangSmith"的逃生演习（导出 pipeline 与 dataset 迁移脚本跑一遍）。**"用平台的糖，留自己的井"**——这句话本身就是面试加分观点。

---

## 7.7 企业踩坑案例：一夜 $8,412——限流、重试与一个不设防的循环

> 案例全文见 v1 §7.7（法规 API 维护窗口返 429→HTTP client 通用重试不看 Retry-After→错误回喂模型→模型"换个关键词再试"→maxTurns=25×巨型上下文的乘法放大→340 并发撞模式→四小时烧掉年度预算 1/6；四条根因对准缺失；两条红线修复）。机理与语言无关，v2 版把"当时的错误长什么样"翻译成 Python 栈的对照，证明同样的坑在新栈依然张着嘴：

**死亡链条的 v2 栈复现要点**（混沌注入实验，练习 4 正式做）：

1. tenacity 默认 `retry_if_exception_type((Timeout,))` 式的粗分类同样会把 429 归为可重试——**L1 重试层必须显式区分 429 分支读 Retry-After**（ch8 主讲，今天先在 trace 里看到它的恶果）；
2. LangChain 的工具错误回喂（handle_tool_errors 默认开）若不配异常分类，效果等同当年的"一律回喂"——**ch3 四分类 middleware 是唯一解药**；
3. recursion_limit 默认值宽松且只管轮数——**乘法维度限额（token 硬顶）在闸1 落实**；
4. 没有成本实时观测时，Python 程序烧钱的速度与 Java 分毫不差：**发现时延×燃烧速率=事故规模**这道算术题没有语言方言。

两条红线的验收标准也原样：**per-run token 硬顶**（超出即优雅收尾+显式未完成声明）与**连续同类失败熔断**（`tool.consecutive_failures{code}` ≥3 → 本次 run 下线该工具+跨 run 高频则全局熔断进降级阶梯）；外加"发现烧钱"时延目标从次日账单改为 **15 分钟燃尽告警**。

---

## 动手练习

> `chapter07` 分支。compose 增补 otel-collector + tempo；langfuse 已有。

**练习 1 · 双轨埋点施工（5h）**
轨道A 一键接通（LANGSMITH_TRACING）；轨道B 完成 7.1 参考树全部私有 span（assemble/guard/interrupt/step.index 编号/subgraph 全局计数）；gen_ai.* 属性对齐；验收：随机一条生产 trace 能回答"它第 3 步为什么选 close_ticket 而不是 update_priority"（含当时可见上下文清单+checkpoint_id 指针）。

**练习 2 · Collector 管道与韧性（3h）**
一分三出口+tail-based 内容采样（guard.blocked/error/高成本强制全文）；kill Collector 演示业务零阻塞+drop 计数可见；埋点前后 P95 差 <5% 压测证明。

**练习 3 · 指标与五条告警（4h）**
四族指标+Grafana 三板块+exemplar 深链；五条告警（延迟分解突变/工具失败率/拒答双侧/拦截率突变/成本燃尽）逐条注入演练验证会响——没响过的告警不算存在。

**练习 4 · 复演 $8k 事故（4h）**
mock 供应商 429 风暴（带 Retry-After），先拆掉防线复现死亡链条前半段（记录模拟账单增速），再依次启用四分类 middleware/Retry-After 感知退避/token 硬顶/连续失败熔断，展示事故如何分别在第 3 轮和第 15 分钟被掐灭；输出修复前后模拟账单对比表。

**练习 5 · 成本实测与优化备忘录（3h）**
三级核算上线+价格表版本化；prompt caching 稳定/不稳定前缀两版各 100 次多轮会话对比 cached_tokens 占比与综合成本；检索复用 TTL 敏感性测试；每项手段附 ch6 质量回归结果，产出《成本优化备忘录》。

**练习 6 · 隐私验收（1.5h）**
正则扫 Langfuse 导出数据断言 PII 零命中；回源指针调阅流程证明"调阅产生审计"；保留期清理任务+其自动化测试；轨道A 出域样本脱敏管线及其测试。

**练习 7 · 对照与逃生演习（1.5h）**
写 7.6 双面账的本地版（你实际接入后的工时/能力盘点）；执行一次"LangSmith 逃生演习"：dataset 导出→Langfuse 侧重建评测集→评测跑通，全程计时记录卡点。继续 cost-log（本期科目：观测管道自身的资源开销）。

---

## 本章小结

- **四原则没有被自动化消灭**：外部 I/O 成 span、循环步编号（step.index=L2/L3 取数字段）、决策依据上挂、护栏动作一等事件——开箱 trace 只覆盖机械层，你的私有概念（assemble/guard/interrupt）永远要亲手挂。
- **双轨制是成熟不是骑墙**：LangSmith 吃开发红利与 time-travel 独门诊断，生产与敏感数据守自托管边界；"用平台的糖，留自己的井"+季度逃生演习，把锁定风险变成受控变量。
- **semconv 当普通话**：gen_ai.* 词表+MCP 属性组保证跨平台可聚合——约定优先于聪明。
- **指标可操作性来自分解**：P95 拆到步、拒答率盯两侧、拦截率突变当安全哨兵、burn rate 替静态阈值、exemplar 打通最后一公里。
- **成本是一等公民的三件套**：三级核算（价格表版本化）、三道闸（限额设在 token×轮数的乘法维度）、五级阶梯（每级确定性开关）；省钱手段不过质量回归就不算省钱，算埋雷。
- **两条红线来自真金白银**：$8k 案例在 Python 栈的每个环节都能原样复现——教训的价值正在于它的语言无关性；发现时延×燃烧速率=事故规模，目标 15 分钟。
- **下一章预告**：玻璃盒造好、账单看得见了——但看见故障不等于扛得住故障。第 8 章把 tenacity/pybreaker/TaskGroup 的武器库对准模型、工具、网络三个不稳定源，把本章"发现"的一切变成"自愈"的动作，最后用六幕混沌+k6 给你的系统出具一份有数字签名的体检报告。
