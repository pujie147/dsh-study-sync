# 第 3 章 · 工具调用工程与 MCP / A2A 协议（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：第 2 章（ReAct 循环、wrap_tool_call middleware、错误四分类）、第 0 章（Pydantic/装饰器）；goal1 第 5 章（提示注入初步防御）
> **建议学时**：24 小时
> **本章定位**：上一章管住了 agent 的"大脑"，这一章解剖它的"手"。工具是 agent 与世界的一切接口，因此也是**攻击面与故障面的最大来源**。v1-Java 版的全部治理思想原样保留（描述即 prompt、schema 是动作空间边界、错误语义是架构决策、MCP 要当供应链管），实现层换装：`@tool`+Pydantic args_schema 取代 `@Tool/@P` 反射链路，官方 MCP python-sdk + langchain-mcp-adapters 取代 LC4j starter（生态反而更厚）。所有工具按『可测试、可审计、可熔断』三标准重做一遍。

---

## 本章学习目标

1. 讲清 `@tool` → JSON Schema 的生成链路（docstring/类型注解/Field description 三路汇流），能预测任意 Python 签名生成的 schema 形状并管理其漂移；
2. 掌握工具描述写作规范（动词开头/触发条件/互斥声明/失败预告），并用探针任务量化"改描述前后的误选率"；
3. 用 wrap_tool_call middleware 落地错误语义四分类的**基础设施化**，读写工具分离与注册期门禁制度化；
4. 建立工具规模治理三级火箭：分组暴露 → bind_tools 动态子集/tool_search → embedding 召回（RAG-for-tools），量化 schema 的 token 税；
5. 完成 MCP 双向实操：**FastMCP** 把工单 API 暴露为 server、langchain-mcp-adapters 消费外部 server；说清 tools/resources/prompts/sampling 原语、transport、协议版本 pin 纪律与 OAuth 现状；
6. 建立 MCP 威胁模型与分层防御（描述投毒评审/lockfile+哈希漂移检测/返回值定界/后果封顶），把"信任要可验证"写进接入流程；
7. 客观评估 A2A 现状，回答"跨 agent 通信何时值得上协议而不是直接 RPC"；
8. 通过第三方 MCP server 静默投毒案例，带走三条供应链纪律。

---

## 3.1 工具是什么：从函数签名到模型决策的完整链路

### 3.1.1 @tool 的三路汇流

```python
from pydantic import BaseModel, Field
from langchain_core.tools import tool

class GetTicketArgs(BaseModel):                 # 路线③：显式 args_schema（推荐，控制力最强）
    ticket_id: str = Field(description="工单号，格式 T-数字，如 T-1024")

@tool(args_schema=GetTicketArgs)                # ≈ v1 的 @Tool + @P 合体，但 schema 来源可见可控
async def get_ticket(ticket_id: str) -> TicketView:
    """查询指定工单的当前状态、优先级与归属仓库。只读操作，可安全重复调用。

    使用场景：需要了解工单现状时。若用户询问的是政策/流程而非具体工单，
    请改用 search_knowledge_base。
    失败形态：工单不存在时抛 ToolException(NOT_FOUND)，请勿重试，引导用户核实单号。
    """                                        # ← 路线①：docstring 成为工具 description
    ...
```

三路信息源合成发给模型的 `ToolSpec`（对照 v1 的反射链路图）：

```
docstring(路线①) ─┐
类型注解+默认值(②)─┼→ name/description/args JSON Schema → 每轮请求的 tools[] 数组 → 模型的动作空间
Field.description(③)┘                                          （它"能想到的动作"到此为止）
```

核心认知平移：**description 不是文档，是 prompt 的一部分；schema 不是校验器，是模型想象力的物理边界。** 差异在 Python 里这条链路更透明——不依赖反射猜参数名（0.7 反模式之外的另一桩 Java 迁移福利：`inspect.signature` 天然可读，不需要 `-parameters` 编译选项这种考古知识）。

三个会咬人的细节（v1 清单翻新）：

- **裸类型推断的坑**：不写 args_schema 时框架从函数签名推导——`dict`/`Any` 参数生成空泛 schema，模型自由发挥；`str | None` 可选参数的 required 标记历史上版本敏感 → **本课程纪律：所有对外工具一律显式 Pydantic args_schema**，把不确定性清零；
- **枚举优于自由字符串**：`priority: Literal["P1","P2","P3","P4"]` 进 schema 的 enum 约束，误参率断崖下降——能用类型表达的约束永远不留给描述文字（v1 定律原样生效，Literal 就是 Python 的 enum 惯用法）；
- **返回值的自解释性**：返回裸字符串 vs 返回带 `status/reason` 字段的 dict，对模型下一步行为的影响巨大（2.2.4 根因②"结果不满意"多半治在这里）。**结构化返回是默认姿势**，Pydantic 模型 dump 即可。

### 3.1.2 Schema 快照测试：防"活物"漂移

v1 的教训在 Python 侧更重要（无编译器兜底 + 框架自动推导更多）：

```python
def test_tool_schemas_snapshot():
    actual = {t.name: t.args_schema.model_json_schema() for t in EXPORTED_TOOLS}
    assert actual == load_baseline("tests/baselines/tool_schemas.json")
    # ↑ 任何签名/Field/docstring 改动都会 diff 出红 —— 工具契约变更从此走 review 流程
```

这就是"工具契约是公共 API"的制度化：改一个 Field description 和改一个 REST 端点一样需要评审。第 9 章 README 里这算一条加分治理项。

### 3.1.3 描述写作规范与度量闭环

六规则表原样沿用 v1（动词开头/写明何时该用与不该用/输入输出示例/副作用与幂等声明/失败形态预告），Python 版补充一句：**docstring 的缩进与格式会被原样喂给模型**，写得像给新同事看的交接文档就对了。

度量闭环不变：每工具建 5~10 条"该用它"+5 条"容易误用它"的探针任务，跑选择准确率——第 6 章 golden set 的种子。面试金句同款："我优化过工具选择准确率，改了 X 描述后误选率从 8% 降到 2%"。

### 3.1.4 幻觉工具名三层防线

① 执行前查注册表，未注册名回填 `UNKNOWN_TOOL + 可用列表 + advice`（2.2.2 已实装）；② 供应商侧 `tool_choice`/strict 模式按需启用（各网关支持度不一，先测后用）；③ 幻觉率作为指标上报（第 7 章漂移哨兵）。原则重申：**纠错回填让模型自愈 + 事件记录供归因**，别为幻觉工具名终止整个会话。

---

## 3.2 错误语义基础设施化：从内联代码到中间件链

v1 在 `GuardedToolExecutor` 装饰器链里做的事，本章正式搬进 middleware 栈——同一个洋葱，标准的挂点：

```python
@wrap_tool_call
async def tool_pipeline(request, handler):
    spec = REGISTRY[request.tool_call["name"]]
    try:
        args = spec.args_model.model_validate(request.tool_call["args"])   # ① schema 违规
    except ValidationError as e:
        return ToolMessage(content=json.dumps({"error": "INVALID_ARGUMENT",
                    "detail": e.errors(), "hint": "修正参数后可重试一次"}),
                    tool_call_id=request.tool_call["id"])                  # → 回喂模型
    match spec.classify(await spec.precheck(args)):          # ② 业务/权限预判
        case "biz_fail":                                     # 业务否定：回喂但给出路
            return _result(request, {"error": "NOT_FOUND", "advice": "告知用户，勿重试"})
        case "risk_deny":                                    # 风控拒绝：上抛+独立告警通道
            alert_sink.security_event(request); raise GuardRejected(...)
    try:
        async with asyncio.timeout(spec.timeout_s):          # ③ 系统故障：上抛走韧性层
            out = await handler(request.replace(tool_call_args=args))
        audit.ok(request, out)
        return _result(request, out)
    except (TimeoutError, ConnectionError) as e:
        audit.sysfail(request, e)
        raise ToolSystemFailure(request.tool_call["name"]) from e
```

四分类裁决表（schema 违规回喂/业务否定带 advice/系统故障上抛/风控拒绝告警）逐行照抄 v1 §3.2——**这张表是全课程复用率最高的资产之一**。两个 Python 特有注脚：

- 异常类型设计成 `ToolException` 子类族：LangChain 默认会把 `ToolException` 转成回喂内容，其余异常向上炸穿——**"回喂还是上抛"的路由由异常类型决定**，比 v1 靠框架默认语义猜测干净得多（自定义异常层次≈Java checked exception 的表达力补偿）；
- 错误文案模板化白名单（第 5 章注入防御的前置）：`e.errors()` 这类结构化的字段级错误可以回喂，**裸异常栈绝不回喂也不落 trace 原文**。

### 读写分离与注册门禁（v1 铁律的 Python 制度形态）

```python
@dataclass(frozen=True)
class ToolDef:
    spec: BaseTool
    kind: Literal["read", "write"]              # 强制标注，无默认值——漏标=构造失败
    idem: IdempotencyPolicy | None = None       # write 必须提供，见 __post_init__
    risk: RiskLevel | None = None               # 第 5 章风险矩阵的挂载点

    def __post_init__(self):
        if self.kind == "write":
            if self.idem is None or self.risk is None:
                raise RegistrationError(f"{self.spec.name}: 写工具缺幂等策略或风险定级，拒绝注册")
```

启动期断言 fail-fast 的精神从 v1 原样继承（那时是"未定级拒启"，这里合并了"无幂等策略拒启"——第 8 章重复出票案例的两半处方提前埋好）。

---

## 3.3 工具规模治理：schema 是昂贵的上下文资产

三重代价分析（token 税粗算/选择退化/攻击面扩大）与三级火箭完全沿用 v1 §3.3，此处只更新实现件：

| 层级 | v1-LC4j 手段 | v2-LangGraph 手段 |
|---|---|---|
| 静态分组 | per-agent 工具白名单 | 每个 subgraph/agent 实例 `bind_tools(子集)`——supervisor 架构天然红利 |
| 动态暴露 | ToolProvider 运行时问询 | before_model middleware 改写本次请求的工具列表；内置 `tool_search` 类中间件（大工具集按需检索加载的模式已被官方产品化） |
| 语义召回 | 自建 embedding 路由 | 同一套 pgvector 管道（goal1 资产复用），索引对象换成"工具名+描述+典型触发句"；起步阈值同 v1：<30 分组够用，>50 上召回 |

逃生口设计保留（模型宣称"没有合适工具"时允许扩权一轮 top-K 放大重问，事件计入指标）。成本饼图纪律保留：每轮 prompt token 中 schema 占比长期挂仪表盘——**这个数字驱动一切治理**。

---

## 3.4 MCP：把工具从私有财产变成生态协议

### 3.4.1 定位与原语（概念全保留）

M×N→M+N 的解耦逻辑、六大原语信任含义表（tools/resources/prompts/sampling/roots+notifications/elicitation）、"annotations 只是 hint 不可作放行依据"的警告——v1 §3.4.1/3.4.2 整段有效。本版新增一行生态事实：**MCP 已是跨阵营共识**（OpenAI/Google/Microsoft 相继采纳，Claude Code/VS Code/JetBrains 原生支持），学一次通吃多栈——这是它在课程权重高于 A2A 的原因。

### 3.4.2 Transport 与版本 pin 纪律

```python
# 客户端（消费方）——langchain-mcp-adapters 把 MCP 工具直接转成 LangChain tools：
from mcp.client.streamable_http import streamablehttp_client
from langchain_mcp_adapters.tools import load_mcp_tools

async with streamablehttp_client("https://mcp.vendor.com/mcp",
                                 headers={"Authorization": f"Bearer {gw_token}"}) as (r, w, _):
    async with ClientSession(r, w) as session:
        await session.initialize(protocol_version="2026-07-28")   # ★ 显式 pin，禁 auto-negotiate
        tools = await load_mcp_tools(session)                     #   → bind_tools(tools) 即用
```

要点平移自 v1：stdio 适合本地/容器化 server（Docker 起社区 server 实测用这个）；远程生产选 **streamable HTTP**；协议规范正从无状态会话向 2026-07-28 无状态化版本演进，**版本碎片化真实存在——pin 版本 + 哈希基线**的理由与 v1 一字不改。OAuth 2.1 路线（PKCE/dynamic client registration）已在规范确立但生态参差，务实姿势不变：外部 server 当"自带凭据的第三方依赖"管理，凭据绝不经模型上下文，企业侧统一走自家网关代理。

### 3.4.3 实操一：FastMCP 把 TicketAgent 暴露为 server

Python SDK 自带的 FastMCP 让服务端薄到令人警惕（越薄越要护栏）：

```python
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("ticketagent", host="0.0.0.0")     # streamable HTTP 挂在 /mcp

@mcp.tool()
async def ticket_get(ticket_id: str) -> dict:
    """查询工单状态/优先级/归属仓库。只读。"""
    principal = current_principal.get()           # contextvars！0.4.4 的伏笔在此回收——
    return await svc.get_authorized(ticket_id, principal)   # MCP session 绑定终端用户身份

@mcp.resource("tickets://{ticket_id}/attachments")
def attachment_list(ticket_id: str) -> list[str]: ...       # 资源以 URI 寻址暴露

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
```

三条红线原样强制（练习 3 验收）：**身份透传**（网关 mTLS+短 JWT → contextvar → ACL 过滤，否则你的 MCP server 就是绕开 goal1 权限体系的旁门）；**工具面收缩**（对外只读三件套，写操作待第 5 章审批建成再开）；**审计独立标签**（MCP 通道流量单独核算 rate limit 与 trace tag）。

### 3.4.4 实操二：消费外部 server 的治理开关

`load_mcp_tools` 之后接本课自己的治理层（对应 v1 的 filterToolNames/nameMapper/resultAttributes 三件套）：

```python
allowed = lockfile.approved_tools("community-fetcher")      # 白名单来自 lockfile（3.5）
tools = [t for t in mcp_tools if t.name in allowed]
tools = [prefix_rename(srv_key, t) for t in tools]          # 命名空间消歧（多 server 同名）
tools = [wrap_untrusted(t) for t in tools]                  # 返回值 <untrusted> 定界包装
```

实测清单沿用 v1 练习 4 三观察（描述质量打分/注入载荷试探/断网行为）。

---

## 3.5 MCP 安全：供应链信任模型的重建

**三类攻击机理、lockfile 方案、四层防御**全部继承 v1 §3.5（tool poisoning/rug pull/间接注入的描述一字不易——攻击针对的是协议与模型，与宿主语言无关），本版做两处 Python 化落地：

```yaml
# mcp-servers.lock —— 与 uv.lock 并列进版本库，CI 每日比对
- server: community-fetcher
  url: https://mcp.example-community.com/mcp
  protocol_pin: "2026-07-28"
  image_digest: "sha256:..."
  tool_hashes:                       # name+description+schema 规范化后的 sha256
    fetch_url: "sha256:a1b2..."
```

漂移检测实现从"handler 里比对"升级为 **before_model middleware 巡检**（每次装配工具列表时顺手验哈希，漂移即摘除该工具+告警）——治理逻辑长在标准挂点上，这是 v2 相对 v1 的实现红利。

四层防御回顾（标记为数据 `<untrusted>` 定界 / 清洗过滤 / **后果封顶：高危动作不吃软约束**——第 2/5 章的结构保证被注入的模型顶多在只读工具间空转 / 溯源：每条工具结果带 server 出处进 trace）。

---

## 3.6 企业踩坑案例：静默更新的第三方 MCP server（案例通用，附 Python 取证细节）

v1 §3.6 全文有效（六周静默投毒：HTML 注释藏指令、诱导 log_session 外传上下文、用完即删工具；根因三连与四项制度修复）。本版补一段"如果发生在 Python 栈"的取证细节，演示 lockfile 体系如何把六周压缩到六小时：

```python
def test_no_tool_drift():                        # CI 每日跑，红=阻断发布+P2 告警
    for srv in ACTIVE_SERVERS:
        live = {t.name: canonical_hash(t) for t in fetch_tools(srv)}
        base = lockfile.hashes(srv)
        added, removed, changed = live.keys()-base.keys(), base.keys()-live.keys(), \
            {k for k in live & base if live[k] != base[k]}
        report_or_raise(srv, added, removed, changed)
        # 本案在第 2 周就会红：log_session ∈ added；第 4 周会红：fetch_url ∈ changed
```

配合 Langfuse 的 per-tool 调用统计（第 7 章），还能反向发现"声称 readOnlyHint 的工具出现在写路径计数里"这类 annotations 撒谎信号。**三条带走的教训原文保留**：信任的单位是每次调用不是每次采购；检测能力价值≥预防话术；最小工具面同时是成本优化与攻击面预算。

---

## 3.7 A2A 速览与跨 agent 通信判断（概念全保留，Python 生态位更新）

判定树、两条前瞻认知（协议解决发现与信封不解决信任与语义；跨 agent 传引用不传转述）沿用 v1 §3.7.2。生态更新两点：

1. **a2a-python SDK 已发布**（Linux Foundation 项目官方实现），且 Google ADK 原生支持 A2A——协议阵营在扩容，但"规范完备、真实跨组织生产部署仍少"的判断维持；
2. LangChain 系的跨 agent 互通目前走自有 handoff/subgraph 机制，A2A 适配在路线图推进中——**结论不变：读规范、留接口缝（把 supervisor 的分诊出口抽象成可替换的 TaskClient 接口）、不实现**。

对照阅读（方向翻转版）：LC4j 的 MCP 集成意外成熟（内置 starter 一等公民）、Spring AI 的 Advisor 链与 middleware 同构——三栏对照表并入第 9 章总表维护，本章只需记住：**协议层的选型自由度远大于编排层，MCP/A2A 学一次全栈通用**。

---

## 动手练习

> `chapter03` 分支。验收总纲不变：每个工具都有 schema 快照测试、描述评审记录、错误处置测试、trace 标签。

**练习 1 · Schema 显微镜（3h）**
导出全部工具的 `model_json_schema()` 存档为快照测试；三种签名对比实验（裸 str 参数/Literal enum/嵌套 Pydantic），每种 10 次跑记录产参违规率；体验一次"忘写 Field description 后模型开始猜"的现场。产出 `docs/ch03/schema-lab.md`。

**练习 2 · 错误管线矩阵（4h）**
完成 3.2 的 tool_pipeline middleware + ToolDef 注册门禁；mock 下游制造四类故障各 5 例，断言路由正确（回喂样本含 `e.errors()` 结构、系统故障确实上抛到韧性钩子、风控拒绝进了独立告警 sink）；同步/流式两种调用路径各跑一遍契约测试。

**练习 3 · FastMCP server 上线（5h）**
按 3.4.3 暴露工单三件套：contextvar 身份透传打通（网关 JWT filter→ACL 过滤验证）、只读工具面、独立审计标签；用 MCP 官方 inspector 冒烟，再用自家 adapters client 端到端。写《对外 MCP 发布 checklist》一页（简历工件）。

**练习 4 · 外部 server 攻防三幕（5h）**
(a) 接入社区 server：pin 协议版本+白名单+哈希 lockfile 全套；(b) 注入演练：让它 fetch 你自建的藏指令页面，验证 `<untrusted>` 定界与后果封顶；(c) rug pull 模拟：本地 mock server 运行中篡改描述，展示 `test_no_tool_drift` 如何变红。三幕 trace 截图归档。

**练习 5 · 规模治理实验（4h）**
工具面膨胀到 60（含 10 对近义干扰组），三档方案跑同一 20 任务集：全量 bind / 静态分组 / before_model 动态召回 top-8。记录 schema token 占比、误选率、成功率，产出对比图表（面试"上下文经济学"白板素材）。

**练习 6 · 工具描述 A/B（2h）**
挑误选率最高的 2 个工具重写 docstring（按 3.1.3 六规则），探针集前后各 20 次算误选率变化，记入 `docs/ch03/desc-ab.md`。

**练习 7 · 阅读与备忘录（1h）**
读 a2a-python SDK README + 一张 Agent Card 实例，15 行备忘录：TicketAgent 未来一年唯一可能需要跨 agent 互操作的真实场景、为何现阶段直接 RPC+结构化 DTO 更优、TaskClient 接口缝留在哪。继续记 cost-log（本期新增"MCP server 独立进程的资源开销"科目）。

---

## 本章小结

- **工具链路的每一环都是决策面**：三路汇流的 schema 划动作空间、docstring 即 prompt、结构化返回值治"踱步"根因、Literal/Pydantic 把约束从文字移进类型。快照测试让契约变更走 review——"工具契约是公共 API"。
- **错误语义找到了原生之家**：wrap_tool_call 洋葱链 + 异常类型路由（ToolException 系回喂、其余上抛）；四分类裁决表照抄执行；读写分离与注册门禁（无幂等策略/无风险定级即拒绝注册）把第 5、8 章的两大铁律提前焊死在启动期。
- **schema 税持续可见**：三级火箭（分组/bind 子集/召回+tool_search）与成本饼图纪律不变——治理的动力来自那个百分比。
- **MCP 是学一次通吃全栈的协议资产**：FastMCP 十分钟建 server 的便利恰恰要求三条红线的自觉；协议版本 pin、白名单、哈希 lockfile 三件套把"运行时自我修改说明书的动态依赖"关进制度的笼子。
- **信任的单位是每次调用**：三类攻击、四层防御、六周→六小时的检测差——v1 案例的每一条教训在 Python 栈都找到了更顺手的实现位。
- **A2A 姿势**：读透、留缝、不实现；跨 agent 的第一性问题仍是"传引用不传转述"与"协议不解决信任"。
- **下一章预告**：手戴好了手套，轮到脑子失忆的问题——checkpointer 接管会话持久化后，剩下的仗在"窗口里放什么"：压缩谱系失真量化、Store 长期记忆写入纪律、ContextAssembler 预算表。第 2 章你见过轨迹漂移的惨状，第 4 章从源头治理它。
