# 第 8 章 · 可靠性治理：重试、降级、幂等与容量韧性（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：ch2（错误四分类）、ch3（wrap_tool_call 管线/注册门禁）、ch5（幂等键/HITL 状态机/step token）、ch7（两条红线/降级阶梯/成本观测）；goal1 第 8 章规划（SSE/连接池基础件概念）
> **建议学时**：22 小时
> **本章定位**：看得见之后要扛得住。v1-Java 版的可靠性体系（F1~F10 故障图谱、三层重试栈、D0~D5 降级梯子、幂等+saga、超时预算、流式并发韧性、混沌六幕+k6 三维曲线）**全量继承**；换装清单：Resilience4j → **tenacity + pybreaker + asyncio.timeout/TaskGroup + anyio semaphore**，以及一个重要增量——LangGraph 的 **durable execution/fault tolerance** 能力让"编排层的崩溃恢复"从 v1 的手写 progress 表扫描升级为框架原生（我们仍手写最小版懂原理，再对照原生配置）。重复出票案例照常压轴——它对语言零感知，对纪律重若泰山。

---

## 本章学习目标

1. 背熟 F1~F10 故障图谱与总纲"**区分故障在跟谁说话**"（基建→韧性层/内容→模型至多一次/语义→护栏评测），并能按此设计分层重试栈；
2. 用 tenacity 实现传输层正确重试（429 单独伺候+Retry-After+配额账本+retry budget），理解重试在 token 预算内跳舞的成本联动；
3. 实装 D0~D5 降级梯子：双供应商兼容测试矩阵、快慢信号分级触发、half-open 回升与振荡保护、D4"影子 workflow 平时养"制度；
4. 打通幂等终拼图（意图派生键/canonical 序列化/去重与业务写同事务/重放含失败结果的作废窗口）与 saga 补偿注册制、progress 滞留态扫描；并说清 LangGraph durable execution 接管了其中哪一段、没接管哪一段；
5. 制定超时预算分配表（deadline 递减传递/每环节处置预定/TTFT 三段拆），实现进度账本驱动的部分结果交付；
6. 建成流式与并发韧性：断连取消止损链路（is_disconnected→task cancel→收益实测）、SSE 续传三态、asyncpg 池 sizing、anyio 舱位隔离与优先级准入；
7. 组织六幕混沌演练日并用 k6 产出"并发-延迟-成本"三维曲线与成本拐点报告；
8. 通过双张票案例掌握"超时是量子态——写操作超时后第一个动作是读"与读写分离注册门禁。

---

## 8.0 故障图谱与总纲（原样保留）

F1~F10 十行表（四个 ★ agent 新增格子：畸形输出/语义跑偏/有毒返回值/成本放大器）与总纲路由规则全文继承。**真实事故按链条发作**（F1→F4→F9=第 7 章那晚）的观察不变。Python 侧只补一行生态注记：F8"网络与进程"这一族里，GIL 不在名单上——agent 服务是 IO 密集，GIL 只在 CPU 段（本地 embedding/rerank 批处理）现身，对策是 to_thread/multiprocessing 或干脆交给推理服务；压测报告里给出证据即可（练习 6），别凭传闻焦虑。

---

## 8.1 三层重试栈（架构不变，武器换装）

```
┌─ L3 语义层 ─ "任务没完成" ─ 编排层决定，默认禁止，白名单+预算前提
├─ L2 内容层 ─ "输出不可用" ─ 换输入再试(纠错提示)，至多 1 次
└─ L1 传输层 ─ "没送达/没答上" ─ tenacity: 指数退避+jitter+429 专属分支
```

### 8.1.1 L1：tenacity 的正确开法（对照 Resilience4j 记忆）

```python
from tenacity import retry, retry_if_exception, stop_after_attempt, \
                     wait_exponential_jitter, before_sleep_log

def _should_retry(exc: BaseException) -> bool:
    if isinstance(exc, RateLimited):        # 429: 可重试，但必须听服务器的话
        return True                          #   （Retry-After 在退避计算里消费，见下）
    if isinstance(exc, (TransientServerError, ConnectionError)):
        return True
    return False                             # 其余一律不重试——白名单思维！
                                             # ≈ Resilience4j 的 retryOnException 谓词，
                                             #   但 Python 默认"什么都不重试"，粗心的反方向风险小些

@retry(retry=retry_if_exception(_should_retry),
       stop=stop_after_attempt(3),                    # LLM API 瞬时故障恢复快，3 封顶
       wait=_smart_backoff(),                          # 自定义：有 Retry-After 就 max(它, 退避值)
       before_sleep=before_sleep_log(log, WARNING))
async def call_provider(req): ...
```

三个进阶件（概念平移自 v1）：**本地配额账本**（收到 429=乐观估计错了，通道进冷却期主动错峰，而非每个请求各自碰壁——一个 dict+monotonic 时钟的小类）；**retry budget**（tenacity 无内置，滑窗计数自己包一层：过去 10s 重试占比 >20% 即停止新重试直接降级——防 retries 风暴的第二次洪峰）；**重试计入 per-run token 硬顶**（SDK 内的悄悄加戏被闸1 罩住——限额在预算内跳舞的原则不分栈）。观测 `agent.retry.count{layer,reason}` 常驻，某通道重试率 >5% 提前路由。

### 8.1.2 L2 内容层：换输入再试，止于一次

v1 的两条洞察原样保留：**(a)** 概率性错误对同参重跑几乎不变（温度 0 也救不了结构性歧义）——所以纠错提示拼进对话再问一次是唯一正确姿势；**(b)** 最好的重试是不用重试（Literal/Pydantic with_structured_output/JSON mode 把触发率压低一个量级）。Python 实现的顺手处：`ValidationError.errors()` 结构直接序列化为纠错消息（0.3 练习 2 那份表格的回收现场）；两次皆败即承认系统性问题走降级+告警，畸形样本自动入库喂 prompt 优化与 ch6 回归集。

### 8.1.3 L3 语义层与两个灵魂拷问

四前置条件（任务幂等/随机型失败已证/预算充足/用户无感延迟）与"多数情况正确答案是不重试、交出不完美结果+诚实声明"的克制立场保留。**拷问一**（谁付双倍钱）与**拷问二**（被重试的操作安全吗→超时≠失败→幂等是资格不是补丁）两条结论原文有效——后者直接把镜头推给 8.3。

---

## 8.2 多级降级梯子（D0~D5 结构保留，触发器接上 ch7 仪表）

梯子全景图、三级认知（D1 换供应商的参数方言与质量地板来自消融数据授权/D4 影子 workflow 平时养/D5 责任闭环）、触发信号选型表（错误率快信号切小级、finish_reason/幻觉工具名率中信号、judge 抽样慢信号切大级——**降级动作越大要求证据越多**）、半开回升与振荡保护（降级期缓存失效的成本反弹要有豁免线）、B2.3 节 digest 文体残留细节——v1 §8.2 整节资产继承。

Python 实现更新两处：**(a)** 熔断器用 pybreaker（或 OTel 生态的 circuitbreaker 库）包 provider client——`max_consecutive_failures=5, reset_timeout=30` 级别参数即达 Resilience4j 八成语义，注意它是**每通道一实例**（主/备各一只，别让备用通道的健康度污染主通道的判断）；**(b)** LangGraph 场景的降级切换点天然在模型工厂：`model = router.pick(signal_snapshot)` 于 before_model 装配时现选（模型对象是一等公民，热切换比 Spring bean 重建干净得多——DI 世界的又一桩小事）。

---

## 8.3 幂等与补偿：durable execution 时代的手工课与框架课

### 8.3.1 一把键的旅程（v1 全景图保留 + 一个新路口）

意图诞生→pending_action UNIQUE 占坑→执行器入口去重表→透传支持 Idempotency-Key 的业务 API→不支持的重放首果——五站全部保留（SQL 一字不改，Postgres 还是那位老朋友）。新增的路口是：**LangGraph 的恢复机制本身也可能造成"步骤重放"**——节点从头重跑的语义（ch5 陷阱的通用版）意味着副作用节点若无外部幂等锚点，checkpoint 恢复也会制造重复。规矩升级为一句话：

> **图内副作用靠"interrupt 前无副作用"纪律+action_id 幂等锚；图外副作用靠 idem_key 贯穿。两套锚点都要有，因为恢复源有两个（审批回调 & checkpoint replay）。**

### 8.3.2 saga 补偿注册制（保留）+ durable execution 对照

补偿动作预登记（ToolDef.compensation，R3 无补偿不上线）、EXECUTED_PARTIAL 显式建模、dead-letter+P1 告警（"钱出去了但世界不完整"）、progress 表滞留态扫描 job——v1 全套保留。然后翻开 LangGraph 的新页：

| 需求 | v1-LC4j 方案 | v2-LangGraph 原生件 | 仍归你的 |
|---|---|---|---|
| 崩溃后从断点继续 | progress 表+扫描重放 | **checkpointer 自动**：`ainvoke(None, config)` 从最后完成的 superstep 续跑 | 业务键对齐（防止续跑重复扣款仍需幂等锚） |
| 单步失败重试策略 | 手工 try/retry | **节点级 fault tolerance**：`RetryPolicy(...)` 挂节点（重试次数/退避/异常白名单） | 与 L1/L2 分层协调——别套娃重试（节点重试×SDK 重试=乘法爆炸，练习 2 专门验一条） |
| 长时间外部等待 | 回调驱动状态机 | interrupt + 后台 `graph.update_state` 唤醒 | 过期作废扫描（框架不管 TTL） |
| 补偿编排 | 自建 saga 表 | 无原生 saga——图里加 compensation 节点可表达 | 补偿语义/对账/人工升级全是你 |

诚实结论：**durable execution 接管的是"编排状态的恢复"，接管不了"业务效果的恰好一次"**——前者是快照科学，后者是数据库唯一约束+幂等键的艺术。面试讲清这条分界，胜过背十个名词。

---

## 8.4 超时预算与部分结果交付（全案保留，实现件换名）

SLA 蛋糕分配表（排队 0.5s/装配检索 2.5s/LLM 往返×N ≤10s/工具 3s 每次/收尾 2s；人审不计在线 SLA 计完成时长另一条钟）、三条纪律（**deadline 沿链递减传递**——每层拿剩余而非全额；每环节处置预定；季度校准用 ch7 延迟分解图）、部分结果交付话术模板与"进度账本驱动已完成/未完成清单+续作按钮携带原键新 attempt_window"的产品化思想（pass^k 的产品学翻译）——v1 §8.4 完整继承。

Python 落点三件：**(a)** deadline 传递用 `config["metadata"]["deadline_at"]`（单调时钟戳随 RunnableConfig 流动，middleware 环环检查剩余）——contextvars 保证跨 await 不丢；**(b)** 每环节超时的实现统一为 `asyncio.timeout(remaining)` 包裹（0.4.3 的肌肉记忆复用）；**(c)** "流的死亡不等于任务的死亡"（下节）与部分交付共享同一本 progress 账——账本是全章复用最勤的数据结构，值得单独建表建索引。

---

## 8.5 流式与并发韧性（战场依旧，兵器换代）

### 8.5.1 断连止损：FastAPI 版链路

```python
@app.post("/api/chat/stream")
async def chat_stream(body: AskIn, request: Request):
    task = asyncio.create_task(run_agent(body))         # 持引用！（0.4.3 事故③）
    async def event_gen():
        try:
            async for chunk in task.result_stream:
                if await request.is_disconnected():      # ≈ Servlet 容器抛 IOException 的异步版
                    task.cancel()                        # 向 await 点注入 CancelledError：
                    raise StopAsyncIteration             #   上游供应商请求随之中止=止损
                yield f"id: {chunk.seq}\ndata: {chunk.json()}\n\n"
        finally:
            metrics.abort_rate.observe(cancelled=task.cancelled())
    return StreamingResponse(event_gen(), media_type="text/event-stream")
```

v1 的三条现实约束原样有效：供应商对断开未必真停生成（可能照计费）→ **收益要实测**（练习 5 统计断连场景实际省下的 token 比例）；前端"停止生成"做成显式 POST /cancel 而非赌 TCP 语义；`abort_rate` 升高本身就是产品体验报警。

### 8.5.2 SSE 续传三态（协议不变）

delta 帧带序号、Redis Stream 缓冲（TTL 分钟级）、`Last-Event-ID` 重连补发、补不上则"最终答案已生成一次性下发"（查 progress 账本）——三态设计与理由保留。Python 件：redis.asyncio 的 xadd/xrange 十分钟搭完，比 v1 时代的 Lettuce 胶水薄一半。

### 8.5.3 容量与隔离：asyncio 世界的舱壁学

- **虚拟线程红利→asyncio 既有优势，但控制阀位置同理**：单事件循环天然不怕"百万线程"幻觉，真正的稀缺仍是**供应商 RPM/TPM 与自家 DB 池**——in-flight run 上限用 `anyio.Semaphore(max_concurrent_runs)` 在准入处把关（满则快速失败或排队，配队列深度指标）；
- **asyncpg 池 sizing 教训平移**：LLM await 期间绝不持有 DB 连接——v1 那句"检查有没有在 LLM await 前后夹长事务"在 Python 里以新形态复发：**async with session 的作用域横跨 await model.ainvoke() 就是同款罪**（代码审查 checklist 收录）；
- **按工具分舱**：慢工具独立 Semaphore（数量小）+短队列，快工具共享大舱——一个慢下游吃光许可拖垮全家，两栈剧本相同；
- **优先级准入**：在线坐席辅助 > C 端会话 > cron 离线流量（记忆提取/评测回放可抢占低优先级舱）——token 计费世界里 noisy neighbor 更真实；
- **超时拆分纪律保留**：connect/read/idle 三段+TTFT 专项超时（httpx.Timeout 天生支持分项配置，这点比裸 HttpURLConnection 文明）；thinking 模式另配。

常见误区点名照旧："给 LLM 调用配一个 30s 大超时一把梭=看起来配了 resilience 的假安全感。"

---

## 8.6 演练日：六幕剧本与 k6 曲线（方法论全保留）

六幕混沌表（C1 429 风暴/C2 畸形 JSON 20%/C3 主力工具超时→部分交付/C4 检索空+模型自信幻觉/C5 DNS 黑洞→D1 全自动接管/C6 审批重放×3+kill -9→恰好一次）逐幕预期断言保留——它们测的是体系不是语法。Python 注入工具链更新一句：mock 层用 respx（httpx 的 mock 库）+ testcontainers 起 PG/Redis，chaos 脚本比 v1 时代轻不少。

k6 要点四条原样：流量画像抄 golden set 难度分布（全是简单问答的压测=骗自己）；**成本作为一等断言维度**（custom metric 记 token 消耗，产出并发-延迟-成本三维曲线，标注成本拐点——并发过临界后重试/降级导致单位成本反升的那个膝点，找到它并在容量规划里远离）；瓶颈定位三板斧映射（供应商限流看 429/Retry-After vs 应用看 semaphore 拒绝数与队列深度 vs DB 看 asyncpg 池 pending）；《瓶颈定位 runbook》成文。

这份压测报告+六幕演练记录=简历"支撑 X 并发、P95 Y ms、通过 N 场混沌演练"的原始凭证（ch9 弹药库）。

---

## 8.7 企业踩坑案例：网络抖了三秒，机票出了两张（案例通用，Python 栈穿透复盘）

v1 §8.7 全文有效（超时≠失败的量子态→盲重试→网关幂等正确地返回重放成功→**处理器把重放误读为新出票**→上下文残留"之前失败了"的错误信念→模型追问时又发起全新参数出票绕过幂等→17 单双张票；四条修复：读写分离注册门禁/超时后先查证/replayed 打标回喂/事实轨同步）。

v2 栈的五步穿透对照（证明每条老根因在新栈都有精确对应物）：

```
① httpx 默认不重试，团队加了 tenacity 且 retry_any 一网打尽     ← L1 白名单缺失
② 超时异常被当"失败"回填 ToolMessage，模型记住了虚假前提          ← ch3 四分类缺失(系统故障不该回喂)
③ 网关重放响应 200 被 handler 无条件转成成功 Observation          ← 幂等重放未打标
④ 会话记忆里没有任何地方权威记录"票据号 X 已出"                   ← ch4 事实轨缺失
⑤ 全程没有任何一方持有单一权威视图，审计日志倒是记满了矛盾         ← ch5 审计≠防线
```

四条修复的制度形态全部在本课已有着落：注册门禁（ch3 ToolDef.kind/idem 强制）、"超时后的第一个动作是读，不是写"（写入 RefundPolicy：写工具超时→自动插入 query_order_status 读步骤→确认未成单才允许新尝试，图上一个条件边搞定）、replayed:true → 特殊 Observation（"此前请求已完成，票据号 X，请勿重复操作"）、结构化 fact 入 SessionFacts 通道（Decimal+enum，禁转述区）。

三条带走教训原文保留：**超时是量子态**；幂等键防得住重复请求防不住重复意图（后者靠事实轨与打标）；**韧性组件必须理解业务读写语义，通用默认策略在副作用面前一律有罪推定**。

---

## 动手练习

> `chapter08` 分支。本章验收方式延续 v1：**每个练习以一场演练或一份报告结尾**。

**练习 1 · 三层重试栈（4h）**
tenacity L1（429 专属退避+配额账本+滑窗 retry budget）/L2（errors() 纠错重试恰一次+畸形样本入库）/L3（默认关，白名单开）；`agent.retry.count{layer,reason}` 接线；mock 依次演 429 风暴与随机畸形，断言行为与**重试成本增幅**（cost-log 单列）。

**练习 2 · 降级梯子与套娃检测（5h）**
D0~D5 全梯+四信号分级触发+half-open 回升+降级期预算豁免线；**双供应商兼容测试矩阵**（参数方言/tool_calls 行为/streaming 语义逐项断言）；专项：节点 RetryPolicy × SDK 重试 × 审批重放三层叠加的最坏情况枚举测试（防套娃乘法爆炸——8.3.2 的分界线用测试钉死）。演练 C5 录屏归档。

**练习 3 · 幂等终验与 durable 对照（4h）**
去重表与业务写同事务（ON CONFLICT 单语句）；双恢复源测试：审批回调重放×3 与 checkpoint 恢复重放各自恰好一次；progress 表+扫描 job 手写最小版后，切换 LangGraph 原生 durable 配置复测对比（记录哪些手工代码可以删、哪些锚点必须留——这段观察写进迁移笔记）。补偿注册制生效演示：故意不登记 compensation 让启动失败。

**练习 4 · 超时预算与部分交付（3h）**
deadline 经 config 递减传递贯通全链；TTFT 专项超时；进度账本驱动的部分交付话术+续作按钮（原键新窗口）；k6 注入检索慢响应验证 P95 达标率与部分交付触发正确性。

**练习 5 · 流式韧性与舱壁（3h）**
8.5.1 断连链路实装并**实测止损收益**（断开时刻 vs 计费停止的差值报表）；Redis Stream 续传三态（含缓冲过期兜底路径）；慢工具 sleep 10s 实验证明快工具舱位无恙；asyncpg 池"await 横跨事务"的反例代码 review 抓虫练习（互相埋雷再互挖）。

**练习 6 · 混沌六幕 + k6 全案（3h）**
生产镜像环境逐幕执行（预期→实际→结论），出具《韧性体检报告》对外格式版；k6 三维曲线+成本拐点+容量建议（"安全水位=X 并发，依据=Y"）；附 GIL 影响测量一节（CPU 段/IO 段吞吐对比，给 8.0 那句"传闻焦虑"画上数据句号）。

**练习 7 · 对照阅读（1h）**
读 LangGraph Fault Tolerance/Duration & durable execution 文档 + Temporal 概念页各一遍，12 行笔记：durable engine 的"重放确定性"要求（节点函数须纯）与我们的 interrupt 前无副作用纪律是同一件事的两种表述吗？什么样的业务复杂度值得引入专职 durable engine？

---

## 本章小结

- **总纲仍是路由**：F1~F10 里四个 ★ 是 agent 新增格子；基建故障给韧性层、内容故障给模型（换输入、止于一次）、语义故障给护栏与评测——武器换了名字（tenacity/pybreaker/TaskGroup），**"区分故障在跟谁说话"这条宪法没有修正案**。
- **重试三原则跨栈无损**：白名单式可重试判定、429 听服务器的话、重试在 token 预算内跳舞；幂等是重试的前置资格——超时是量子态，写操作超时后的第一个动词是"读"。
- **降级的胆量来自数据**：每一级的触发器接 ch7 仪表、每一级的质量地板来自 ch6 消融授权、最大一级（D4）靠平时养的影子 workflow；快信号切小级慢信号切大级，升降自动且留痕。
- **durable execution 划清了新的责任线**：框架管编排状态的恢复（快照/续跑/节点重试），你管业务效果的恰好一次（幂等锚×双恢复源/补偿注册/对账）——这条分界线本身就是本课的原创洞见之一，面试直接引用。
- **预算与部分交付是一对连体婴**：蛋糕切分递减传递，账本驱动"已完成+可续作"——把 pass^k 的坏消息变成便宜补齐的过程。
- **并发韧性的 asyncio 特色**：单循环不再怕线程耗尽但照样怕配额与池；semaphore 舱位按工具分、离线流量可抢占；断连止损的收益要实测数字不要信直觉。
- **没演练过的韧性是 PPT 韧性**：六幕逐幕有断言、k6 曲线有拐点标注、报告有遗留缺陷编号——"上次演练它在这个并发下这样表现"才是生产者语态。
- **下一章预告**：八章零件全部就位且各自扛过了压力测试——第 9 章做最后三次翻译：DoD 总验收把整机拧出来，文档与简历把手艺翻译成判断力凭证，模拟面试把九个月的汗压缩成五分钟能讲明白的故事。也是这门课给你我的期末考。
