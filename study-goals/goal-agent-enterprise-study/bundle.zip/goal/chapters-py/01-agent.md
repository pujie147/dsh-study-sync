# 第 1 章 · Agent 工程全景与生产化心智模型（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：第 0 章（Python 工程桥接）；goal1《企业级 AI 应用落地》第 1~5 章（LLM 心智模型、框架基础、RAG 摄取/检索/权限——概念全部复用，实现语言为 LC4j 的部分本章按对照阅读处理）
> **建议学时**：12 小时
> **本章定位**：主线第一课仍然不是写 agent，而是建立**判断力**：什么时候该用 agent、该用哪种形态、以及为什么"能跑的 demo"和"敢上线的系统"隔着三道工程鸿沟。v1 版在这一章立起的三件事（agent 三要素定义、生产三特性、五层架构）与语言无关，全部保留；本章的增量工作是：① 用 2026 年的生态地图重画五层落位表（create_agent/LangGraph/middleware 取代 AiServices/Agentic Services 的位置）；② 发布 **ADR-001 修订案**——把主栈从 LC4j 换成 LangGraph 的决策写成正式记录，这份"跨栈迁移评估"本身就是你简历上的独家素材。

---

## 本章学习目标

1. 用工程语言给出 agent 的定义（**LLM 在循环中自主决定行动**），并用三要素判据区分 agent / workflow / 单次 RAG 问答；
2. 解释生产三特性——概率性输出、非幂等副作用、token 成本随循环放大——并亲手复现一次"同一问题不同轨迹"；
3. 解读市场锚点数据（agent 进生产 ~57% vs 评测普及率 ~52%），据此确认本课程的投入重心；
4. 画出企业 Agent 服务的五层架构，并把 **LangGraph 生态的各组件**（`create_agent`、`StateGraph`、middleware、checkpointer、`@tool`、callbacks）准确放到对应层；
5. 掌握 2026 agent 框架生态的判断坐标：三层栈（harness/运行时/深代理）、编排范式三分法（图式/角色式/循环式）、以及 Python-first 格局的成因与例外（Claude Code 为什么是 TS）；
6. 撰写 ADR-001 修订案：换栈的收益、代价、被拒选项与重评触发条件；
7. 搭好 Python 版仓库基座（uv 骨架 + docker-compose 复用 + CI 冒烟）。

---

## 1.1 开场：同一个需求的两种实现（Python 重绘版）

需求不变："用户问：帮我把工单 T-1024 升级到 P1 并通知值班群"。

**实现 A（workflow，确定性代码）**：

```python
def handle(ticket_id: str, user: Principal) -> None:
    t = ticket_repo.find_by_id(ticket_id)                  # 1. 查工单
    if not authz.can_edit(t, user):                        # 2. 权限校验
        raise Forbidden("无权处置该工单")
    ticket_service.update_priority(t, Priority.P1)         # 3. 改优先级
    notify_client.send_to_duty_group(t)                    # 4. 发通知
```

每步都是你写的，pytest 全覆盖，压测数据可信。

**实现 B（agent，LLM 驱动循环）**：

```python
from langchain_core.tools import tool
from langgraph.prebuilt import create_agent                # 2026 的标准入口：预置 harness

@tool
def update_ticket_priority(ticket_id: str, priority: str) -> str:
    """升级指定工单的优先级。仅当用户明确要求变更优先级时使用。"""
    ...                                                     # docstring 即工具描述（第 3 章展开）

@tool
def send_notification(group_id: str, message: str) -> str:
    """向指定群组发送通知消息。"""
    ...

agent = create_agent(
    model="deepseek:deepseek-chat",                         # OpenAI-compatible 逃生舱，ADR-002 不变
    tools=[update_ticket_priority, send_notification, get_ticket],
    system_prompt="你是运维助手……",
)
await agent.ainvoke({"messages": [HumanMessage(content=user_text)]})
# LLM 自己决定：先查工单？直接改？要不要通知？文案写什么？调几次算完？
```

v1 的那句结论原样成立：**实现 B 多出来的每一分自由度，都是一个你不控制的分支**。Python 版还额外多一层微妙：`create_agent` 这行封装背后，LangGraph 运行时替你跑着那个 while 循环——本章第 2 节定义"循环"，第 2 章再把这个循环拆开手写一遍祛魅。

> **☕ Java 锚点**：`create_agent(...)` 返回的是一个编译好的 `CompiledStateGraph`——把它想象成 `SpringApplication.run()` 之后拿到的那个不可变 bean：配置期随意组装，运行期只读调用。`.ainvoke()` 的 a 前缀 = async 版本（0.4 的双色规矩：整个服务全 async 到底）。

---

## 1.2 Agent 的工程定义：循环、决策权、终止条件

三要素判据（与 v1 完全一致——这是架构概念，不随语言漂移）：

| 要素 | 含义 | 反面例子 |
|---|---|---|
| **循环** | 模型能看到上一步结果并据此产生下一步 | 单次 function calling 只是"带工具的问答" |
| **决策权在模型** | 选哪个工具、传什么参数、是否继续由模型推理产出 | 你用代码固定步骤顺序 = workflow 里嵌了次 LLM 调用 |
| **终止条件** | 模型的"完成"信号 + 你的强制熔断（轮数/token 预算/超时） | 没有熔断的循环 = 1.4 节成本事故的入场券 |

三类系统的边界判定：

- **单次 RAG 问答**：检索→生成一条直线 → 不是 agent（goal1 已解决）；
- **Workflow**：节点和边由开发者预先画好，LLM 只在节点内"填空"。**LangGraph 的状态图恰恰最擅长表达这种形态**——注意这个新认知：在 LC4j 时代"图"要靠自写状态机，现在它是框架一等公民，所以"workflow vs agent 之争"在 LangGraph 里变成了同一套原语上的连续光谱；
- **Agent**：控制流交给模型（`create_agent` 默认形态、或图里让模型节点决定路由）。

Anthropic《Building Effective Agents》的原则在 Python 语境连翻译都省了（原文示例本就是伪 Python），核心一句仍是反直觉的：**找到最简单的解决方案，只在确有必要时才增加复杂度**。

### 常见误区（本版新增一条）

- 误区 1：用了 LangChain/LangGraph 就是在做 agent——框架只是脚手架，判定只看三要素；
- 误区 2：agent 越自主越高级——生产追求"满足 SLA 前提下尽可能少地把决策权交给模型"；
- **误区 3（Python 生态特有）："LangGraph 是重型框架，小任务杀鸡用牛刀。"** 辨析：LangGraph 官方定位是 low-level 编排运行时，它同时支持不加图的裸用法（`create_agent` 十分钟起步）与全显式图（每个节点每条边你定）。真正的成本不在体量而在**心智模型切换**（State/reducer/通道概念）——这正是本课程第 2 章要带你过的河，过了河你会发现：workflow 和 agent 共用一套基础设施反而是最省的。

---

## 1.3 市场背景：57% 进了生产，52% 没建评测——缺口逻辑不变

沿用 v1 论证：agent 已大规模进生产（Klarna 客服 bot 处理 2/3 咨询、折算 853 人工作量、年省 $60M 这类公开案例背书），但系统化评测的团队只有约一半。**会搭的人过剩，能回答"它到底好不好、变差了怎么知道"的人稀缺。** 由此锁定的学习优先级（评测/观测/可靠性三章合计 70h，占全课 1/3）不因换栈而变——反而因为 Python 生态评测工具更成熟（LangSmith evals/DeepEval/promptfoo/τ-bench 原生可跑），第 6 章的兑现度更高了。

**2026 生态快照**（补充本节的市场维度，来源见文末链接）：

```
生产部署量口径          语言阵营        一句话定位
──────────────────────────────────────────────────────────────
LangGraph  34.5M/月下载  Python-first   企业默认；Klarna/Elastic/Uber/LinkedIn/JPMorgan
OpenAI Agents SDK 10.3M  Python(+TS移植) handoff/guardrails 极简主义，ephemeral state 是短板
CrewAI 5.2M              Python         原型最快，规模化可控性被诟病
Mastra / Vercel AI SDK    TypeScript     Node 双雄：前端即产品场景；编排原语滞后 Python 半代
Microsoft Agent Framework .NET+Python    AutoGen+SK 合并后继者，.NET 企业唯一解
```

规律一句话（上轮调研的结论沉淀）：**越靠近"重编排、持久状态、评测、数据管道"越是 Python 领地；越靠近"用户手边的交互壳"越是 TS 领地**（编码 CLI 类如 Claude Code 是 TS——为 npm 分发便利）。本课程教的全是前者。

---

## 1.4 生产三特性：demo 与生产的差距全在这里（概念通用，实验重做）

三条特性的机理阐述与 v1 相同（概率性→轨迹分叉需要 pass^k 视角；非幂等→写操作必须幂等键+护栏；成本乘性放大→预算进架构），此处不再重复推导，只更新"Python 侧的工程手感"：

1. **概率性的快速复现**（本章动手练习 2）：对 `agent.ainvoke()` 同参连打 10 次，从返回的 `state["messages"]` 里提取每轮的 `AIMessage.tool_calls`，肉眼对比轨迹分叉——比 v1 时代更容易的是所有数据天然结构化在 messages 列表里，无需翻日志；
2. **非幂等的语言级提醒**：Python 没有类型系统帮你区分"读函数/写函数"，纪律靠两样——命名约定（`get_/find_` vs `create_/refund_`）+ 第 3 章的注册期装饰器门禁（写工具未声明幂等策略则 import 报错）。另外记住 0.3 埋的伏笔：**金额一律 `Decimal`**，`float` 参与的钱会在转述中蒸发小数位（第 2 章案例的语言注脚）；
3. **成本的随手可见**：`result["messages"][-1].usage_metadata` 直接给出本轮 token 计数（input/output/cached 分项）——Python 生态把 usage 挂在每条 AIMessage 上的设计，使 per-step 成本统计几乎零成本，第 7 章的成本饼图原料从这里开始攒。

**三特性小结表**（照抄 v1，一行不改——这正是"好概念跨语言存活"的证明）。

---

## 1.5 五层架构视图 2026：LangGraph 生态落位

架构图五层不变，落位表整体换装：

```
┌─────────────────────────────────────────────────────────┐
│ ⑤ 观测层  callbacks 体系 · OTel GenAI semconv           │ ← 第 7 章
│    LangSmith(亲儿子自动 trace) ∥ Langfuse+Tempo(中立)    │
├─────────────────────────────────────────────────────────┤
│ ④ 护栏层  middleware 体系 + 自建审批/风险表               │ ← 第 5 章
│    内置件: HumanInTheLoopMiddleware/PII/redaction        │
│    自建件: 风险矩阵/幂等/审计链（框架给钩子，语义归你）      │
├─────────────────────────────────────────────────────────┤
│ ③ 工具层  @tool + args_schema(Pydantic) · MCP adapters  │ ← 第 3 章
├─────────────────────────────────────────────────────────┤
│ ② 编排层  StateGraph/条件边/Send扇出 · create_agent      │ ← 第 2、4 章
│    记忆: checkpointer(thread级) + Store(跨thread)        │
│    上下文: summarization middleware + 自建装配器          │
├─────────────────────────────────────────────────────────┤
│ ① 模型层  init_chat_model / ChatOpenAI(compatible)       │ ← goal1 覆盖
│    ADR-002 逃生舱：供应商=配置不是代码                     │
└─────────────────────────────────────────────────────────┘
```

各层责任边界与越界反模式的完整论述见 v1 §1.5（概念等价，阅读 30 分钟），本版只重写两处关键差异：

**差异一：护栏层的"框架参与度"变了。** LC4j 时代护栏层整层空白全自建；LangChain 1.x 把 **middleware** 做成编排层/护栏层的公共骨架——`before_model`/`after_model`/`wrap_tool_call` 三类钩子 + 一批内置件（HITL 审批、摘要压缩、PII 脱敏、prompt caching、context injection）。于是本课第 5 章的教学从"造中断-恢复引擎"上移为"**配对语义**：interrupt 机制归框架，审批业务表/双人复核/参数哈希绑定归你"。⚠️ 警惕反向误区：**有内置件 ≠ 有护栏**——`HumanInTheLoopMiddleware` 只管"暂停等人点头"，它不知道你们的额度政策、不懂什么叫双人复核。框架给你的是挂点，治理语义永远是你的业务。

**差异二：观测层出现"双轨制"。** LangSmith 提供开箱即用的深度 trace（含 time-travel 回放），但它是商业平台；ADR-004 冻结的 Langfuse 自托管 + OTel GenAI semconv 路线保持中立。本课程**双轨都接**（Collector 一分二），并在第 7 章给出"哪些内容绝不离开自托管侧"的隐私分区——这个双轨经验本身就是企业真实处境的映射。

### LC4j → LangGraph 抽象迁移速查（你的独家复习卡）

| 你在 v1/LC4j 学的概念 | LangGraph/LangChain 对应物 | 备注 |
|---|---|---|
| `ChatModel`/`StreamingChatModel` | `init_chat_model()` / `.astream()` | usage_metadata 同样随行 |
| `@AiService` 自动工具循环 | `create_agent()` | 都是"挂工具就跑 ReAct"的高层形态 |
| Agentic Services sequence/parallel/supervisor | 图组合 / Send 动态扇出 / supervisor 模式（官方库 langgraph-supervisor） | LG 显式图表达力更强 |
| AgenticScope（无类型 Map） | **State + reducer（类型化、并发合并语义明确）** | v1 记下的"弱一档"欠条今天还清 |
| ChatMemoryStore(Redis/PG) | **checkpointer(Sqlite/Postgres saver)** | 且不止存消息——存整个编排状态 |
| （LC4j 无）interrupt | **interrupt()/Command(resume)** | 第 5 章主角 |
| ToolProvider 动态暴露 | bind_tools 子集 / tool_search middleware | 概念同名同职责 |
| ChatModelListener | callbacks 体系 + middleware wrap_* 钩子 | 埋点位更多 |
| GuardedToolExecutor 装饰器链 | wrap_tool_call middleware 链 | 洋葱模型同款（≈Servlet Filter chain） |

> **面试价值提示**：这张表就是"我从 Java 栈迁到 Python 栈"的一页纸证据。两栈皆通的人能讲出"AgenticScope 为什么是无类型 Map 是个架构级缺陷"这种颗粒度的话——单栈候选人说不出。

---

## 1.6 ADR-001 修订案：从 LC4j 迁移到 LangGraph（本章核心工件）

按 ADR 标准格式亲自写一遍（模板已在 goal1 用过），要点提纲：

```markdown
# ADR-001r: Agent 编排主栈由 LangChain4j 变更为 LangGraph (Python)
状态: Accepted (supersedes ADR-001)
背景: 学习者多年 Java 后端，目标 6 个月内求职级 agent 工程能力。
决策: 主栈 Python 3.12 + LangGraph 1.x + LangChain(create_agent/middleware)
      + FastAPI(服务壳) + Pydantic(契约)。LC4j/Spring AI 降为对照阅读。
理由:
  R1 生态位: LangGraph 是企业生产默认(34.5M 月下载、400+ 公司平台客户)，
     agent 岗位 JD 曝光度显著高于 LC4j；评测/观测工具链原生同语。
  R2 设施红利: checkpointer/interrupt/Store/reducer 原生到位——v1 中
     "LC4j 缺、需自建"的护栏/HITL/记忆大件由框架承接，课程重心得以上移
     到设计判断、治理与证据链（更值钱的部分）。
  R3 教学完整性: τ-bench/user simulator 等高级弹药仅 Python 侧可实操。
代价与对策:
  C1 学习者的 Python 工程熟练度是真实瓶颈 → 增设第 0 章桥接(8h)+
     全讲义注释密度规范+Java 锚点对照+每章迁移笔记。
  C2 放弃 JVM 组织语境(Spring DI/线程模型/Maven) → 把"跨栈迁移"本身
     升格为课程卖点与简历叙事（迁移成本清单=独家文章素材）。
  C3 LangGraph API 迭代快 → 版本锁定(langgraph>=1,<2)+升级回归纪律；
     关键行为写特征测试钉死（继承 v1 教训：框架默认行为是要测的不是猜的）。
被拒选项:
  - 维持 LC4j: 求职杠杆折损，第一梯队设施需长期自建维护。
  - TypeScript(Mastra/Vercel AI SDK): 编排/持久化原语滞后，且与"企业
    服务端工程"目标画像错位。
  - OpenAI Agents SDK 做主栈: handoff 优雅但 durable state 短板恰是
    本课教学重点，不宜地基即偏科。
重评触发条件: LangGraph.js 功能对齐至同等水位；或目标岗位画像明显
  转向全栈/Next.js 产品团队；或框架出现破坏性方向变更。
```

ADR-002（OpenAI-compatible 逃生舱）、003（pgvector）、004（Langfuse+OTel）**维持冻结**——三者均在 Python 侧有更成熟实现（langchain-openai、langchain-postgres 的 PGVector+PostgresSaver、Langfuse 的 OTLP 接入），换栈无损反而加固。

---

## 1.7 复习锚点与环境衔接

- goal1 依赖关系表沿用 v1 §1.6（token/窗口/采样心智、@AiService→create_agent、RAG 管道→作为检索工具复用、检索 ACL→第 5 章动作侧续篇），仅把"已解决于 LC4j 实现"理解为"概念已解决，Python 等价物见 1.5 迁移表"；
- TicketAgent 演进剧本更新一行：第 2 章起所有实现落在 0.8 骨架的 `orchestration/` 目录，mock 业务三件套（查工单/建工单/查库存）以 FastAPI 假服务或内存 stub 形式先行存在（练习 3 顺手补齐）；
- 基座复用：docker-compose（postgres+pgvector / ollama / langfuse）原样拉起，新增一项可选：`redis`（checkpointer 热层，第 4 章启用）。

---

## 1.8 企业踩坑案例：把固定 SOP 做成自由 ReAct agent 的那支客服团队

> 案例全文见 v1 §1.8（Java 语境版），其四条症状/根因/修复与语言完全无关——此处保留骨架并标注 Python 栈的对应设施，证明"教训的可迁移性大于技术栈"。

**症状回顾**：SOP 型任务硬上自由 ReAct → 延迟翻倍（平均 5.7 轮 vs 应有 2 步）、成本 6 倍、无法回归测试（轨迹不定断言写不出）、千分之二越过 prompt 软约束。

**修复后的混合架构，在 LangGraph 里几乎是"母语表达"**：

```python
graph = StateGraph(TicketState)
graph.add_node("classify", classify_intent)        # LLM 单次调用→enum（意图分类）
graph.add_node("lookup", lookup_order)             # 纯代码节点：确定性查询
graph.add_node("reply", generate_reply)            # LLM 单次调用：话术生成
graph.add_node("complex_agent", restricted_agent)  # 唯一的受限 agent：长尾复杂咨询
graph.set_entry_point("classify")
graph.add_conditional_edges("classify", route_by_intent)  # 路由=代码 switch，不给模型
...
app = graph.compile(checkpointer=...)              # 顺带白送持久化/恢复/时间旅行
```

v1 里这套回退方案要"自写状态机"，在 LangGraph 里是官方主推姿势——**这个对照本身就是 ADR-001r 理由 R2 的最佳例证**。三条教训原封带走：自主性是付费的架构决策；硬约束不进 prompt；trace 和评测不是上线后的补丁。

---

## 动手练习

> 全部在新建的 Python 仓库（0.8 骨架）进行，`chapter01` 分支。

**练习 1 · 基座自检（1h）**
`uv sync` 全绿；docker-compose 拉起 pgvector/ollama/langfuse；`uv run pytest` 冒烟通过；打开 Langfuse 空项目确认连通。截图归档 `docs/ch01/env-check.png`。

**练习 2 · 概率性与成本十分钟实验（2h）**
`create_agent` 挂一个只读 `get_ticket` 工具，构造 3 个两步任务，同参各打 10 次：(a) 从每次返回的 messages 提取 tool_calls 序列，统计轨迹种类数；(b) 汇总每条 AIMessage 的 `usage_metadata`，算最贵/最便宜比值；(c) 写入 `docs/ch01/nondeterminism.md`（表格+两句观察）。这份数据第 6 章建 pass^k 报告时回收使用。

**练习 3 · mock 业务 API 补齐（2h）**
用 FastAPI 实现三个 stub（getTicket/createTicket/checkInventory，数据放内存 dict + 一个故意的随机延迟模拟慢下游），配 httpx async client 封装与 pytest 集成测试。它们是第 2、3、8 章的实验对象，值得一次做扎实（含 OpenAPI 文档自动生成的体验）。

**练习 4 · 架构落位默写（1h）**
不看原图重画五层架构并贴名词：`create_agent`、`StateGraph`、`@tool`、middleware、checkpointer、Store、Send、interrupt、callbacks、风险矩阵（自建）。然后填写 1.5 的 LC4j→LangGraph 迁移速查表（凭记忆版），错位处回看正文。

**练习 5 · ADR-001r 成文（2h）**
按 1.6 提纲写出你自己的完整版（重点打磨"被拒选项"三段——那是判断力的浓度所在），入库 `docs/adr/ADR-001r-python-stack.md`；另附 20 行《迁移成本实测清单》：从今天写完 ch0 练习至今，哪些时刻想念 javac/IDE 重构/Maven——诚实记录，第 9 章博客要用。

**练习 6 · 判定标准实战（2h）**
沿用 v1 练习：5 个真实候选场景按三要素表定性（单次调用/workflow/受限 agent/自由 agent），每个 ≤3 行理由。加一问：每个场景在 LangGraph 里是"裸 create_agent 够用"还是"必须显式图"？——这张表第 2 章开工时直接当选型假设用。

**练习 7 · 生态阅读（2h）**
精读两份材料：Anthropic《Building Effective Agents》全文 + The Agent Report 2026 年中框架 landscape 综述（文末链接），写 15 行笔记：三种编排范式（图式/角色式/循环式）各自的失控形态是什么？为什么"角色式"CrewAI 们规模化时被吐槽？——为第 2 章 supervisor 设计与第 6 章轨迹指标预热。

---

## 本章小结

- **定义即判据**：agent = LLM 在循环中握有决策权的系统；三形态是光谱不是等级，只在步骤不可预见的开放任务上购买自主性。
- **三特性跨语言存活**：概率性/非幂等/成本放大与栈无关；Python 侧的新手感是"结构化可得"——轨迹就在 messages 里、成本就在 usage_metadata 里，观测原料唾手可得（用好它是第 6/7 章的前提）。
- **市场缺口决定投入重心**：57% vs 52% 的逻辑不变，且 Python 生态让评测武器更顺手——换栈后第 6 章只会做得更好。
- **五层架构换装不换骨**：模型/编排/工具/护栏/观测依旧分明；新常识是 middleware 成为护栏挂点、checkpointer/Store 接管记忆持久化、观测走向 LangSmith∥Langfuse 双轨。护栏铁律升级表述：**框架给挂点，治理语义永远是你的业务**。
- **ADR-001r 是本章的实体产出**：收益（生态位/设施红利/教学完整性）、代价（Python 熟练度/放弃 JVM 语境/API 迭代快）与对策逐条落字——这份文件连同迁移成本清单，就是你"两栈皆通"叙事的原始凭证。
- **下一章预告**：进入编排层深水区——先用 `model.bind_tools()` 手写 ReAct 循环把 `create_agent` 的黑盒拆开给自己看（消息序列如何生长、三重熔断怎么写），再回到高层 harness 与显式图的取舍，最后用 State+reducer 实现计划-执行与 supervisor。v1 里 AgenticScope 欠下的账，第 2 章开始分期兑付。
