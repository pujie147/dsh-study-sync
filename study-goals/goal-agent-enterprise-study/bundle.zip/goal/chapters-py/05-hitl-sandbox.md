# 第 5 章 · 危险操作管控：human-in-the-loop 与权限沙箱（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：第 3 章（注册门禁/读写分离/工具白名单）、第 4 章（checkpointer 持久化——本章挂起恢复的地基）、goal1 第 5 章（检索侧 ACL）
> **建议学时**：20 小时
> **本章定位**：企业 Agent 岗位的面试分水岭。v1-Java 版的治理体系（五层失效模型、风险四级、审批铁律、参数三查、幂等、沙箱限爆、审计留痕）**一项不减**；变化发生在引擎室：v1 用 `pending_action` 表+回调执行器从零搭建的"挂起-恢复"机制，现在由 **`interrupt()` + checkpointer + `Command(resume)`** 原生承担——教学重心随之从"怎么造中断"上移为"**怎么给中断配上正确的业务语义**"。框架管暂停，谁批准、凭什么批、批准后世界变了怎么办——这些它一个字都不管，而这正是本命的含金量所在。实装对象：TicketAgent 新增写工具 `refund_ticket` / `close_ticket`。

---

## 本章学习目标

1. 建立动作风险四级模型（R0 只读/R1 可逆写/R2 不可逆写/R3 资金销毁），把分级编码进 ToolDef 元数据并由 wrap_tool_call middleware **强制生效**（未定级即拒注册）；
2. 掌握 LangGraph HITL 三件套的精确语义：`interrupt(payload)` 挂起、checkpointer 持久化断点、`Command(resume=value)` 恢复；能设计 payload 与 resume 值的**结构化契约**并避开"节点从头重跑"的经典陷阱；
3. 立起审批界面第一铁律——展示原始参数而非模型转述（presented==executed 哈希绑定），理解参数偷换攻击并会防；实现反审批疲劳设计与通过率元监控；
4. 实现独立参数校验器三查（额度/状态机现值/归属权）与幂等键全链路（意图派生/canonical 序列化/DB UNIQUE 背书/审批重放 CAS）；
5. 设计 agent 权限沙箱：最小权限服务账号+实体级短时效 step token、三级配额、爆炸半径三件套（dry-run 后果清单/影子执行/金丝雀租户+feature flag 一键止血）；
6. 组织红队演练日：间接注入样本驱动越权退款，产出穿透矩阵（样本×L1~L5 热力图）并沉淀进 golden set；
7. 交付不可篡改审计链（append-only/presented_args_hash/假名化调和删除权），说清审计≠日志≠观测三分法；
8. 通过确认弹窗改写参数致批量删资源案例，把"审批界面禁止转译"刻成制度。

---

## 5.0 五层失效模型（原样保留，这是全章坐标系）

```
攻击/故障穿透深度 →
[L1 工具面白名单]   没给它 close_all_tickets，它就调不了          ← ch3 已建
[L2 参数独立校验]   给了工具，但 refund(99999) 过不了金额上限       ← 本章 5.3
[L3 风险分级+HITL]  参数也"合法"，但不可逆操作必须过人              ← 本章 5.1/5.2
[L4 权限沙箱限爆]   人看走眼了，但 agent 账号只能动灰度租户的资源    ← 本章 5.4
[L5 审计溯源]       已经炸了，但 10 分钟内定位全部受影响对象        ← 本章 5.5
```

"单层必破，五层叠加才叫生产"；5.6 案例是 L3 看似存在实则形同虚设的标本。"把 agent 当新员工管理"的类比与"它可以被一句藏在工单备注里的话策反"的警示原文有效。

---

## 5.1 动作风险分级：编码进类型，在执行器强制

### 5.1.1 四级模型与判据三连

R0~R3 × 策略绑定表（自动执行/事后通知/事前确认/双人复核+限额）、定级判据三连（能无声改回来吗/损失是钱还是流程/撤销有二次伤害吗→就高不就低）、批量放大与组合升级两个隐形维度——**全部沿用 v1 §5.1.1**（分类学不因语言改版）。

### 5.1.2 Python 制度形态：ToolDef 门禁 + middleware 执法

第 3 章预告过的两半处方在此合璧：

```python
class RiskLevel(str, Enum):
    READ = "R0"; REVERSIBLE = "R1"; IRREVERSIBLE = "R2"; MONEY = "R3"

@dataclass(frozen=True)
class ToolDef:
    spec: BaseTool
    kind: Literal["read", "write"]
    risk: RiskLevel                              # ← 无默认值：漏标构造即失败
    policy: str = "default"                      # 关联额度表/审批角色配置
    require_ownership: bool = False
    compensation: str | None = None              # R3 必填：补偿路径登记（5.3.2/第8章）

    def __post_init__(self):
        if self.risk in (RiskLevel.IRREVERSIBLE, RiskLevel.MONEY):
            if self.idem is None or (self.risk == RiskLevel.MONEY and not self.compensation):
                raise RegistrationError(f"{self.spec.name}: 高危工具缺幂等策略/补偿登记，拒绝注册")

# 执法点：wrap_tool_call middleware（ch2/3 建的洋葱链，此环专管风险路由）
@wrap_tool_call
async def risk_gate(request, handler):
    td = REGISTRY.by_name(request.tool_call["name"])
    match td.risk:
        case RiskLevel.READ | RiskLevel.REVERSIBLE:
            result = await handler(request)
            if td.risk == RiskLevel.REVERSIBLE:
                notify_queue.enqueue(post_notice(request))      # R1 事后通知
            return result
        case _:                                                  # R2/R3 → 进 5.2 审批流
            return request.interrupt_or_delegate(td)             # 见下节真身
```

单一事实源纪律不变：`tool_risk_matrix` 配置表（PG JSONB 列存策略）同时喂执行器/审批路由/评测对抗生成/告警阈值四方；MCP annotations 只是参考信号，我方登记为准，不一致即漂移告警下线该工具。

---

## 5.2 Human-in-the-loop：interrupt 引擎 + 业务审批真相

### 5.2.1 先立分工表（本章最重要的认知）

| 职责 | 归框架（LangGraph 原生） | 归你（业务自建） |
|---|---|---|
| 暂停执行、持久化断点 | `interrupt(payload)`：抛特殊信号，checkpoint 落盘，run 干净结束（零线程占用） | — |
| 恢复执行 | `graph.ainvoke(Command(resume=x), config)`：从中断点继续 | — |
| "暂停的是什么"的语义 | — | payload 契约设计（原始 args_json+hash+依据摘要） |
| 谁能批、几个人批、超时作废 | — | 审批服务 + pending_action 业务表 |
| 批准后执行前再校验 | — | 额度/状态机/归属三查重跑（世界可能变了） |
| 送审-执行一致性证明 | — | presented_args_hash == executed_args_hash 断言 |
| 审批 UI | — | FastAPI 端点渲染 DB 原始参数（禁转译铁律） |

一句话总纲：**interrupt 让"挂起三天不占资源"成为免费午餐，但"挂起什么、谁来点头、点头后信什么"三个问题它一个都不答。**

### 5.2.2 挂起侧：payload 契约与那个著名的陷阱

```python
@wrap_tool_call
async def hitl_gate(request, handler):
    td = REGISTRY.by_name(request.tool_call["name"])
    if td.risk.value < "R2":
        return await handler(request)

    raw_args = request.tool_call["args"]                    # ★ 冻结此刻的原始参数
    decision = interrupt({                                   # ← 执行到这一行，checkpoint 落盘，run 结束
        "kind": "approval",
        "action_id": str(uuid4()),
        "tool": td.spec.name,
        "args_json": json.dumps(raw_args, sort_keys=True),   # canonical 序列化（5.3.2 伏笔）
        "args_hash": sha256(canonical(raw_args)),
        "requested_by": current_principal.get().user_id,     # 服务端身份，非模型转述
        "basis_digest": summarize_context(request.state),    # "AI 申请理由"——仅供人参考
        "expires_at": now() + timedelta(hours=72),
    })
    # ★★★ 陷阱区：resume 时【本节点从头重跑】！interrupt() 之前的代码会再次执行——
    # 任何副作用必须挪到 interrupt 之后，或以 action_id 做幂等去重。
    if decision.get("approved") is not True:
        return _result(request, {"status": "REJECTED", "advice": "告知用户审批未通过"})
    verified = approval_service.claim_for_execution(decision["action_id"],
                                                    expect_hash=sha256(canonical(raw_args)))
    # ↑ 领取执行权：CAS 防并发双批；hash 复核防"送审后 args_json 被篡改"
    out = await execute_approved_action(td, verified.args)   # ★ 批准的执行绕开模型：
    return _result(request, {"status": "EXECUTED", **out})   #   参数来自冻结副本，不再问模型意见
```

三条设计判断逐条对应 v1 的铁律：**(a)** 恢复后执行的参数取自审批表的冻结副本（不是"再让模型说一遍"——resume 值里塞指令让它重新决策是教程常见漏洞）；**(b)** `execute_approved_action` 走确定性管线（校验器三查重跑→幂等占坑→delegate），**批准后的路径上不允许再有概率性组件**；**(c)** 挂起期间会话标记 WAITING_APPROVAL（State 字段），同名写操作的重复发起被闸口合并去重——模型若试图重试同一退款，第二次调用命中已有 pending 直接返回"已在审批中"（advice 明说勿重试，防审批单风暴）。

**恢复侧 API 体验**（审批服务的回调处理器）：

```python
async def on_approval_callback(action_id: str, approver: Principal, approve: bool):
    pa = approval_service.record_decision(action_id, approver, approve)   # R3 双人：第二签齐了才放行
    thread_cfg = {"configurable": {"thread_id": pa.thread_id}}
    async with langgraph_agent(thread_cfg) as graph:
        await graph.ainvoke(Command(resume={"approved": approve,
                                            "action_id": action_id}), thread_cfg)
    audit.chain_event(pa, approver)               # 无论批准与否都进审计
```

对照 v1：那张手写的 `pending_action` 状态机表仍然要建（审批链/双人记录/过期扫描都是业务），但"消息列表快照+恢复到哪一步"这半壁江山由 checkpointer 代管——**这就是 ADR-001r 理由 R2 在本章的兑现现场**。多中断并存（一次 run 攒了两个待批动作）LangGraph 按队列处理，resume 逐个应答，注意用 action_id 对号入座。

### 5.2.3 审批 UI：禁止转译铁律的 FastAPI 实现

v1 §5.2.4 全文有效（原始参数逐字段带单位格式化/AI 理由进折叠参考区/hash 前 8 位展示/反疲劳四件：低风险不打扰、批量聚合、异常置顶、通过率+决策时长元监控）。Python 侧的关键红利是**这套 UI 根本不需要前端框架**——Pydantic 模型直接驱动渲染，schema 即表单：

```python
@app.get("/approvals/{action_id}")
async def approval_view(action_id: str, viewer: Principal = Depends(approver_auth)):
    pa = approval_service.load(action_id)
    model = REGISTRY[pa.tool_name].args_model.model_validate_json(pa.args_json)
    return templates.TemplateResponse("approval.html", {
        "fields": render_struct(model),          # Decimal 原样字符串输出，零浮点触碰
        "ai_reason": f"<details>AI 申请理由（仅供参考，非执行内容）…{pa.basis_digest}</details>",
        "args_hash_prefix": pa.args_hash[:8],
        "impact_preview": await dry_run.preview(pa),   # ★ 5.4.3 的后果清单：服务端算的，不是模型说的
    })
```

`impact_preview` 一行是 5.6 案例的直接处方：影响范围（"将终止 47 台实例，其中 2 台近 1h 有流量"级别的话术）必须由 **dry-run 反向生成**，永远不用模型叙述。

---

## 5.3 参数防线与幂等（资产平移 + asyncio 注脚）

三查校验器（额度动态画像/状态机现值 load_for_update/归属权 assert_operable）、拒绝文案模板化不泄风控细节、幂等键从意图派生+canonical 序列化+时间窗+UNIQUE 背书、重复三来源对策表——v1 §5.3 整节概念与 SQL 原样保留。本版补三条 Python 注脚：

1. **行锁在 asyncpg 里的正确姿势**：`SELECT ... FOR UPDATE` 必须在事务内且整个"校验→占坑→执行→提交"链条在同一连接上完成——middleware 里跨 await 别换 session（对照 v1 TOCTOU 教训的异步变体：await 点就是并发切面）；
2. **Decimal 的 canonical 形式**：JSON 序列化金额统一 `str(Decimal.quantize(...))`——浮点表示差异会让 args_hash 抖动导致误判"参数被篡改"（精度纪律与哈希绑定的交叉地带，练习 3 有专门用例）；
3. **取消安全**：执行中被 cancel（0.4.3）时，幂等占坑事务要么整体回滚要么留下可判定中间态——Postgres 事务边界天然保证前者，跨外部系统的写要配 progress 表（第 8 章 saga 预埋伏）。

---

## 5.4 权限沙箱：假设前面全漏了（全节概念保留）

授权衰减 step token（scope 到实体级+15min+jti 一次性）、三级配额漏斗（会话/用户/全局，agent 通道与人工通道分开核算）、爆炸半径三件套（dry-run 效果预览/影子执行/金丝雀租户+每工具独立 feature flag）——v1 §5.4 完整有效。Python 实现件更新两处：

- **step token 签发器**挂在 `RunnableConfig.configurable` 随请求流动（contextvars 兜底读取），工具执行前经 `token.exchange(scope_claim)` 现签短凭证——透传用户长凭证的老毛病在这里结构性杜绝；
- **feature flag 一键止血**：LangGraph 的工具列表由 before_model 装配器动态给出（ch3 tool_governor），下线一个工具=配置中心改一行，秒级生效无需发布——事故时"kill refund_ticket"是一个按钮的正确形态。

世界观重申：**不赌拦截率 100%，赌最坏情况的可逆性与可观测时长。**

---

## 5.5 审计与合规留痕（事件 schema 原样继承）

审计事件 JSON schema（actor.on_behalf_of/basis.context_hash/action.args_hash/approval.chain.presented_args_hash/outcome.external_ref）、四条设计决策（append-only 表权限收回 UPDATE/DELETE、presented==executed 密码学证明、哈希+指针平衡隐私与取证、假名化调和删除权与保留义务）、"审计≠应用日志"点名——v1 §5.5 全节有效且是第 9 章取证演习的评分标准，此处不赘。

---

## 5.6 企业踩坑案例：确认弹窗里的"改写版参数"，和一夜之间消失的 47 台云主机

> 案例全文见 v1 §5.6（渗透测试团队用 PDF 藏指令→agent 照单 terminate→风险闸正确挂起→**审批弹窗的描述字段由 LLM 生成显示"清理过期日志缓存"**→深夜值班员瞄一眼详情点了批准→47 台实例终止含 2 台准生产）。机理与语言无关，三条修复在 v2 栈的落点核对一遍：

| 案例修复项 | v2-LangGraph 落点 |
|---|---|
| 审批界面禁止转译，主区只渲染 args_json 直译 | 5.2.3 的 Pydantic 驱动渲染（模型生成的 basis_digest 物理隔离在 `<details>` 参考区） |
| 送审-执行哈希绑定断言 | 5.2.2 `claim_for_execution(expect_hash=...)`——不符即熔断报警，做成执行前置条件而非事后核对 |
| 影响范围由服务端 dry-run 反算 | `impact_preview` 字段强制：R2+ 工具必须注册 preview 函数才能通过注册门禁（5.1.2 的 __post_init__ 再加一条） |
| 深夜高危双人制 | approval.chain 两段签名 + 非工作时间策略路由第二人（PagerDuty 集成） |
| 注入面收敛 + L4 兜底 | `<untrusted>` 定界（ch3）+ step token scope 限爆：本案那种注入即便骗过所有软防御，也只能动打了 staging 标签的资源 |

复盘金句保留："**护栏的有效性要用对抗测试证明，不能用截图证明**"——下一节练习 4 就是你的季度红队制度雏形。

---

## 动手练习

> `chapter05` 分支。refund_ticket/close_ticket 全流程过闸；产出物直接构成第 6 章对抗评测种子集。

**练习 1 · 风险矩阵与注册门禁（3h）**
ToolDef+risk_gate middleware 完成；启动期扫描全部注册工具（含 MCP 外部工具）断言定级齐全，故意漏标一个观察 fail-fast；annotations 漂移检测（mock server 翻 destructiveHint）触发下线告警。

**练习 2 · interrupt 端到端（6h）**
实现 5.2 全套：挂起（含 PENDING 语义回喂"勿重试"测试）、审批服务表+CAS 双批竞争（asyncio.gather 并发双批准断言恰一执行）、回调恢复（**专项测试：resume 重跑陷阱——在 interrupt 前放计数器，断言恢复后副作用未翻倍**）、执行时重校验（审批通过后偷偷关掉工单，断言 INVALID_STATE 拒绝）、结果回流会话（下轮对话模型可见"退款已执行"）。Pod kill -9 后恢复演示录屏。

**练习 3 · 三查与幂等终验（4h）**
校验器三查+TOCTOU 行锁并发测试；Decimal canonical 与 hash 稳定性用例（同值不同字面量→同 hash；1234.565 流经审批全程逐位相等）；幂等三来源脚本复演（模型重发/回调重投/人工重推恰好一次效果）。

**练习 4 · 红队演练日（4h）**
≥10 条注入样本（工单正文藏全额退款指令/附件 OCR 藏批量操作/ch4 记忆投毒联动）离线跑穿透测试，产出**穿透矩阵热力图**（样本×L1~L5）；无法拦截的样本登记例外+L4 兜底论证。这份矩阵=第 6 章对抗桶种子。

**练习 5 · 沙箱与限爆（3h）**
step token 签发器（scope 实体级+过期+jti 复用拒绝）；三级配额 Resilience4j 等价物（anyio semaphore+Redis 计数）；dry-run preview 贯通并让 impact_preview 出现在审批 UI；feature flag 下线 refund_ticket 计时演练（发现→止血 <1min）。

**练习 6 · 审计与取证演习（2h）**
审计事件全 schema 落库（DB 权限实测：应用账号 UPDATE 被拒）；反向取证 runbook：给定"昨天 15:04 一笔可疑退款"，从审计库 10 分钟还原因果链（trace→审批→参数→依据→身份），过程文档化。

**练习 7 · 对照阅读（1h）**
读 LangChain Human-in-the-Loop middleware 文档（官方把 approve/edit/reject 做成了配置式内置件），回答 15 行笔记：内置件覆盖了 5.2 的哪些格？为什么本课仍手写 gate（提示：双人复核、hash 绑定、执行时重校验三件事内置件给不给？）——顺带体会"能用内置件快速起步、懂原理才能改造兜底"的分寸感。

---

## 本章小结

- **分工表是本章钥匙**：interrupt/checkpointer 还了"挂起不占资源、恢复不丢现场"的债（v1 两张欠条一并结清），但审批语义——挂起什么、谁点头、点头后信什么、世界变了怎么办——百分之百仍是你的业务。框架给引擎，交规你写。
- **resume 重跑陷阱**务必亲手踩一次（练习 2 的计数器测试）：它是 LangGraph HITL 的头号知识税，也是"读过文档"与"上过手"的分水岭。
- **风险分级长在类型里**：ToolDef 无默认值字段+frozen dataclass+__post_init__ 三重结构让"漏标"在 import 期就死；R3 无补偿登记不上线。
- **审批界面禁止转译**升级为可验证制度：Pydantic 直渲染、presented==executed 断言前置、impact 由 dry-run 反算——每一条都有 5.6 案例背书。
- **参数防线与幂等**：三查以执行时刻现值为准（async 世界的 await 点=并发切面，行锁纪律换了语法不换本质）；幂等键防请求、冻结参数副本防意图漂移、事实轨防信念错误——三层各挡各的。
- **沙箱认命，审计较真**：授权衰减+配额+限爆三件套承认拦截有漏网；审计链用哈希绑定与 append-only 权限把"人批准了什么"变成可举证的往事。
- **下一章预告**：防线全部就位，但"拦住了多少、误伤了多少、比上周如何"不能靠感觉——第 6 章把本章穿透矩阵、ch3 探针、ch4 存活率曲线统合成正式评测体系：轨迹指标、pass^k、judge 校准、CI 门禁与线上回流。你练过的每个对抗样本，即将变成简历上那句"安全回归覆盖率"。
