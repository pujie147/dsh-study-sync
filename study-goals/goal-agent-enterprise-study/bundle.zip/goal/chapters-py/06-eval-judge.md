# 第 6 章 · Agent 评测体系：离线基准、LLM-as-judge 与在线评估（Python/LangGraph 版）

> **课程**：面向生产环境的 AI Agent 工程（Python / LangGraph 实战·Java 背景友好版）
> **前置**：本课程 ch2（轨迹漂移实验）、ch3（工具选择探针）、ch4（事实存活率曲线）、ch5（红队穿透矩阵）；goal1 第 7 章规划（RAG 侧 L1 评测）
> **建议学时**：28 小时
> **本章定位**：全课程的战略重心——市场缺口（~57% 进生产 vs ~52% 建有评测）就是你简历的落点。v1-Java 版的三层指标模型、四类难任务 golden set、judge 校准军械库、消融矩阵、在线回流闭环**全部保留**；换栈带来两个实质升级：① harness 从"JUnit 也能做但生态孤独"变成**主场作战**——pytest+LangSmith datasets/evaluate 双轨、DeepEval/promptfoo/τ-bench 可直接跑通复现；② v1 里作为选读的 **user simulator（模拟用户多轮博弈）升为正课**——它恰好治 6.7 案例"golden set 全是单轮任务"的病根，而 LangGraph 的状态图天生适合当模拟器的宿主。前四章散落的探针、曲线、矩阵在本章入册为正式体系。

---

## 本章学习目标

1. 掌握 agent 评测三层模型（终态答案/轨迹/单步决策），说清 pass@k 与 pass^k 的数学与语义差异并贯彻"报告三连写"纪律；
2. 独立构造 TicketAgent golden set（150+ 条）：真实工单反推+双人背靠背标注（κ≥0.8）、四类难任务分层（多跳/应拒绝/需确认/无解）、期望轨迹标"可接受集合"、事故一票入集；
3. 工程化 LLM-as-judge：rubric 维度化+锚定样例+强制引证；位置/冗长/自偏好三偏差校准；与人工金标准的一致性度量（κ≥0.7 上岗证）；judge 用强模型的性价比策略；
4. 用 pytest + LangSmith 双轨建评测 harness：多次运行取分布、结果落库趋势对比、paired bootstrap 显著性检验、三级 CI 门禁（棘轮基线+豁免通道）；
5. 实现 **user simulator**：LLM 扮演"只说半句、中途改主意"的真实用户生成分层多轮剧本，修补离线-线上形态差；
6. 设计执行消融矩阵（编排模式×上下文策略×模型档位），产出"成本-质量-延迟"三维决策表——简历核心素材；
7. 建立在线评估闭环：灰度 A/B、隐式信号（人工接管率为黄金指标）、judge 抽样回放、月度聚类回灌——并把"离线-线上裂口"本身设为首要监控对象；
8. 通过 OTA"离线 92 分开局、接管率爬到 31%"案例，内建分布审计习惯。

---

## 6.0 没有评测的循环（开篇论证保留）

"坏 case→改 prompt→本地试三次好了→发布→别的场景悄悄坏了"的打地鼠循环，三不可病根（不可知/不可比/不可回归）与"测试金字塔→golden set+指标+harness+门禁"的同构映射——v1 §6.0 整段有效。agent 时代的新命题也照旧只有一句：**被测对象从"一次函数的输出"变成了"一段自主决策的过程"——过程也要能测。**

---

## 6.1 三层评测模型与 pass^k（概念资产原样平移）

L1 答案（goal1 复用）/ L2 轨迹（六指标：工具选择正确率/参数合法率/步数效率/终止正确率/越权拦截率/绕路率）/ L3 单步（诊断显微镜）三层结构与指标定义表全部沿用 v1 §6.1。Python 侧的实现红利是**取数零胶水**：

```python
def trajectory_of(result: dict) -> list[Step]:
    """从最终 state 的 messages 直接重建轨迹——观测与评测同源(ch7 伏笔的另一半)。"""
    steps = []
    for m in result["messages"]:
        if isinstance(m, AIMessage) and m.tool_calls:
            for c in m.tool_calls:
                out = next(t for t in result["messages"]
                           if isinstance(t, ToolMessage) and t.tool_call_id == c["id"])
                steps.append(Step(tool=c["name"], args=c["args"],
                                  ok="error" not in (out.content or ""),
                                  tokens=m.usage_metadata["total_tokens"]))
    return steps
```

pass@k vs pass^k 的两种世界观、`p=0.9 → pass@5≈99.999% / pass^5≈59%` 的数字直觉、"任何对外汇报必须 pass^1/^3/^5 三连写"的报告纪律、随机型 vs 确定型失败的不同处方（区分靠多次运行的失败步骤分布图）——**一字不改**（这是概率论不是框架学）。

---

## 6.2 Golden Set：四类难任务与标注流水线（方法论平移，格式 Python 化）

规模诚实账（100~200 条起步甜点区）、四项构成公式（高频正常 40%/四类难任务 35%/对抗样本 15%/历史事故回归 10%）、"事故是最好的免费测试用例"复利机制——v1 §6.2 全保留。四类难任务的 YAML 契约原样可用（Pydantic 校验其 schema，让评测集本身也有类型）：

```python
class GoldenTask(BaseModel):
    id: str
    input: str | list[SimTurn]                 # ★ v2 扩展：支持多轮剧本（6.2.5 simulator）
    hops: list[str] | None                     # 期望工具链
    acceptable_variants: list[str] = []        # 标"可接受集合"不标唯一序列（虚低分数警告）
    reference_min_steps: int | None
    expected_outcome: Literal["answered","refused","pending_approval","unresolvable"]
    assertions: list[dict] = []                # 代码可判断言：如 pending_action.amount==800.00
    negative_assertions: list[str] = []        # "回复不得含'已退款'"这类否定式断言
    bucket: Literal["normal","multihop","reject","hitl","unresolvable","adversarial","incident"]
    version: str                               # 业务变更失效扫描用
```

四类实例（多跳/应拒绝/需确认/无解）连同各自的 failure_modes_to_detect 注释从 v1 §6.2.2 平移——它们考的是 agent 四种人格缺陷（不会规划/没有边界/越权代办/死不承认），与语言无关。反向生成流水线（生成器提效判别器负责/双人背靠背 κ≥0.8/争议仲裁）与"评测集的评测"三指标（标注一致率/条目存活时长/版本戳失效扫描）完整保留。

### 6.2.5 新增正课：user simulator（v1 选做项的兑现）

τ-bench 思想的落地——让 LLM 扮演带隐藏意图的用户与你的 agent 多轮博弈：

```python
class SimPersona(BaseModel):
    goal: str                       # "退掉那件外套，但不想填表单"
    style: Literal["含糊","急躁","改主意","信息挤牙膏"]
    opening: str                    # 只说半句："我那个快递好像有问题…"
    hidden_facts: dict              # 被追问才给：订单号、诉求底线
    drift_at_turn: int | None       # 第几轮改主意（考察意图跟随！）

async def simulate(persona: SimPersona, agent_graph, config):
    msg = HumanMessage(persona.opening)
    for turn in range(MAX_TURNS):
        reply = await agent_graph.ainvoke({"messages": [msg]}, config)
        if done(reply): break
        msg = await user_llm.ainvoke(                      # 另一个模型演用户，
            persona_prompt(persona, history))               # 按人设决定追问/改口/放弃
    return TrajectoryRecord(...)                            # 喂 L2 指标引擎
```

三个使用要点：**(a)** 模拟器与被测系统**异源模型**（防自偏好镜像）；**(b)** 剧本库按"drift_at_turn × style"分层采样——OTA 案例那种"意图会变的用户"从此在离线覆盖得住；**(c)** 模拟器自身的不稳定用固定 seed+温度 0+剧本版本号控制，否则你在测一个移动的靶。这一小节同时回收 ch5 练习的红队样本（注入文本可以藏在模拟用户上传的"附件"里）——攻防与评测两套体系在此合流。

---

## 6.3 LLM-as-judge：外包标注员管理法（全节平移 + 一件新工具）

优先级（确定性断言>规则>judge）、rubric 四写作规则（维度分解/锚定样例/先推理后打分强制引证/二元化倾向）、三偏差校准军械库（换位双评/长度相关系数监控/异源 judge）、judge-人 κ≥0.7 上岗证、judge 用最强模型的性价比论证——v1 §6.3 整节是跨栈通用的方法论财富，原文保留。

Python 生态的增量武器（v1 只能"对照了解"，现在直接调用，但仍要求你先自建一遍再用平台件）：

| 工具 | 拿来做什么 | 本课态度 |
|---|---|---|
| **DeepEval** | G-Eval rubric 模板、conversational 指标族（turn-level/session-level）现成件 | 借其 rubric 写作模板与指标命名；judge 管线主体仍自建（可控性与脱敏） |
| **promptfoo** | YAML 声明式配置矩阵（prompt×model×assert 笛卡尔积） | 快速冒烟对比好用；深度轨迹指标不够 |
| **LangSmith evaluate/datasets** | trace↔dataset 一键互转、线上样本回灌管道现成 | 与 6.6.4 回灌制度天然契合；注意数据出域边界（隐私分区见 ch7） |
| **τ-bench / tau2-bench** | 公开可跑的 tool-agent 基准（零售/航空域+simulator 参考实现） | 跑一遍原版找手感，把它的 user simulator 设计抄进 6.2.5 |

---

## 6.4 Java→Python：harness 落地细节

### 6.4.1 pytest 版评测套件

v1 的三个架构决策（结果落库优先于断言失败/多次运行是协议不是选项/评测流量与生产流量在 trace 上可区分）逐条平移，marker 体系替代 @Tag：

```python
@pytest.mark.eval                                   # 默认不进单测流水线
@pytest.mark.parametrize("task", load_golden(bucket="all"), ids=lambda t: t.id)
async def test_agent_trajectory(task: GoldenTask):
    runs = [await harness.run(task.input) for _ in range(task.repeats)]   # repeats=3 起
    verdict = metrics.evaluate(task, runs)          # L1+L2+L3 全量 + pass^1/^3 判定
    await result_repo.save(verdict)                 # ★ 落库：run_id/git_sha/model_ver/
    assert verdict.final_outcome == task.expected_outcome, verdict.evidence()
    assert not verdict.violations                   # 越权/绕路/重试风暴/否定式断言
```

趋势库 schema 沿用 v1（每 run 一行含三戳+分维指标+成本延迟），Grafana 折线替你盯"上周那次合并是不是弄坏了多跳桶"。并发跑批用 TaskGroup+semaphore 限流（别把供应商 RPM 打爆导致评测自己制造 429 噪声——ch8 容量知识的提前应用）。

### 6.4.2 统计素养（一节都不能少）

噪声底先测再谈改进、paired bootstrap 置信区间（Python 反而更简单，numpy 十行）、多重比较陷阱（1600 个观察值总有假显著→按指标族聚合/校正）、"提升是否显著"话术规范——v1 §6.4.2 全文有效。**agent 调优的日常一半是在跟方差搏斗，统计素养是免费的竞争力**这句加粗保留。

### 6.4.3 三级 CI 门禁

PR 冒烟桶（30 条×1 次纯规则断言，安全类零容忍）/每日全量桶（150×3+judge，分维度基线-2pp 红线）/发布前预发桶（成对比较+新候选）+棘轮基线+带 owner 到期日的豁免清单——表格与反脆弱理由原样平移。CI 载体从 GitHub Actions workflow 到 `uv run pytest -m eval` 的接线在练习 4 完成；**故意劣化合并验证红灯会亮**这条验收仪式不变。

---

## 6.5 消融矩阵：九宫格照旧，臂间调度换引擎

F1 编排模式（裸 create_agent/P&E 图/supervisor 图）× F2 上下文策略（L1 摘要/L2 分层+卡片/激进预算）× F3 模型档位（旗舰/中档/经济+混合路由）的部分因子设计、每臂=全量×repeats、成本估算（几十美元量级 vs 一次事故赔付）、三维决策表与读表三纪律（看分桶不看总票/pass^1-pass^3 落差列单独画/帕累托外直接淘汰）——v1 §6.5 全套方法论保留。

Python 实现的一个便利：LangGraph 的 graph 是一等对象，**消融臂=一张编译好的图变体**，臂间调度器只是 `itertools.product` + TaskGroup：

```python
ARMS = [(orch, ctx, mdl) for orch in [...] for ctx in [...] if not pruned(...)]
async with asyncio.TaskGroup() as tg:
    for arm in ARMS:
        tg.create_task(run_arm(arm, golden_set), name=str(arm))
```

这份《架构选型备忘录》（数据回答"TicketAgent 主干用哪种编排"+显著性过程）继续担任第 9 章简历原料。

---

## 6.6 在线评估：三组仪表与回灌闭环（全节平移）

离线-线上四大系统性差距（分布/环境/交互/时间差）的分析框架、灰度 A/B 要点（方差大→样本量预估；影子流量先行）、隐式信号表（👍👎有偏只看趋势/**追问率**/**人工接管率=黄金指标**/复制行为/会话放弃率=沉默流失）、judge 在线抽样（2% 异步、同 rubric 版本才可比、PII 脱敏前置）、周期回放制度（周冒烟/月全量/触发式：供应商版本公告或幻觉工具名率突增）、月度回灌仪式（线上会话→意图 embedding 聚类→未覆盖簇识别→脱敏标注→入集打版本戳→基线重算）——**v1 §6.6 整节是本章含金量最高的运维设计，与栈无关，原文继承**。

Python 侧两件顺手事：LangSmith 的 dataset↔trace 互转把"一键把真实 trace 变 golden 条目"做成平台功能（6.3 表的兑现处）；聚类脚本 sklearn 一行（这也是当年 Java 方案里要跨语言调用的部分，今天母语直写）。**"评测集的演化速率=团队学习速率的下限"**题眼保留。

---

## 6.7 企业踩坑案例：离线 92 分开局，接管率三个月爬到 31%（案例通用，两处 v2 注脚）

v1 §6.7 全文有效（800 条 golden set 里 780 条单轮问答 vs 真实主战场"开口半句→贴截图→中途改主意"的多轮模糊指令；judge 只评终态放过过程缺陷；暑期暴雨退改高峰让未覆盖任务占比冲到 17%；五板斧修复与"会议语言从'92 分怎么回事'变成'多跳桶掉了 3 个点，回放 diff 指向 prompt v14'"的成熟度标志）。

v2 注脚两条：**(a)** 该案第一板斧"引入 user simulator 把多轮占比提到 45%"正是本章 6.2.5 正课的历史出处——你现在学的就是那家公司的修复方案；**(b)** 三条带走教训之首"golden set 是业务分布的假设不是事实，每季度重新测绘"在 Python 栈的实施成本更低（聚类+diff 报表都是 pandas 十分钟的事），**借口更少，更没有理由不做**。

---

## 动手练习

> `chapter06` 分支。前三章散落的探针/曲线/矩阵全部入册；交付完整评测基础设施+第一份消融报告。

**练习 1 · Golden set v1（6h）**
反向生成+人工清洗 120 条（四类配比达标、acceptable_variants 齐全、对抗桶迁入 ch3/ch5 样本 ≥20 条）；GoldenTask Pydantic 校验+双人背靠背 10% 抽检 κ 报告；YAML+DB 双格式带版本戳。

**练习 2 · 轨迹指标引擎（5h）**
实现 trajectory_of+六指标计算器+pass^1/^3/^5 格式化器；对 ch2 三种编排各跑一轮出第一份分桶成绩单（数字难看没关系，先有基线）。

**练习 3 · Judge 校准工作坊（5h）**
四维 rubric（锚定样例）→ 人工盲标 60 条 → κ 计算与不一致案例归类 → 迭代至 κ≥0.7，产出《judge 校准报告》；位置偏差实验 20 组成对样本正反序翻转率统计。

**练习 4 · Harness 与门禁（4h）**
pytest marker 体系+并发限流跑批+结果落库+Grafana 趋势面板+棘轮门禁接 CI；故意劣化合并（max_turns 8→3）验证红灯，留档。

**练习 5 · User simulator（4h）**
实现 SimPersona 剧本库（style×drift 分层 ≥30 个 persona），接入 golden set 的多轮任务格式；重点复现一组"OTA 病灶"用例：agent 在用户 drift_at_turn=3 时的意图跟随成功率——把这个指标加入 L2 家族（命名 intent_follow_rate）。

**练习 6 · 消融矩阵首战（5h）**
F1×F2 九宫格（repeats=3），三维决策表+帕累托图+《架构选型备忘录》（含 bootstrap 显著性过程）；结论回填 ch2 练习 6 的选型表形成闭环。

**练习 7 · 线上回流最小闭环（3h）**
mock 流量→意图聚类→未覆盖簇报告→"trace 一键转 golden 条目"脚本（脱敏+预填标注模板）；跑一次月度回灌演习写 10 行复盘。另交 15 行阅读笔记：跑 τ-bench 官方 quickstart 的观感+与我们 L2 指标的异同。

---

## 本章小结

- **三层坐标系定型**：L1 复用、L2 管选型与稳定性证据、L3 管诊断显微镜；LangGraph 的 messages 结构让轨迹取数近乎零胶水——**评测与观测共用一套 schema 的伏笔正式合龙**。
- **pass^k 是生产观**：demo 话术与 SLA 口径的分水岭就在那道指数；失败分布图决定你开的是重试药还是降级药。
- **golden set 按失败模式分层**：四类难任务对应四种人格缺陷；标可接受集合不标唯一序列；事故一票入集；**季度重测绘地图**——user simulator 的转正让"多轮模糊指令"从盲区变成覆盖区（OTA 案例的直接免疫）。
- **judge 是外包标注员**：确定性断言永远优先；rubric 维度化+锚定+引证；三偏差各有军械；**κ 一致性是上岗证**；judge 用最贵的模型是全场性价比之王。
- **统计与门禁是制度的两翼**：bootstrap 置信区间防自欺，三级门禁+棘轮+豁免通道防回退——没被误杀过一次的门禁等于没验证过的门禁。
- **消融矩阵清偿选型债**：臂=图变体的调度便利让九宫格一晚上跑得完；分桶读数、落差列可视化、帕累托淘汰——把"我觉得"变成"九宫格显示"。
- **在线仪表与回灌闭环是系统的代谢**：接管率为王、裂口本身是被监控的首要指标、评测集演化速率=学习速率下限。
- **下一章预告**：评测告诉你"该看什么数字"，第 7 章解决"数字从哪来"——callbacks/middleware 埋点、OTel GenAI semconv、LangSmith∥Langfuse 双轨、三级成本核算与三道预算闸。你手里那份 pass^3 曲线的每一次运行，都将在玻璃盒里留下可回放的骨架。
