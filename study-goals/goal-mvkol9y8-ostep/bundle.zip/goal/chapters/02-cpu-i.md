# 第 2 章 CPU 虚拟化 I：进程与直接执行机制

## ② 本章概览（总）

### 本章在全课程框架中的位置

第 1 章立了「虚拟化 = 机制 + 策略」的总纲。本章走 CPU 虚拟化的**机制半边**：进程这个抽象到底是怎么被造出来的——直接执行、受限运行、定时器中断驱动上下文切换、进程创建/销毁 API（fork/exec/wait）与 PCB。这是全书第一个「机制→策略」闭环中的机制部分（策略部分见第 3 章），也是后续所有实验的操作基础。框架归属：本章几乎全部落在**控制层**（模式切换、trap、上下文切换）与**数据层**（PCB），服务层的调度决策暂不展开。对应 OSTEP Ch.4–7。

### 本章抽象框架

```mermaid
flowchart TB
    subgraph MECH["CPU 虚拟化的机制链条"]
        DE["直接执行<br>程序独占 CPU 一跑到底"]
        LR["受限运行<br>OS 可随时夺回控制权"]
        TIMER["定时器中断<br>不请自来的闹钟"]
        TRAP["trap 进内核<br>保存现场 PCB"]
        CS["上下文切换<br>换一块 PCB 恢复现场"]
    end
    API["进程 API<br>fork 造 新 进程 exec 换 内 核 wait 收 尸"]
    DE -->|"为什么不够"| LR
    LR --> TIMER --> TRAP --> CS
    API -.->|"进程从哪来 到哪去"| TRAP
```

一句话说明：先用「直接执行」体验裸跑，再靠定时器中断把控制权强制收回来，收回来时把运行状态存进 PCB、换上另一个进程的 PCB——这一存一换就是上下文切换；fork/exec/wait 则回答「被切换的那些进程从哪造出来、死后怎么收场」。

### 分节地图

- 4.1 进程 = 运行中的程序：PCB 里存什么
- 4.2 直接执行：裸跑之美与不足
- 4.3 受限运行与定时器中断：OS 如何夺回 CPU
- 4.4 上下文切换完整时序（含小实验：汇编视角看 PC 的保存与恢复）
- 4.5 进程 API：fork / exec / wait 三件套（含两个经典坑）

### 本章欠账声明（黑盒）

- OS 按什么规则**挑选下一个运行的进程**（调度策略）——作黑盒使用，第 3 章详述 → 已在第 3 章讲清
- fork 的**代价为什么只是复制页表**（Copy-on-Write 与页表机制）——作黑盒使用，第 5 章详述 → 已在第 5 章讲清

## ③ 承接与补完

- **承接第 1 章**：第 1 章欠的两笔账在此清偿——上下文切换机制（4.3–4.4）与 fork/exec/wait 语义（4.5）；第 1 章 4.2 节「syscall 入境通道」的概念在本章升级为完整 trap 时序。工程上，第 1 章 demo 中黑盒使用的 `fork/execl/wait`，本章逐句讲清。
- **本章分支动线**：从第 1 章合并点（main 上的 `--no-ff` 合并提交）出发：

  ```bash
  git checkout main && git pull . 2>/dev/null; git checkout -b chapter/02-process-mechanism
  ```

- **章末验证点**：`mini-init` 运行后 `ps` 进程树正确、无僵尸残留（见⑤）。达成后合并回 `main`。

## ④ 正文

### 4.1 进程 = 运行中的程序：PCB 里存什么

**结论先行：进程不是程序文件，而是「一次运行的全部状态」；OS 用一个数据结构把它记下来，这就是进程控制块（PCB, process control block）。**

程序是磁盘上的静态字节（第 8 章会讲文件）；运行 = 载入内存后 CPU 顺着指令走。要把「运行」虚拟化成人手一个，OS 必须随时能回答：**这个进程走到哪了？接下来该执行哪条指令？它拥有哪些资源？** PCB 的最小必存项：

| PCB 字段 | 作用 |
|---|---|
| PC（程序计数器） | 下一条要执行的指令地址——进程的灵魂位置 |
| 通用寄存器组 | 暂停瞬间的运算现场（第 6 章会看到 `mov` 对 eax 等的使用） |
| 状态 | NEW/READY/RUNNING/EXITED 等（就绪 ≠ 运行：READY 是等 CPU，RUNNING 正占着 CPU） |
| PID 与父子关系 | 全局唯一的进程号；wait 按它收尸（4.5） |
| 内存资源信息 | 指向本进程地址空间/页表的指针（第 4–5 章的主角，本章先当作 PCB 里的一条记录） |
| 打开文件表 | 指向文件描述符表的指针（第 8 章详述其语义） |
| 调度信息 | 优先级等——供第 3 章的策略使用 |

Linux 的实现视角（一句话）：内核里线程就是用 `clone(2)` 创建的进程，`pthread_create(3)` 亦由 clone 实现——PCB 的实体是内核的 `task_struct`（来源 4 的 wait(2) NOTES 佐证这一关系，线程细节第 6 章展开）。

OSTEP 配套模拟器 `process-run.py` 把 PCB 演成可见状态：每条指令（`sleep 1`、`iou 1`）执行时打印「当前 PC 指向哪、寄存器值、切换到哪个进程」——跑一遍胜过千言（见⑤练习 1）。

> 常见误区：「进程死了就没了」。错——退出的进程在**父进程 wait 之前**会以**僵尸（zombie）**状态继续占用进程表槽位与一份最小 PCB（记录退出码），这正是 4.5.3 要处理的。

### 4.2 直接执行：裸跑之美与不足

**结论先行：最朴素的 OS 什么也不做——把 CPU 直接交给程序（direct execution），程序从入口地址顺序执行，直到主动把控制权还给 OS。这能跑，但跑不好。**

直接执行的三拍（书 Ch.6 骨架，(补充) 依书叙述）：

1. **移交控制权**：OS 加载程序后跳入其入口，此后 OS 自己不占 CPU——「让 CPU 直接执行用户程序代码」。
2. **跑下去**：程序顺序执行指令；遇 I/O 则**忙等（spin-wait）**轮询设备状态（设备何时完成，程序只能反复去看——第 8 章会看到中断/DMA 如何改掉这一窘态，此处作概念预告不展开）。
3. **交回控制权**：程序以 `trap` 类指令（如 `int 0x80`）主动回内核，例如请求退出。

它的问题一目了然：程序若不主动交回（死循环、恶意代码），OS 永远拿不回 CPU；I/O 忙等时 CPU 白白空转。**修复第一条，就是受限运行。**

### 4.3 受限运行与定时器中断：OS 如何夺回 CPU

**结论先行：让「不交回控制权」变得不可能——给 CPU 装一个闹钟（定时器中断），时间一到，硬件强制把 CPU 交给 OS。**

- 开机时 OS 在硬件的**中断向量表**注册：定时器到期该跳入哪个内核入口地址。此后 OS 只需设置「每 $n$ 毫秒响一次」。
- 闹钟响时，CPU 正在用户态的任意一条指令边界上**被硬件打断**：切到内核态、按向量表跳入 OS 的 handler——用户程序无权也无力阻止。
- OS handler 从此拥有了一段「说话算话」的时间窗：它想换谁跑就换谁跑。

第 1 章 4.2 说过系统调用是「主动入境」；定时器中断则是「被强制带入境」。两者汇入同一条 trap 大道——这就是「受限运行（limited run）」的全貌：OS 始终保留最终控制权。

> 常见误区：「多核才需要抢 CPU」。单核同样需要——虚拟化本质是**把一个变成多个**，哪怕物理上只有一个。

### 4.4 上下文切换完整时序

**结论先行：一次切换 = 保存旧进程现场到其 PCB + 换用新进程 PCB + 恢复现场。硬件负责「进门」，软件负责「换人」。**

```mermaid
sequenceDiagram
    participant A as 进程A 用户态
    participant HW as CPU 硬件
    participant OS as OS 内核 handler
    participant B as 进程B 用户态
    A->>HW: 正在执行第 N 条指令
    HW->>OS: 定时器中断 硬件保存PC与状态进入内核态
    OS->>OS: 把 A 的寄存器现场存入 A 的 PCB 状态改READY
    OS->>OS: 挑选下一个进程 记为B 策略细节见第3章黑盒
    OS->>OS: 切内存映射指针 使此后地址翻译属于 B
    OS->>B: 从 B 的 PCB 恢复寄存器与PC 返回用户态
    B->>B: 从它上次停下的那条指令继续跑
```

一句话说明：注意「切地址翻译指针」这一步——CPU 靠一个寄存器（如 x86 的 CR3）知道「当前用谁的页表」，换进程必须先换它，否则恢复的 PC 会被翻译到错误的物理内存。第 5 章将把这条线彻底展开，本章按黑盒处理。

**小实验（gdb 版 crash，替代书内 x86 crash 实操）**：资料缺口注明书中 crash/x86 汇编片段只有 PDF 示例，这里用可复现的方式观察 PC 的保存/恢复：

```bash
gcc -g -o loop src/loop.c   # src/loop.c 就是一个 while(1) 空循环
gdb ./loop
(gdb) break main
(gdb) run
(gdb) info registers rip    # 观察 PC 当前值
(gdb) stepi                 # 单步一条机器指令，再看 rip 如何+4/+5 前进
(gdb) disassemble           # 反汇编当前函数
```

`stepi` 让你看见：PC 就是可被存取的普通寄存器值，「保存 PC」即把该值写进内存某处（PCB），「恢复 PC」即反过来——第 9 章在 xv6 源码里会看到这两句的真实 C 与汇编（`saving.pc = ...` / `sret`）。

### 4.5 进程 API：fork / exec / wait 三件套

**结论先行：fork 造一个「和自己一模一样的进程」，exec 把一个进程「换脑」成新程序，wait 替父进程「收尸」拿回孩子的退出状态。三者正交组合，能搭出一切进程创建场景。**（本节事实均出自 man 页原文，来源 3/4/5。）

#### 4.5.1 fork()：返回值双份的坑

`pid_t fork(void)` —— 调用**一次**，返回**两次**：

- 在**父进程**中：返回**子进程的 PID**（>0）；
- 在**子进程**中：返回 **0**；
- 出错：父进程收到 **-1**，没有子进程。

```c
pid_t pid = fork();
if (pid < 0) {
    perror("fork");            /* 只有父进程会走到这 */
    exit(EXIT_FAILURE);
}
if (pid == 0) {
    /* 子进程代码：此处 pid 是 0 */
} else {
    /* 父进程代码：此处 pid 是孩子 PID */
}
```

**这就是「用返回值当 if 条件分流」的标准形**；忘了判 0 分支、或忘了 `pid<0` 错误分支，是两个最常见的坑。

语义清单（来源 3）：子进程拥有唯一 PID、ppid 指向父亲；**父子运行在分离的内存空间**，一方写入不影响另一方（Linux 用 CoW 页实现，代价仅为复制页表与建 task 结构——为什么便宜，第 5 章详述）；子进程**不继承**内存锁、挂起信号、计时器，但**继承打开文件描述符的副本**（父子共享同一 open file description 与文件偏移，第 8 章细讲）。

#### 4.5.2 exec：不是「新进程」，是「换脑」

族系入口 `int execv(const char *path, char *const argv[])`（还有 execl 等变体，语义同一）。权威正名（来源 4）：

> 常见描述「execve 执行了一个**新进程**」是高度误导的——**没有新进程**：PID 等许多属性不变，只是让**现有进程**去执行一个新程序。

成功后**永不返回**：text/data/bss/stack 被新程序镜像覆盖；失败才返回 -1（`perror` 之后代码继续跑，这是 `execlp("nosuchcmd"...)` 后还能打印错误的原理——务必把 exec 放在子进程的 if 之后）。默认 fd 跨 exec 保留（除非 `O_CLOEXEC`）；mmap 映射不保留；信号处置重置。`argv/envp` 成为新程序的 `main(argc, argv, envp)`。shell 脚本首行 `#!interpreter` 的解释器机制也在此定义——OSTEP Ch.39 之后讲管道时还会回到 exec 家族。

#### 4.5.3 wait：收尸与僵尸

`wait(&status)` / `waitpid(pid, &status, options)`（来源 5）：

- 子进程**终止但未被等待** ⇒ 僵尸：内核保留其 PID、退出状态、资源用量，占着进程表槽位；**表满将无法再创建进程**。
- 父进程 wait 后僵尸资源释放；父先死 ⇒ 僵尸被 `init(1)` 收养并自动 wait。
- 退出状态打包在 `status` 整数里，用宏解剖：`WIFEXITED(status)` 判正常退出、`WEXITSTATUS(status)` 取退出码、`WIFSIGNALED`/`WTERMSIG` 判信号致死。
- 偷懒正确姿势：`signal(SIGCHLD, SIG_IGN)` ⇒ 孩子终止即不成僵尸（POSIX 行为，Linux 2.6 起遵循）——但你就拿不到退出码了；`mini-init` 这类要记账的进程必须老实 wait。

**典型用法组合**（shell 语义的雏形）：`fork()` 出孩子 → 孩子 `execl(...)` 变成目标程序 → 父亲 `waitpid(...)` 收状态。三个 API 各司其职，**fork 复制、exec 替换、wait 回收**——第 9 章看 xv6 的 `fork1()/exec()/wait()` 实现时会认出同一套骨架。

> 常见误区三连：① 以为 fork 复制了「已 exec 的新程序」——顺序反了：先 fork 再各自决定；② 以为 exec 失败会回退到旧程序——不会，原镜像已拆，极端时内核直接杀进程（来源 4 NOTES）；③ 以为 wait 只等「直接孩子中的某一个特定 pid」——`waitpid(-1,...)` 可等任意孩子，options 里 `WNOHANG` 可立即返回。

## ⑤ 动手练习（统一工程 hello-os）

在 `chapter/02-process-mechanism` 分支增量开发：

1. **模拟器先行**：`cd ../ostep-homework/cpu-intro`；跑 `./process-run.py -l sleep10.txt -s 0` 观察 PC/寄存器如何随指令变化；再 `-x` 打开「每条指令都尝试切换」，亲眼看到上下文切换在每个指令边界的可能插入点；换 `-l io-busy.txt`（含 `iou`）看 I/O 与 CPU 的并行。把「哪一行输出显示进程状态 READY 而 CPU 空闲」记进 README。
2. **mini-init**：`src/mini_init.c`——循环 `fork()` 出 3 个孩子，各自 `execl("/bin/sleep", "sleep", "2", ...)`；父亲用 `waitpid(-1, &st, 0)` **循环收尸**直到 `ECHILD`，用 `WIFEXITED/WEXITSTATUS` 打印每个孩子退出码。
3. **僵尸现场重现**：临时改码：fork 后父亲 `pause()`（不 wait）。运行，另开终端 `ps aux | grep sleep`，找出状态列为 `Z` 的进程行，截图/粘贴进 README；再恢复 wait 版本，确认消失。
4. **gdb 观察**：对 `src/loop.c`（`while(1);`）做 4.4 的 `info registers rip` + `stepi` 实验，记录两次 rip 值与差值。
5. **Makefile** 增加 `mini-init` 与 `loop` 目标，`make run` 行为不变（不破坏第 1 章验证点）。

**章末验证点**：mini-init 全生命周期中 `ps` 显示的进程树正确（父 PID 链完整）、结束时**无 `Z` 状态残留**；README 含僵尸重现记录。通过后合并回 `main`。

## ⑥ 本章小结

1. **进程 = 运行中的程序 + 全部可恢复状态**；PCB 记 PC、寄存器、状态、PID/父子、内存资源指针、打开文件表、调度信息（4.1）。
2. **直接执行**让程序独占 CPU 直到主动交回，I/O 靠忙等——「不交回」的漏洞必须由**受限运行**堵上（4.2）。
3. **定时器中断 + 中断向量表**：OS 夺回控制权的机制；trap 进内核有「主动（syscall）/被动（中断）」两种入口（4.3）。
4. **上下文切换 = 存现场入 PCB + 切地址翻译指针 + 从新 PCB 恢复现场**；gdb `stepi` 可见 PC 只是可存取的寄存器值（4.4）。
5. **fork 一次调用两次返回**（父得孩子 PID / 子得 0 / 出错 -1），父子内存分离（Linux CoW 实现，便宜原因欠账第 5 章）；**exec 不换进程只换程序**，成功不返回；**wait 收尸**，僵尸占进程表、`SIG_IGN` 可免（4.5）。
6. 本章框架挂回总图：控制层（trap/中断/切换）与数据层（PCB）已建，服务层的「选谁跑」留待第 3 章。

## ⑦ 参考来源

1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html
2. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework
3. fork(2) — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man2/fork.2.html
4. execve(2) — Linux manual page — https://man7.org/linux/man-pages/man2/execve.2.html
5. wait(2)/waitpid — Linux manual page — https://man7.org/linux/man-pages/man2/wait.2.html
6. xv6 book 目录（mit-pdos.github.io） — https://mit-pdos.github.io/xv6-riscv-book/
