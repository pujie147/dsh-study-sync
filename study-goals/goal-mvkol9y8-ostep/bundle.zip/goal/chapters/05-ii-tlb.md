# 第 5 章 内存虚拟化 II：分页、TLB 与超越物理内存

## ② 本章概览（总）

### 本章在全课程框架中的位置

分页是内存虚拟化的**核心答案**：第 4 章的连续方案被外部碎片判了缓刑，本章用「固定大小页 + 每进程页表」终结它。随后跨过物理内存的边界——当页不够用时，OS 靠局部性原理与置换策略把冷页搬去磁盘（swap 空间），再叠上 CoW 与 mmap 这两个「完整 VM 系统」的高级特征。第 1、2、4 章关于页表与 CoW 的欠账在本章全部清偿。框架归属：服务层（地址翻译、置换）+ 数据层（页表、TLB、PTE）。对应 OSTEP Ch.18–24。

### 本章抽象框架

```mermaid
flowchart TB
    PAGE["把内存切成等大的页<br>虚拟页 对 物理页帧"] --> TABLE["每进程一张页表<br>VPN 查 PPN 加 有效位 保护位"]
    TABLE --> TLB["翻译太慢 加缓存<br>TLB 命中 或 缺页"]
    TLB --> MULTI["页表本身太大 分层<br>多级页表 稀疏地址空间的对策"]
    MULTI --> BEYOND["物理内存不够<br>局部性 支撑 置换策略 LRU Clock WS"]
    BEYOND --> FULL["完整 VM 特征<br>CoW 与 mmap 共享 私有"]
```

一句话说明：分页定抽象（页是单位），页表定机制（查表翻译），TLB 定加速（缓存翻译），多级定开销控制，置换定策略（谁离开内存），CoW/mmap 定上层建筑——层层递进，每一层都在解上一层引入的新问题。

### 分节地图

- 5.1 分页与地址翻译全流程：VPN → 页表 → PPN
- 5.2 TLB：翻译的缓存
- 5.3 多级页表：给稀疏地址空间瘦身
- 5.4 反置页表（一瞥）
- 5.5 局部性与置换策略：LRU / Clock / Working Set
- 5.6 交换、thrashing 与完整 VM 系统
- 5.7 fork 的 Copy-on-Write 与 mmap 两种模式

### 本章欠账声明（黑盒）

- **磁盘的机理与性能**（swap 空间为何慢、寻道/旋转/传输）——作黑盒使用，第 8 章详述 → 已在第 8 章讲清

## ③ 承接与补完

- **承接**：第 4 章留下的「物理页何时真正出现」在本章 5.6 demand paging 讲清；第 2 章「fork 只复制页表」在 5.7 展开；第 4 章 base+limit 的粗保护升级为 5.1 PTE 的逐页权限位。第 1 章 4–5 章合账在此终结（分页部分）。
- **本章分支动线**：

  ```bash
  git checkout main && git checkout -b chapter/05-paging-tlb
  ```

- **前置章标注回改**：第 2 章 CoW 黑盒与第 4 章分页黑盒均已追加「已在第 5 章讲清」。
- **章末验证点**：给定访问序列的 TLB 命中率手算与模拟器一致；CoW demo 计数正确（见⑤）。达成后合并回 `main`。

## ④ 正文

### 5.1 分页与地址翻译全流程：VPN → 页表 → PPN

**结论先行：等大小页一刀切平两个碎片——虚拟地址空间切**虚拟页**（VPN），物理内存切**页帧**（PPN）；页表即「VPN→PPN」的查找表，连续问题被彻底消除（任何 VPN 可落任何空闲 PPN）。**

**直觉版公式**：地址按页大小 $P$ 平铺时，

$$va = VPN \times P + offset, \qquad pa = PPN \times P + offset$$

翻译即「查表换 PPN、offset 原样保留」。二进制视角更常用：虚拟地址切成 **高位 VPN + 低位 offset** 两段，$offset$ 位数 $= \log_2 P$（如 4KB 页取低 12 位）（依书 Ch.18 骨架，(补充) 表述方式）。

每页的页表项（PTE）至少装四样东西：

| PTE 字段 | 作用 |
|---|---|
| Valid 有效位 | 1=该页当前驻留内存；0=在磁盘或不存在 ⇒ 访问它触发**缺页异常** |
| Protection 保护位 | 读/写/执行权限——第 4 章段内粒度的答案（如代码页只读、栈可读写） |
| PPN 物理页号 | 目标页帧 |
| （另有）dirty/present 等 | 支撑写回与交换（5.5–5.6） |

```mermaid
sequenceDiagram
    participant C as CPU 发出虚拟地址 va
    participant T as TLB
    participant PT as 页表 内存中
    participant OS as OS 缺页处理
    C->>T: 用 VPN 查 TLB
    T-->>C: 命中 直接得 PPN 拼 pa 继续执行
    T->>PT: 未命中 访问进程页表第 VPN 项
    PT-->>T: 有效位 1 PPN 填入 TLB 重试
    PT->>OS: 有效位 0 触发缺页 trap
    OS->>OS: 从磁盘取回该页 更新PTE 或 分配新页
    OS-->>C: 重启原指令
```

一句话说明：一次翻译的三种结局——TLB 命中（最快）、页表命中（慢一点）、缺页（最慢，要走磁盘）。内存层级结构「寄存器→cache→TLB→主存→磁盘」正是这三档速度的物理表达（TLB 与页表都在内存层级里，磁盘按黑盒第 8 章）。

内核文档对齐点（来源 2）：页表层级组织、顶层指针驻寄存器（x86 即 **CR3**，切换进程时硬件自动加载新 CR3——第 2 章「切地址翻译指针」的真相）、高位逐级索引、低位页内偏移。实验：`paging-linear-translate.py` 手算 VPN/PPN 拼接；`mem.c` 在真机打印某虚拟地址对应的物理地址（需 root 读 pagemap）。

> 常见误区：「页表是 per-CPU 的」。页表是 **per-process** 的数据结构（挂在 PCB 里那条内存记录上，第 2 章），CR3 只是「当前进程用哪张」的指针。

### 5.2 TLB：翻译的缓存

**结论先行：分页把翻译变成「每次访存先查表」，查表本身要访存——TLB 用一小块全相连硬件缓存把查表成本摊掉。**

- TLB（Translation Lookaside Buffer）= 少量「VPN→PPN+权限」条目的硬件缓存，**每 CPU 核心一份**（进程切换时按 CR3 标记刷新/选择性失效）。
- 内核文档的定位（来源 2）：TLB 是**稀缺资源**，工作集大的应用受 TLB miss 拖累——「TLB pressure」从此进入你的词汇表。
- 大页（huge pages）是 TLB 的解药：x86 允许二/三级页表项直接映射 **2MB/1GB** 页，一条 TLB 项覆盖的地址范围成倍扩大（来源 2；Linux 的 hugetlbfs 与 THP 两机制属延伸）。
- 实验：`paging-multilevel-translate.py` 内置 TLB 模拟（命中率可打印），本章验证点即用它与手算对拍（来源 1）。

### 5.3 多级页表：给稀疏地址空间的对策

**结论先行：64 位地址空间按页表全量存会浪费天文数字的空间——但真实使用是稀疏的；解法是把页表也做成树，只为「真用到了的区域」分配低层表。**

- 线性页表的问题：$2^{48}/2^{12}=2^{36}$ 项 × 8B ≈ 512GB 一张表——不可行。
- **多级页表**：顶层表索引二级表，二级索引三级……最后一级才是 PTE。未使用的区域**整个子树直接不分配**（顶层项有效位=0 即可跳过）——稀疏性免费变现为空间。
- 代价：一次 TLB miss 要 $k$ 次内存访问（$k$ 级）。工程补偿：各级中间表项也可缓存（PDE 缓存），以及 5.2 的大页「跳级」。
- 实验：`paging-multilevel-translate.py -s -n -k -p` 参数组（来源 1、README 为准）。

**x86-64 的四级实例**（资料缺口清偿：书只讲通用模型；本节图示为自绘，依据 Intel SDM Vol.3A §4.5，标注补充）：

```mermaid
flowchart TB
    VA["48 位有效虚拟地址<br>高 16 位符号扩展 canonical"] --> L4["bits 47..39 PGD 索引 9 位"]
    L4 --> L3["bits 38..30 PUD 索引 9 位"]
    L3 --> L2["bits 29..21 PMD 索引 9 位"]
    L2 --> L1["bits 20..12 PTE 索引 9 位"]
    L1 --> OFF["bits 11..0 页内偏移 12 位"]
```

(补充) 一句话说明：每级表 512 项（$2^9$）、恰占一页；Linux 的 `mm_struct` 里对应 pgd/p4d/pud/pmd/pte 五个遍历宏；2MB 大页跳过最后一级、1GB 跳过两级——对应「二/三级表项直接映射」的内核文档说法（来源 2）。canonical 地址（高 16 位复制第 47 位）解释了用户/内核地址各半壁江山。

### 5.4 反置页表（一瞥）

**结论先行：正置页表「每进程一张」，空间开销与进程数相乘；反置页表（IPT）改成全系统一张——每物理页帧一项，存 (进程, 虚拟页, 权限)。**

查表变成「按 (pid, VPN) 全表搜索」，靠哈希加速；共享与多核同步问题也随之而来。教学定位：**知道它存在、知道它把「页表大小 × 进程数」的矛盾翻转成「每帧一项」即可**（依书 Ch.23；本次无网络一手材料需求，见资料缺口节——不需要额外来源，标注依书即可）。

### 5.5 局部性与置换策略：当物理内存不够装全部页

**结论先行：内存超配的前提是程序不会同时用到所有页——这是局部性原理；OS 据此在缺页时决定「谁被踢出去」，置换策略是本章的纯策略部分。**

- **局部性（locality of reference）**：时间局部性（刚用过的还会再用）+ 空间局部性（邻近地址会被用）。程序循环、数组扫描、栈帧都在强化它（依书 Ch.22）。
- 度量：**页错误率**（page fault rate）与**缺页代价** $T_{fault} \approx T_{disk} + T_{restart}$——磁盘项主导，故第 8 章讲磁盘性能后你会重新理解「为什么缺页贵得离谱」（黑盒预告）。
- **最优算法 OPT**（踢未来最久不用的）：不可实现的基准，一切启发式与之比差距。
- **LRU**（踢最久未用的）：逼近 OPT 但硬件记账昂贵。
- **Clock / 二次机会**：用 PTE 的 referenced 位 + 环形指针近似 LRU，工程主流（依书 Ch.22）。
- **Working Set**：以最近 $W$ 次访问集合为驻留依据——与「局部性」直接挂钩（依书 Ch.22）。
- 实验主战场：`paging-policy.py -a FIFO|LRU|CLOCK|WS -n`（来源 1）。

### 5.6 交换、thrashing 与完整 VM 系统

**结论先行：被踢出的页写入磁盘上的 swap 空间；当系统整体超配、页错误率高到 CPU 大部分时间在等换页，就是 thrashing——OS 的对抗手段是 Swapper 整进程换出 + 工作集记账。**

- **swap 空间**：磁盘上一块按页对齐的区域；页可能来自文件（干净，可直接丢弃重读）或匿名内存（脏，必须先写回）——「脏页/净页」之别决定换出代价（依书 Ch.21–22）。
- **两级体系**：per-process 页表（进程视角）+ per-machine 反向映射（内存视角：这物理页属于谁的哪一页）——Swapper 选「整个进程换出」时靠后者（依书 Ch.23，本章点到为止）。
- **thrashing 对策**：监控页错误率、按工作集准入/驱逐；Linux 真实形态 = reclaim/kswapd/OOM killer 谱系（来源 2 的 Reclaim/OOM 段——kswapd 异步扫描、低水位线触发、min 水位线则同步回收、极端时 OOM killer 杀任务救系统）。这是 5.5 置换策略在生产系统的放大版，对照阅读。
- CoW 与 mmap 之后，Ch.23「Complete VM Systems」把这些拼成 Linux 全景：demand paging + swap + Swapper + overcommit 准入。

### 5.7 fork 的 Copy-on-Write 与 mmap 两种模式

**结论先行：fork 不复制字节，只复制页表并把双方页标记为只读；谁先写谁触发缺页，缺页处理程序此刻才复制那一页——这就是第 2 章「fork 代价只是复制页表」的完整答案。mmap 则提供共享（MAP_SHARED）与私有 CoW（MAP_PRIVATE）两种映射语义。**

**CoW 时序**（依书 Ch.24 + man 页事实）：

```mermaid
sequenceDiagram
    participant P as 父进程
    participant K as 内核
    participant C as 子进程
    P->>K: fork 系统调用
    K->>K: 子进程页表 每项指向与父相同的物理页<br>双方 PTE 置只读
    K-->>C: 返回 0
    K-->>P: 返回子 PID
    C->>C: 写某页 触发保护缺页
    C->>K: 缺页处理 判定 CoW 场景
    K->>K: 为该页分配新物理页 拷贝 改PTE为可写
    K-->>C: 重启写指令 完成
```

一句话说明：fork 后「读不花钱、写才付费」；若父子都只读则物理页始终共享。权威注脚（来源 4 fork(2) NOTES）：Linux fork 以 CoW 页实现，代价仅为复制页表与创建 task 结构；且「父子运行在分离的内存空间，一方写入不影响另一方」（来源 4 DESCRIPTION 首段）——CoW 正是实现这条语义的机制。

**mmap 两模式**（来源 3 官方定义，逐字级可靠）：

| | MAP_SHARED | MAP_PRIVATE |
|---|---|---|
| 他进程可见性 | 映射同一文件的进程**互相可见** | **不可见**（私有 CoW 映射，man 原文 "Create a private copy-on-write mapping"） |
| 回写文件 | 是（精确控制需 `msync`） | 否 |
| 典型用途 | 进程间共享内存、mmap 文件协作 | 加载程序的私有副本、大 malloc |

NOTES 补充：**mmap 的内存跨 fork 保留、属性不变**——MAP_SHARED 映射父子继续共享，MAP_PRIVATE 则进入 CoW 故事。三者组合（fork + CoW + mmap）即可严谨说明「shell 管道里 mmap 一块缓冲区被两个进程用」的全部行为（来源 2/3/4 三角互证）。

> 常见误区：「MAP_PRIVATE 修改会写回文件」。恰恰不会——写时只复制到私有页；要让改动落地请用 MAP_SHARED + msync/fsync（fsync 语义第 8 章再深化）。

## ⑤ 动手练习（统一工程 hello-os）

在 `chapter/05-paging-tlb` 分支：

1. **手算对拍**：`paging-linear-translate.py` 生成 5 个随机地址翻译题，先手算 VPN/PPN/offset 拆分再 `-c` 核对，记录一题完整过程于 README。
2. **多级 + TLB 验证点主体**：`paging-multilevel-translate.py` 按 README 给定参数跑一段访问序列：**先手算 TLB 命中率，再与模拟器输出对拍**（章末验证点之一）；把 `-s` 种子与 `-n/-k/-p` 参数抄进 README。
3. **置换策略对比**：`paging-policy.py -a LRU/CLOCK/FIFO` 对同一种子比较页错误数，README 一句话结论（哪种在你这组序列最优）。
4. **CoW 计数 demo**：`src/cow_demo.c`——父进程 `mmap(NULL, 3*4096, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANONYMOUS, -1, 0)` 写入模式 A；`fork()`；子进程写其中一页；用 `/proc/<pid>/smaps` 的 `Private_Dirty/Rss` 字段（grep 页号区间）证明「未写的两页仍共享、写过的页私有化」，把计数变化记 README（章末验证点之二）。
5. **真机翻译实验**（可选加分）：跑 `mem.c`（需 sudo），观察同一虚拟地址在 fork 前后物理地址是否相同——印证 CoW。

**章末验证点**：TLB 命中率「手算=模拟器」一致；CoW demo 的 smaps 计数表完整。通过后合并回 `main`。

## ⑥ 本章小结

1. 分页以等大小页终结外部碎片：$va = VPN \times P + offset$，页表=VPN→PPN 查找表，PTE 携有效位/保护位——第 4 章段内粒度在此解决（5.1）。
2. 一次翻译三档结局：TLB 命中/页表命中/缺页；TLB 是稀缺缓存，大页是其解药（5.2）。
3. 多级页表把稀疏性变现为空间；x86-64 四级 PGD/PUD/PMD/PTE、9+9+9+12 位切分、CR3 指向顶层——第 2 章「切换地址翻译指针」的实身在 (补充) 图示节（5.3）。
4. 反置页表一瞥：每物理帧一项，翻转开销结构（5.4）。
5. 局部性撑住超配，OPT/LRU/Clock/Working Set 是「谁被踢」的策略谱系；页错误率与 $T_{fault}$ 主导性能（5.5）。
6. swap/thrashing 引出 Swapper 与 Linux 的 reclaim/OOM 对照；脏页先写回、净页直接丢（5.6）。
7. **CoW 清偿全账**：fork 只复制页表并设只读，写时缺页才复制；mmap 的 MAP_SHARED（共享且回写）与 MAP_PRIVATE（私有 CoW 不回写）+「mmap 跨 fork 保留」三角互证（5.7）。
8. 本章欠账：磁盘机理（swap 为什么贵、$T_{disk}$ 的构成）——第 8 章。

## ⑦ 参考来源

1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html
2. Linux MM Concepts overview（kernel docs） — https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html
3. mmap(2) — Linux manual page — https://man7.org/linux/man-pages/man2/mmap.2.html
4. fork(2) — Linux manual page — https://man7.org/linux/man-pages/man2/fork.2.html
5. MIT 6.1810 Labs（tools.html 导航） — https://pdos.csail.mit.edu/6.828/2023/tools.html
