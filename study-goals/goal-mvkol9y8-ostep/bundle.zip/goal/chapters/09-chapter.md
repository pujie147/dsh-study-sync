# 第 9 章 合拢与展望：三大件在一个真实内核里 + 虚拟机与安全概览

## ② 本章概览（总）

### 本章在全课程框架中的位置

收官章。前八章把「机制+策略 × 三大资源」的框架逐块建齐；本章做三件事：**① 把框架合拢**——在 xv6 这个两万行级真实内核源码里，认出前面每一章的抽象对应的具体代码；**② 扩两扇窗**——虚拟机（把「虚拟化」再抬一层：整台机器）与安全（把「保护」再推一步：防的不只是 bug 还有对手），均按大纲做边界级概览；**③ 指下一段路**——6.S081 labs 与 ostep-projects 的进阶清单。本章不引入新的深机制，全部是已讲概念的再认与串联。

### 本章抽象框架

```mermaid
flowchart TB
    subgraph XV6["xv6 内核 一个可通读的真实系统"]
        TRAPV["trap.c 向量入口"] --- PROCC["proc.c 进程"]
        PROCC --- VMC["vm.c 页表"]
        VMC --- SPIN["spinlock.c kthread.c 锁"]
        SPIN --- FS_C["fs.c log.c 文件系统"]
    end
    C2["第2章 机制"] --> TRAPV
    C3["第3章 策略"] --> PROCC
    C5["第4-5章 内存"] --> VMC
    C7["第6-7章 并发"] --> SPIN
    C8["第8章 持久化"] --> FS_C
```

一句话说明：五个文件对应五章——「教科书抽象 vs 真系统」的距离，就是这张图的箭头：每一处都能在源码里找到行号级实身。

### 分节地图

- 9.1 xv6 是什么、为什么选它（环境搭建两条路径）
- 9.2 五处关键代码定位法（trap 向量 → proc.c → vm.c → spinlock → fs.c）
- 9.3 收官串讲：一次 fork 如何同时穿过三大件
- 9.4 虚拟机概览：VMM 两型与硬件辅助（一句话认知级）
- 9.5 安全三支柱概览：认证、访问控制、加密（边界级）
- 9.6 全课程复盘总图 + 进阶路线（6.S081 labs / ostep-projects 选做清单）

### 本章欠账声明（黑盒）

- 无新增黑盒；全课程所有先前黑盒均已在各自章节清偿。

## ③ 承接与补完

- **承接**：本章每一节都在回收前章——9.2 的每个定位点对应一章的机制名词；9.3 的 fork 串讲集齐第 2 章（fork/wait）、第 5 章（CoW 页表）、第 8 章（文件表引用计数）三件已讲知识。大纲缺口「xv6 环境摩擦」由 9.1 的两条官方路径清偿。
- **本章分支动线**：

  ```bash
  git checkout main && git checkout -b chapter/09-xv6-capstone
  ```

  注意：xv6 本体是**外部仓库**（另 clone，不并入 hello-os）；hello-os 侧只交付 `xv6-notes/README.md`（五处定位 + 跟踪日志）。这是统一工程的最后增量。
- **章末验证点**：在 xv6 中完成 initial-xv6 跟踪任务、notes 齐备；合并回 main 后打 tag `course-complete`（见⑤⑥）。

## ④ 正文

### 9.1 xv6 是什么，环境怎么搭

**结论先行：xv6 是 MIT 为教学写的简单类 Unix 内核——受 Unix V6 与 Lions Commentary 启发，ANSI C 实现在多核 RISC-V 上，源码与讲解书互为超链接。它是市面上唯一「一个人能通读完」的现代教学内核。**（来源 1。）

获取与搭建（来源 3，官方文档逐字级可靠）：

```bash
git clone https://github.com/mit-pdos/xv6-riscv.git
git clone https://github.com/mit-pdos/xv6-riscv-book.git   # 配套书
```

**路径 A · Linux/WSL2（推荐主线）**：Ubuntu/Debian 一行装齐（与第 1 章 env_baseline 同一命令——当初「一举两得」在此兑现）：

```bash
sudo apt-get install git build-essential gdb-multiarch qemu-system-misc \
     gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu
```

自检：`qemu-system-riscv64 --version`（需 ≥5.1）与 `riscv64-linux-gnu-gcc --version`（来源 3）。Windows 学生官方姿势：**WSL2 + Ubuntu**（务必 `wsl -l -v` 确认 v2；PowerShell 换 Windows Terminal）（来源 3）。进 xv6 目录 `make qemu` 即启动。

**路径 B · 虚拟机/macOS**：跑不动原生工具链的机器 → VirtualBox/VMware 装 Linux VM 再走路径 A；macOS = xcode-select + Homebrew riscv-tools + qemu（来源 3）。

(补充) 大纲提及的 Docker 路线：存在社区维护的 xv6-riscv 开发镜像，但本次资料未核验到稳定官方仓库页——按第 9 章资料缺口处理，不列为课程主线，如需请自行验证镜像维护状态。

### 9.2 五处关键代码定位法

**结论先行：不要通读 xv6，用「从第 N 章的概念反查文件」的方法读它——每章欠一个「真身」，本章分五次还。**

资料缺口清偿要点：行号随 commit 漂移，**课程要求掌握的是定位手法**：`grep -n '函数名' *.c *.h` + 配套书对应章的超链接。下表给出「目标符号」（来源 2 书章 ↔ 源码文件对照）：

| # | 概念（来自章） | xv6 文件 | 找什么符号（grep 目标） | 对应 xv6 book 章（来源 2） |
|---|---|---|---|---|
| 1 | trap 大道（第 2 章）；中断/异常/syscall 三扇门（第 8 章） | `kernel/trap.c` | `trap()` 主循环、`uservec`/`kernelvec` 汇编保存现场 | Ch.4 Traps and system calls |
| 2 | PCB、状态机（第 2 章）、调度（第 3 章） | `kernel/proc.c` `proc.h` | `struct proc`（看 kstack、state、sz、oftable 字段）、`sched()` 与 `growproc()`/`fork` 协作 | Ch.2/8 |
| 3 | 页表、TLB、切换（第 4–5 章） | `kernel/vm.c` `vm.h` | `uvmalloc()`、`freewalk`、`wmap`；进程切换时 satp（RISC-V 的 CR3）读写 | Ch.3 Page tables |
| 4 | 自旋锁/休眠锁（第 6–7 章） | `kernel/spinlock.c` `kthread.c` `sleeplock.c` | `acquire()`（关中断+原子测试——6.5 金字塔的实身）、`sleep()/wakeup()`（7.1 condvar 的内核原语） | Ch.7 Locking / Ch.9 Sleep and Wakeup |
| 5 | 文件/inode/日志（第 8 章） | `kernel/fs.h` `fs.c` `log.c` | `struct dinode`（对照 inode(7) 清单）、超级块/位图读法、`log_write`+`commit`（WAL 的最小实现） | Ch.10 File system / Ch.11 Logging |

每次定位的固定动作：① 找到符号 ② 读 ±30 行 ③ 打开配套书对应章核对理解 ④ 把**函数名+一句话作用+与本课程哪节对应**写进 `xv6-notes/README.md`（这就是本章交付物骨架）。

### 9.3 收官串讲：一次 fork 的三段旅程

**结论先行：`fork()` 一次系统调用，恰好把三大件在同一条代码路径上各用一遍——这是全课程最好的复盘题。**

```mermaid
sequenceDiagram
    participant U as 用户进程A
    participant K as xv6 内核 trap 门
    U->>K: ecall SYS_fork
    K->>K: 第一段 CPU件 复制 proc 结构 PCB 状态新建 父进程走 sched 排队
    K->>K: 第二段 内存件 uvmcopy 复制页表 双方 PTE 置只读 CoW 见第5章
    K->>K: 第三段 持久化件 遍历文件表 dup 计数加一 见第8章 OFT 共享
    K-->>U: 父得 child pid 子得 0
```

一句话说明：xv6 源码里三段依次是 `proc.c: fork`（新建 proc）、`vm.c: uvmcopy`（逐页查 PTE、加引用计数、清写位）、`proc.c: filedup`（fd 表逐项复制——父子**共享同一 open file description/文件表项**，偏移共享，正是第 2/8 章那条「fork 继承 fd 副本」的内核实现）。三个第 X 章的概念在同 80 行里同框——「教科书抽象 vs 真系统」的距离感在此归零。

**观察练习衔接**：⑤的跟踪任务让这三段在你屏幕上打出名字。

### 9.4 虚拟机概览：VMM 两型与硬件辅助

**结论先行：虚拟机监控器（VMM/hypervisor）把「虚拟化」从进程抬到整台机器：Type-1 裸机直跑（VMware ESXi、KVM 模式、Xen），Type-2 寄生在宿主 OS 之上（VirtualBox、VMware Workstation）；现代硬件用 VT-x/AMD-V 特权模式让「客户机内核态」不再需要二进制翻译才安全。**（依书附录 vmm-intro.pdf 口径；(补充) 资料缺口注明 Type-1/2 与硬件辅助无独立一手网页源被核验——本节一句话认知级，不展开机制，更深的「翻译 vs 经典 VMM 两形态」细节见书附录。）

- 教学定位：VMM 与本课程三层框架同构——它也有控制层（VM exit 门，trap 道的再嵌套）、服务层（调度虚拟 CPU）、数据层（影子页表/EPT，第 5 章页表的再升维）。
- 一句边界：OS 虚拟化「一个机器上的多个程序」；VMM 虚拟化「一台机器上的多个 OS」。其余全是同题（调度、内存、I/O）的递归。

### 9.5 安全三支柱概览（边界级）

**结论先行：OSTEP v1.10 新增 Peter Reiher（UCLA）的五章安全（Ch.52–57：总论、认证、访问控制、加密、分布式安全）（来源 5）——本课程只需在地图上认出三根柱子及其边界。**

- **认证（authentication）**：你是谁——口令的存储问题（加盐哈希、口令文件本身是攻击面，书 Ch.54 主线：*口令存储的军备竞赛*）。
- **访问控制（access control）**：你能碰什么——第 8 章的 inode mode 位（`S_IRUSR` 家族）正是最朴素的 DAC；ACL/能力表/强制访问控制是扩展谱系（书 Ch.55）。**回看第 4.3 基址限长、第 5.1 PTE 保护位：虚拟化给的保护是「互相伤害的上限」，访问控制给的是「策略化的权限」。**
- **加密（cryptography）**：数据不怕看——对称/公钥/哈希的角色，OS 用它做存储加密与传输通道（书 Ch.56）。
- 一句认知级收束：前三章把系统「做对」（机制+策略），安全章假设有人**故意做错**（对手模型）——同一套抽象、不同的失败定义。主线不展开，按边界处理；有兴趣直接读 Ch.53 总论 + 各章开头。

### 9.6 全课程复盘总图与进阶路线

**结论先行：九章全部挂回第 1 章那张「机制+策略 × 三大资源」框架——一图收课；下一段路在 6.S081 labs 与 ostep-projects。**

```mermaid
flowchart TB
    subgraph RES["三大资源 × 策略 机制"]
        direction LR
        CPU["CPU 虚拟化<br>策略章3 机制章2"]
        MEM["内存虚拟化<br>策略章5置换 机制章4翻译 章5分页TLB"]
        DISK["持久化 磁盘到文件<br>策略章8缓存日志 机制章8通路布局"]
    end
    CONC["并发 横切件 章6-7<br>线程 锁 条件变量 信号量 死锁 事件"]
    RES --- CONC
    CAP["合拢 章9<br>xv6 源码 虚拟机 安全 进阶"]
    RES --> CAP
    CONC --> CAP
```

一句话说明：第 1 章画了这张图的骨架，现在每个格子都有了章号——这就是「先总之总、每章再分」的回收。

复盘自检十问（能秒答即毕业）：① fork 返回值三分支与父子内存关系？② 定时器中断为什么是抢占的地基？③ STCF 为什么平均周转最优、为什么不可实现？④ MLF 哪四条规则、作弊怎么解？⑤ 内部/外部碎片分别怎么产生？⑥ 多级页表为什么省空间、CR3/satp 何时切换？⑦ cond_wait 为什么必须配 mutex 并用 while？⑧ 死锁四条件与最实用的破法？⑨ fd→OFT→inode 三层链里谁存偏移？⑩ journaling 把恢复从什么复杂度降到什么复杂度？

**进阶路线**（来源 4、6；(补充) 分级由本课程给出）：

| 台阶 | 内容 | 前置已备 |
|---|---|---|
| ① 主线收尾 | xv6 book 通读（13 章，Ch.12 Concurrency revisited 尤其回收第 6–7 章） | 第 9 章定位法 |
| ② 官方入门项目 | **initial-xv6**（"Intro to Kernel Hacking"，来源 4）——本章⑤任务即是它 | 第 1/2 章 |
| ③ 系统编程项目池 | processes-shell、scheduling-xv6-lottery、vm-xv6-intro、concurrency-pzip、concurrency-mapreduce、filesystems-checker…（ostep-projects 全清单，来源 4） | 各对应章 |
| ④ 硬核课程 | **MIT 6.S081/6.1810 labs**：util → syscall → pgtbl → traps → cow → lock → net → fs → mmap（来源 6 官方顺序）——与本课程章节一一对拍（pgtbl/cow=第 5 章、lock=第 6–7 章、fs=第 8 章） | 全课程 |
| ⑤ 延伸书/课 | CS-739 分布式（书 Ch.47–51 的下一步）、APUE/《Linux 内核源码剖析》类按需 | 第 9 章边界感 |

选做清单建议：③ 池里至少做完 **processes-shell + vm-xv6-intro**（覆盖 CPU/内存两件的写码闭环）再进 ④。

## ⑤ 动手练习（统一工程 hello-os + xv6）

在 `chapter/09-xv6-capstone` 分支：

1. **环境与冒烟**：按 9.1 路径 A 装齐（第 1 章 apt 命令原样复用）；clone xv6-riscv，`make qemu` 看到 `$ _` 提示符、跑 `grep` 内置小工具退出即成功。
2. **五处定位**：按 9.2 表逐一 `grep -n` 定位五个文件的目标符号，每个记三行进 `xv6-notes/README.md`：函数名 / 一句话作用 / 对应本课程章号（**章末验证点之二**）。
3. **initial-xv6 跟踪任务**：照 ostep-projects 的 initial-xv6 说明，在 syscall 路径（trap.c 的 `syscall()` 分发处）加一条打印或跟踪，**完整跟踪一次 getpid/写文件** 的调用轨迹贴进 notes（**章末验证点之一**）；体会 9.3 的三段旅程在真源码里的落点。
4. **fork 串讲验证**：在 xv6 里 `trace 83`（sys_open=83 类机制，见 util lab 文档）或用你的打印验证：子进程 fd 指向**同一 file 表项**（偏移共享，第 8 章结论在真内核复现）。
5. **收课仪式**：notes 终稿 + 「复盘自检十问」自测记录合入 hello-os 后合并回 main：

   ```bash
   git checkout main && git merge --no-ff chapter/09-xv6-capstone
   git tag course-complete
   ```

**章末验证点**：① xv6 内一次 syscall 跟踪记录；② 五处定位 notes 齐备；③ tag 已打。

## ⑥ 本章小结

1. xv6=可通读的多核 RISC-V 教学内核，源码与书互链；环境两条官方路径（Linux/WSL2 一行 apt、macOS brew），Docker 路线因未核验不列主线（9.1）。
2. 五处定位不背行号、背手法：trap.c（第 2/8 章之门）、proc.c（PCB+调度）、vm.c（页表与 satp）、spinlock/sleep（6.5 金字塔与 7.1 原语的真身）、fs.c/log.c（8.4 inode 清单与 8.6 WAL 的最小实现）（9.2）。
3. **一次 fork = 三大件同框**：复制 proc（CPU 件）→ uvmcopy 置 CoW（内存件）→ filedup 计数（持久化件）——教科书与真系统 80 行内会师（9.3）。
4. VMM 两型（Type-1 裸机 / Type-2 寄生）与 VT-x/AMD-V 一句话认知：虚拟化把「多程序」问题递归成「多 OS」问题，框架不变（9.4）。
5. 安全三柱=认证（你是谁）、访问控制（你碰什么——与 PTE 保护位/inode mode 一脉相承）、加密（数据不怕看）；主线画边界不展开（9.5）。
6. 复盘总图把九章挂回「机制+策略×三大资源+并发横切」；进阶台阶四级：xv6 book → initial-xv6 → 项目池 → 6.S081 labs（pgtbl/cow/lock/fs 与本课程章号一一对拍）。全课程黑盒清单在本章清零（9.6）。

## ⑦ 参考来源

1. MIT PDOS xv6 页（6.828/6.1810） — https://pdos.csail.mit.edu/6.828/xv6
2. xv6 book 在线目录 — https://mit-pdos.github.io/xv6-riscv-book/
3. MIT 6.1810 Tools 安装文档 — https://pdos.csail.mit.edu/6.828/2023/tools.html
4. remzi-arpacidusseau/ostep-projects（GitHub） — https://github.com/remzi-arpacidusseau/ostep-projects
5. OSTEP 官网目录页 — https://pages.cs.wisc.edu/~remzi/OSTEP/
6. MIT 6.1810 Labs 列表（tools.html 同页导航） — https://pdos.csail.mit.edu/6.828/2023/tools.html
