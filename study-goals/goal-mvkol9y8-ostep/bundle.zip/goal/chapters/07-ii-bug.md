# 第 7 章 并发 II：条件变量、信号量、死锁与并发 Bug

## ② 本章概览（总）

### 本章在全课程框架中的位置

并发件的下半场——**协作与灾难的两面**。第 6 章末尾留下的「等条件成立」语义缺口（dequeue 遇空队列）由**条件变量**补齐；**信号量**给出更小巧的计数原语；然后直面并发最阴险的失败模式——**死锁**，以及它的诊断框架（四条件）与三条对策；最后以「竞态/死锁/活锁」收束并发 debug 心法，并一瞥事件驱动这个「线程之外」的路线。框架归属：服务层（同步原语）+ 数据层（等待队列）。对应 OSTEP Ch.30–33。

### 本章抽象框架

```mermaid
flowchart TB
    CV["条件变量<br>等一个谓词成立"] --- SEM["信号量<br>数着资源等"]
    CV --> PC["协作经典题<br>生产者 消费者"]
    SEM --> PC
    PC --> BAD["灾难面 死锁 deadlock<br>人人持有等待 无人前进"]
    BAD --> CURE["对策三选<br>检测 预防 破环"]
    CURE --> ALT["换条路 事件驱动<br>单线程状态机"]
```

一句话说明：上半区的两个原语让线程可以「安全地等」；下半区回答「等出来的死局」如何识别与拆解——协作与灾难本是同一枚硬币。

### 分节地图

- 7.1 条件变量：mutex+cond 配对的完整语义
- 7.2 丢唤醒、虚假唤醒与 while 检查；signal 还是 broadcast
- 7.3 信号量：互斥型与计数同步型
- 7.4 经典题双解：生产者-消费者（condvar 版 vs 信号量版）
- 7.5 死锁：四条件、哲学家就餐与三条对策
- 7.6 并发 bug 谱系与调试心法
- 7.7 事件驱动并发：线程之外的另一条路

### 本章欠账声明（黑盒）

- 无新增黑盒（monitor 原语按书末附录处理，主线不展开；磁盘相关引用于第 8 章自带框架）

## ③ 承接与补完

- **承接**：第 6 章条件变量黑盒（6.6）在此打开；6.5 的「BLOCK 状态+等待队列」正是 wait 挂起的内核化身；6.6 埋的「两把锁顺序不一致」种子在 7.5 理论化；第 2 章的状态机（READY/RUNNING/EXITED）经 6.5 补 BLOCK，本章再补「唤醒回 READY」的闭环；第 3 章「前进/有限等待」判据直接用于诊断死锁违反的是哪条。
- **本章分支动线**：

  ```bash
  git checkout main && git checkout -b chapter/07-concurrency-cv-sema
  ```

- **前置章标注回改**：第 6 章 CV 黑盒已追加「已在第 7 章讲清」。
- **章末验证点**：condvar 版与信号量版生产者-消费者输出一致且 stress 通过；可复现死锁 demo 修复后归零（见⑤）。达成后合并回 `main`。

## ④ 正文

### 7.1 条件变量：mutex + cond 配对的完整语义

**结论先行：条件变量 = 「因某谓词不成立而挂起、待他人通知后醒来复查」的等待队列；它必须与 mutex 配对使用——这不是风格问题，而是正确性问题。**

规范定义（来源 1，pthread_cond man 页转述）：条件变量让线程**暂停执行、让出处理器，直到共享数据上的某个谓词成立**。两个基本操作：`wait`（等条件）与 `signal/broadcast`（报条件可能成立）。

**为什么必须配 mutex（丢唤醒竞态）**——man 页原文给出权威理由：*「条件变量必须始终关联一个 mutex，以避免一个线程准备进入等待、而另一个线程恰在它真正等待之前发信号的竞态」*。拆成时序看：

```mermaid
sequenceDiagram
    participant W as 消费者
    participant M as mutex
    participant P as 生产者
    W->>M: lock 检查谓词 队列空
    Note over W,P: 危险窗口 若此刻无锁屏障
    P->>M: lock 投件 发 signal
    M-->>P: 无人等待 signal 落空
    W->>W: 才真正进入 wait 睡到地老天荒
```

带 mutex 的解法：`pthread_cond_wait(&cond, &mut)` **原子地**执行「解锁 mutex + 挂起到 cond 队列」，被唤醒返回前**重新拿锁**。因为生产者发 signal 也须持同一 mutex，「检查谓词 → 进入等待」这段就处于锁的保护下——signal 要么发生在消费者持锁期间（消费者回头自己会看见条件），要么发生在其挂起之后（唤醒有效），**中间窗口不存在**（来源 1）。

### 7.2 丢唤醒、虚假唤醒与 while 检查；signal vs broadcast

**结论先行：wait 返回 ≠ 谓词成立，只 = 「有人动过条件，值得再看一眼」。所以检查必须用 while 而不是 if——man page 的官方示例即是此写法。**

规范示例（来源 1 EXAMPLE 节原文骨架）：

```c
pthread_mutex_lock(&mut);
while (x <= y) {                 /* 谓词 用 while 不用 if */
        pthread_cond_wait(&cond, &mut);
}
/* 此刻才可安全操作 x y */
pthread_mutex_unlock(&mut);

/* 修改 x y 的一方 */
pthread_mutex_lock(&mut);
/* ...modify x and y... */
if (x > y) pthread_cond_broadcast(&cond);
pthread_mutex_unlock(&mut);
```

三类「醒来但不是给你的」场景：

1. **虚假唤醒（spurious wakeup）**：POSIX 允许 wait 无信号也返回；
2. **信号被共享**：broadcast 唤醒 N 个，可能只够 1 个的份；
3. **插队**：醒来重拿锁之间，第三个线程可能已把资源消费光（Mesa 风格语义的常态）。

`while` 循环把三类统统防住——醒来看谓词，不成立就再睡。

**signal 还是 broadcast**（来源 1 官方准则）：`signal` 恰好唤醒**一个不确定是谁**的等待者；`broadcast` 唤醒全部。准则原文：**能证明至多只需唤醒一个等待者才用 signal（更高效），拿不准就用 broadcast**。用 signal 唤醒错人（叫醒了等 A 条件、但 B 条件成立时）会造成整队人「无人前进」的**广播丢失**——这也是主线代码建议「一个 condvar 只配一个谓词、每类谓词各一个 cond」的原因。(补充) 后半段工程准则依书 Ch.30 叙述。

**Mesa/Hoare 一瞥**（旁注级，(补充)；资料缺口注明无一手网络源）：Hoare 语义「直接把手递给被唤醒者」与 Mesa「被唤醒者回队重抢」的历史差异，落到工程上殊途同归——**POSIX 是 Mesa 风格，所以 while 检查是强制纪律**。timedwait 的 `ETIMEDOUT` 用法（来源 1 示例）留作「带截止期的等待」工具。

### 7.3 信号量：一个计数器加两个原子操作

**结论先行：semaphore = 一个非负计数器 + `sem_wait`（P：减一，为零则挂起）+ `sem_post`（V：加一，唤醒一个等待者）。比 condvar 小巧，能直接编码「资源有几个」。**

规范（来源 2，sem_init man 页转述）：`sem_init(&sem, pshared, value)`——`value` 即资源初值；`pshared=0` 同进程线程间用（放全局/堆），非 0 放共享内存跨进程使用（fork 子进程亦可访问，呼应第 2 章）。`sem_wait` 阻塞直至计数器 >0 再减一；`sem_post` 总成功、加一并唤醒等待者。

两类用法（依书 Ch.31 骨架）：

| 用法 | value 初值 | 语义 | 例 |
|---|---|---|---|
| **二进制信号量（互斥型）** | 1 | 当锁用，P/V 成对夹临界区 | 保护共享变量 |
| **计数信号量（同步型）** | N | 「资源件数」计数器，P 拿资源 V 还资源 | barrier（到 N 才放行）、限流 |

信号量与 condvar 的分工：condvar 配谓词、更贴近「等待条件」；semaphore 配计数、更贴近「等待资源」，且**自带计数记忆**（post 先行不会丢——这点比 signal 健壮）。但 semaphore 不绑定 mutex：**P 完进临界区、V 前出临界区的纪律全靠自觉**——忘 V 即饿死全场，是 semaphore 版经典事故。(补充) 分工评价依书 Ch.31。

barrier 一行实现（依书 Ch.31 例）：`sem_wait(&s)` 后 `if (atomic_fetch... )`…教学标准形：

```c
/* 每线程: sem_wait 前先自报到计数; 最后报到者广播 */
int n = atomic_fetch_add(&arrived, 1);
if (n < total-1) for (;;) sem_wait(&go); /* 等待放行 */
else            for (int i=0;i<total-1;i++) sem_post(&go);
```

(补充) barrier 代码为示意级（书 Ch.31 有完整逐行版），本章工程不考 barrier。

### 7.4 经典题双解：生产者-消费者

**结论先行：同一道题，condvar 版显式写谓词、signal 精确通知；信号量版用两个计数器 full/empty 隐式编码状态——理解「显式等待条件 vs 计数等待」的对照就理解了两种原语的哲学差。**

**condvar 版**（7.1–7.2 规范骨架 + 第 6 章 tqueue）：

```c
/* producer */
lock(&m); enqueue(item);
if (was_empty) signal(&nonempty);
unlock(&m);

/* consumer */
lock(&m);
while (queue_empty()) cond_wait(&nonempty, &m);  /* 谓词 空? 睡眠 */
item = dequeue(); unlock(&m);
```

**信号量版**：

```c
sem_t empty;  /* 初值 = 缓冲区容量或无界时不配 */
sem_t full;   /* 初值 = 0 */
sem_t mutex;  /* 初值 = 1 保护队列本身 */

/* producer */
sem_wait(&empty); sem_wait(&mutex);
enqueue(item);
sem_post(&mutex); sem_post(&full);

/* consumer */
sem_wait(&full); sem_wait(&mutex);
item = dequeue();
sem_post(&mutex); sem_post(&full->empty 笔误修正见下注);
```

注：consumer 应为 `sem_wait(&full); ... sem_post(&empty);`——上面最后一行是刻意保留的「常见抄写错误」提醒，实际代码以⑤练习为准。(补充) 双解代码为教学示意，书 Ch.30/31 各有逐行版；P 顺序 empty→mutex、V 顺序 mutex→full 的**先后纪律**（先拿资源计数、再进临界区；先出临界区、还资源放最后）值得在练习里故意违反一次观察死锁。

### 7.5 死锁：四条件、哲学家就餐与三条对策

**结论先行：死锁=每个参与者都持有对方需要的资源、又都在等——互斥、持有并等待、不可剥夺、循环等待四条件同时成立之时。破任一条即解。**

- **可复现现场**（来源 3/4：HW-Threads-RealDeadlock 的 `vector-*.c` 系列）：两个全局数组各配一把锁；线程 1 按 A→B 顺序拿锁、线程 2 按 B→A——交错时互相持有对方等待的锁，**双双 BLOCK 且永不唤醒**。这正是第 6 章三要求里「前进」的彻底破产。
- **Coffman 四条件**（(补充) 教材通识，依书 Ch.32 叙述；资料缺口已注明本次无独立一手网页源）：互斥、持有并等待（hold and wait）、不可剥夺（no preemption）、循环等待（circular wait）。四者**同时**成立才可能死锁。
- **三条对策**（依书 Ch.32，与四条件一一对偶）：

| 对策 | 破坏的条件 | 手段 | 代表 |
|---|---|---|---|
| **检测+恢复** | （不破坏，允许发生） | 资源分配图找环；或超时 abort；从死锁点重启/回滚 | 数据库死锁检测器 |
| **预防** | 破「持有并等待」或「循环等待」 | 一次性申请全部资源；**全局锁序**（按地址序拿锁） | 书 Ch.32 方案一/二 |
| **避免** | 破进入死锁状态的路线 | 分配前预判「给了你会不会进不安全区」 | 银行家算法（课外科普级） |

  **哲学家就餐**（依书 Ch.32 例）：N 人围桌、N 支筷、每人需左右两支——「对称 + 各自拿一支」是教科书级死锁；书给的标准解即**锁序/编号规则**（先拿小编号再大编号，掐断循环等待）或「只允许 N-1 人同桌」（掐断持有并等待）。
- 工程首选：**全局锁排序**——便宜、静态可审；配合「锁图检测（lock ordering violation check）」在开发期报警。(补充) 评价依书 Ch.32 结尾建议。

### 7.6 并发 bug 谱系与调试心法

**结论先行：并发失败不止竞态与死锁——把谱系画全，配上第 6 章的方法论，就是完整的并发 debug 工具箱。**

| 病症 | 特征 | 诊断抓手 |
|---|---|---|
| 竞态（race） | 结果偶尔错（6.2） | 控制交错（x86.py）、stress、谓词断言 |
| 死锁（deadlock） | 卡死不前进 | 锁序审查、`gdb thread apply all bt` 看谁在等哪把锁 |
| 活锁（livelock） | 忙但不动（反复谦让重试） | CPU 占用高而状态不变；退避随机化 |
| 饥饿（starvation） | 个别线程长期不满足 | 有限等待检查、公平调度（回看第 3 章） |
| 丢唤醒/虚假唤醒 | 偶发永久睡眠 | while 谓词检查纪律（7.2） |

心法三句（回收第 6 章）：**先画时序再写代码；先定谓词再选原语；先排锁序再上并发。** 工具层：`Helgrind/ThreadSanitizer` 类动态检测器可自动报锁序与数据竞争（(补充) 工具名通识，资料未核验版本行为，用前 `man`/官网为准）。

### 7.7 事件驱动并发：线程之外的另一条路

**结论先行：另一条避免共享内存撕裂的路——根本不建多线程：单线程事件循环 + 状态机，事件来了再动。**

- 模型：一个 `while(true){ event = get(); handle(event); }`；所有「等待」登记为回调/状态位（依书 Ch.33）。
- 优势：**无锁、无竞态、无死锁**——因为不存在并行执行流；天然适合 I/O 密集与高连接数服务器（第 8 章的异步 I/O 与之衔接）。
- 代价：单个 handler 必须**短**（阻塞即全栈冻结，「一个慢查询冻住全站」的事故原型）；CPU 密集任务无能为力；回调/状态机写复杂业务很折磨人（"callback hell"）。
- 定位：与「多核并行」互补而非替代——I/O 等待多、计算少选事件驱动；计算并行选线程/进程+锁。
- 实验：HW-Threads-RealEvents / 书 Ch.33 作业即把一个线程版程序改写成事件驱动版（来源 3/4），⑤练习 4 对应。

> monitor 原语（书末附录 threads-monitors.pdf）：「把锁+条件+临界方法打包进对象」的语言级封装——Java `synchronized` 即其家族。按大纲为主线略讲，不展开。

## ⑤ 动手练习（统一工程 hello-os）

在 `chapter/07-concurrency-cv-sema` 分支（复用第 6 章 `src/tqueue.[ch]`）：

1. **condvar 版正式化**：把第 6 章 dequeue 的「空队列 sleep 轮询」换成 `pthread_cond_wait + while` 谓词版；生产者投 1000 件、两消费者取件，验证守恒。
2. **信号量版双实现**：`src/pc_sema.c`——empty/full/mutex 三信号量版，**注意 7.4 的 P/V 顺序纪律**。
3. **双实现对照（章末验证点）**：同一任务流分别跑两版各 $10^3$ 轮：输出序列一致、无死锁、CPU 时间对比记 README。
4. **可复现死锁 + 修复**：`src/deadlock.c`——按 `vector-*.c` 思路做 A→B / B→A 双锁序线程；加 `sem_timedwait` 式超时探针或 `gdb bt` 取证确认死锁；再按**全局锁序**修复，stress 归零。
5. **故意违反一次**：在 pc_sema 版里交换 P 顺序（mutex→empty），观察是否死锁并解释（7.4 的纪律题）。
6. **事件改写（可选）**：把一个「多线程轮流打印」小例改写为单线程状态机版，体会 handler 不能阻塞的约束。

**章末验证点**：两版生产者-消费者输出一致 + stress $10^3$ 轮全绿；死锁 demo 复现记录与修复记录齐备。通过后合并回 `main`。

## ⑥ 本章小结

1. 条件变量=谓词等待队列；**与 mutex 配对不是风格而是正确性**——man 页的丢唤醒竞态论证 + wait 的「原子解锁+挂起、返回前重拿锁」语义（7.1）。
2. wait 返回只是提示：虚假唤醒/广播共享/插队三类场景 ⇒ **while 谓词检查**；signal 唤醒一人且不确定是谁、**拿不准就 broadcast**（7.2；Mesa/Hoare 仅旁注）。
3. 信号量=计数+P/V，**自带计数记忆**；二进制当锁、计数做同步（barrier/限流）；初值与 V 纪律是它的命门（7.3）。
4. 生产者-消费者双解对照：condvar 显式谓词 vs 信号量隐式计数；P/V 顺序（先资源后互斥、先出锁后还资源）必须成为肌肉记忆（7.4）。
5. 死锁四条件（互斥/持有并等待/不可剥夺/循环等待）同时成立是前提；对策=检测恢复、预防（**全局锁序最实用**）、避免；哲学家就餐是四条件的标本（7.5）。
6. bug 谱系竞态→死锁→活锁→饥饿→丢唤醒，各配诊断抓手；心法三句收束第 6–7 章方法论（7.6）。
7. 事件驱动=不建并行流的第三条路：无锁即无敌，但 handler 必须短、CPU 密集无解——与线程并行互补（7.7）。
8. 本章无新增黑盒；monitor/语言级封装按附录与略讲处理。

## ⑦ 参考来源

1. pthread_cond_init(3)/pthread_cond_wait — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man3/pthread_cond_wait.3.html
2. sem_init(3) — Linux manual page — https://man7.org/linux/man-pages/man3/sem_init.3.html
3. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html
4. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework
5. xv6 book Ch.7 Locking / Ch.9 Sleep and Wakeup（目录页） — https://mit-pdos.github.io/xv6-riscv-book/
