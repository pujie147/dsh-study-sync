# 第 8 章 持久化：磁盘、RAID 与文件系统

## 来源清单
1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 本章模拟器权威入口：disk.py（Ch.37）、raid.py（Ch.38）、vsfs.py（Ch.40 FS 实现）、ffs.py（Ch.41）、fsck.py（Ch.42 journaling/checker）、lfs.py（Ch.43）、ssd.py（Ch.44）、checksum.py（Ch.45）— 访问 2026-08-09
2. open(2) — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man2/open.2.html — 文件 API 规范：fd 是进程 fd 表索引、**open file description（系统级打开表项，含 offset 与状态标志）**、O_SYNC/O_DSYNC/O_APPEND 原子性、fork 继承共享 offset — 访问 2026-08-09
3. fsync(2)/fdatasync — Linux manual page — https://man7.org/linux/man-pages/man2/fsync.2.html — 崩溃一致性的用户侧入口：fsync 刷数据+元数据并等设备确认；**fsync 不保证目录项落盘（需对目录再 fsync）**；fdatasync 只刷检索所需元数据 — 访问 2026-08-09
4. inode(7) — Linux manual page — https://man7.org/linux/man-pages/man7/inode.7.html — inode 元数据全清单（ino/nlink/uid/mode/size/blocks/atime-mtime-ctime），「同一 inode 可被多个目录项引用」的硬链接语义基础 — 访问 2026-08-09
5. getdents(2) — Linux manual page — https://man7.org/linux/man-pages/man2/getdents.2.html — 目录即「dirent 序列（d_ino+d_name+d_type）」的一手结构定义，附完整解析示例程序——mini-fs 列目录练习的直接参照 — 访问 2026-08-09
6. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework — 上述全部模拟器所在官方仓库 — 访问 2026-08-09

## 摘录与要点
- （来源 2）「open/read/write/fsync 背后发生了什么」的规范答案：**每次 open 创建一个新的 open file description**（内核全局打开文件表项，POSIX 术语，俗称 struct file）；fd 只是本进程表中指向它的索引；dup/fork 产生的 fd **共享同一 open file description，因而共享文件偏移**；两次独立 open 则各有 offset。O_APPEND 下「定位到末尾+写」是单一原子步骤；O_SYNC 使每次 write 如同后跟 fsync。这些正是书 Ch.39 文件抽象层作业（main-file-share.c 等）考查的点。
- （来源 3）fsync 细节可核点：把修改过的 buffer cache 页刷到持久设备并**穿过/刷新磁盘缓存**、阻塞至设备确认；还刷与该文件关联的元数据；但**目录项不随之落盘**——讲义讲 WAL/崩溃一致性时可举此例说明「为什么 rename 后还要 fsync 父目录」。EIO 报告策略（Linux 4.13 起写回错误报给所有可能写过该数据的 fd）体现真实系统的复杂性。
- （来源 4）inode 字段清单直接支撑 FFS 讲解：st_blocks 以 512B 计且**可小于 size/512（空洞文件 sparse）**——extent/间接块节省空间的动机实例；atime/mtime/ctime 的触发事件列表完整；S_IFMT 掩码与 S_ISREG 等宏给出「文件类型存于 inode mode 字段」的实现事实。
- （来源 5）目录的内核表示：linux_dirent{d_ino, d_off, d_reclen, d_name[, d_type]}，getdents 一次批量读多条；示例程序在 ext2 目录上打印 inode 号表——让学习者明白「目录 = inode 号→名字的映射」，与书 Ch.39/40 模型同构，mini-fs 练习可仿其解析逻辑。
- （来源 1）模拟器分工建议：disk.py 练寻道时间计算（$T \approx T_{seek}+T_{rot}+T_{transfer}$ 的量化实验与 CLOOK 调度）；raid.py 逐条验证 RAID4/5 条带+奇偶校验的重建；ffs.py 手算块组分配是否「就近」；fsck.py 给损坏镜像做一致性检查（对应本章工程验证点）；ssd.py 演示 FTL 写放大。README 均在仓库内。
- RAID 级别 0/1/4/5/6 的吞吐/容错权衡本次另检索到中文图解长文（腾讯云社区、知乎），但抓取未成功核验正文，故不列入清单；依书 Ch.38 + raid.py 实验即可覆盖。

## 本章仍缺的缺口
- ext4/XFS 真实 on-disk 结构（journal2、HTree 目录索引等）比 FFS 教学模型复杂：本次未核验到可引用的结构化权威网页（Ubuntu help 页 404），讲义按大纲以「概念映射」处理并注明。
- SSD FTL 与写放大的深入材料未找到一手可靠源（厂商白皮书类），依书 Ch.44 叙述为限。
- NFS/AFS 分布式文件系统按大纲列为选读延伸，本次未检索（不入主线考核）。
