# 第 4 章 内存虚拟化 I：地址空间与连续分配

## 来源清单
1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 本章三个模拟器权威入口：relocation.py（Ch.15 地址翻译）、segmentation.py（Ch.16）、freespace.py（Ch.17 空闲空间）；VM Intro/API 为写代码型 — 访问 2026-08-09
2. malloc(3)/free(3) — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man3/malloc.3.html — malloc/free/calloc/realloc 用户侧 API 权威规范，含 glibc 内部用 brk/mmap、MMAP_THRESHOLD 128KB、arena 机制等内核侧线索 — 访问 2026-08-09
3. brk(2)/sbrk — Linux manual page — https://man7.org/linux/man-pages/man2/brk.2.html — program break 即「堆顶」的一手定义：移动 break = 扩缩数据段；malloc 默认经 sbrk 调整堆 — 访问 2026-08-09
4. mmap(2) — Linux manual page — https://man7.org/linux/man-pages/man2/mmap.2.html — 匿名映射（MAP_ANONYMOUS）与大块分配路径；页对齐要求；fork 后映射保留——heap/stack/mmap 三区域直觉的官方出处 — 访问 2026-08-09
5. Linux MM Concepts overview（kernel docs） — https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html — 「Virtual Memory Primer」小节：虚拟地址抽象动机、层级页表组织、高层索引+低位偏移的翻译描述——与书 Ch.13–15 同构 — 访问 2026-08-09

## 摘录与要点
- （来源 2）glibc malloc 权威注记：**默认 Linux 采用乐观 overcommit**，malloc 返回非 NULL 不保证内存真可用，OOM 时进程可能被 OOM killer 杀；常规 malloc 从堆分配并用 **sbrk(2)** 调整堆大小；超过 **MMAP_THRESHOLD（默认 128KB，mallopt 可调）**的块改用**私有匿名 mmap**；多线程下以互斥锁保护分配器数据结构，检测到争用则创建额外 **allocation arenas**。这给学习者「用户侧 API vs 内核侧策略」的真实对照，正是本章 focus point 之一。realloc(p,0) 在 glibc 的坑（BUGS 节）可作课堂彩蛋。calloc 的溢出安全乘法（n*size 溢出返回错误 vs malloc(n*size) 不检测）也是好教材。
- （来源 3）program break 一手定义：break 是未初始化数据段（bss）之后的第一个位置；增大 break 即分配内存、减小即释放；`sbrk(0)` 可查询当前 break。讲义画「code / heap↑ … ↓stack」地址空间图时，heap 上界就是它。NOTES 亦告诫：避免直接用 brk/sbrk，malloc(3) 才是便携方式。
- （来源 4）mmap 关键语义可核：addr=NULL 由内核选页对齐地址；offset 必须是页大小倍数；MAP_ANONYMOUS 内容初始化为零；**mmap 的内存在 fork 后按同样属性保留**（与第 5 章 CoW 衔接）。
- （来源 5）内核文档 Virtual Memory Primer：物理内存分为 page frames；每个物理页可映射为一个或多个虚拟页；页表**层级组织**，顶层表指针在寄存器中，虚拟地址高位索引顶层表项→逐级下降→最低位是页内偏移。「为什么需要虚拟内存」三条原文（对应用抽象物理细节、按需驻留 demand paging、进程间保护与受控共享）可直接用作本章开篇动机。
- （来源 1）配套练习分工：relocation.py 模拟基址+限长寄存器翻译并注入越界错误；segmentation.py 比较固定/自由段式方案的地址空间碎片；freespace.py 比较 first/best/worst-fit 与合并/不合并策略的外部碎片率——三者覆盖大纲「内部/外部碎片量化对比」的全部实验需求。

## 本章仍缺的缺口
- 伙伴系统（buddy allocator）的内核侧文档本次未核验到合适页面（kernel docs slab.html 讲通用 slab 而非伙伴），讲义若需深入标注为延伸自读。
- 「碎片率公式」为书 Ch.16/17 正文推导，网上无独立替代源，讲义依书给出表达式并注明章节。
