# 第 7 章 并发 II：条件变量、信号量、死锁与并发 Bug

## 来源清单
1. pthread_cond_init(3)/pthread_cond_wait — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man3/pthread_cond_wait.3.html — 条件变量权威规范：必须配对 mutex 的原因（丢唤醒竞态）、cond_wait 原子解锁+挂起语义、**while 循环检查谓词的官方示例**、signal vs broadcast 选择准则 — 访问 2026-08-09
2. sem_init(3) — Linux manual page — https://man7.org/linux/man-pages/man3/sem_init.3.html — POSIX 无名信号量规范：pshared=0 线程间 / ≠0 进程间共享内存；value 初值决定互斥型(1)或计数同步型(N)——大纲「两类用法」的出处 — 访问 2026-08-09
3. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 本章作业入口：Ch.30 CVs 用 main-*.c 真实代码、Ch.31 Semaphores 写代码、Ch.32 Bugs 跑 vector-*.c 死锁实验、Ch.33 Events 写代码 — 访问 2026-08-09
4. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework — HW-Threads-RealCV / RealSemaphores / RealDeadlock 三组源码所在仓库，工程章双实现验证点直接取用 — 访问 2026-08-09
5. xv6 book Ch.7 Locking / Ch.9 Sleep and Wakeup（目录页） — https://mit-pdos.github.io/xv6-riscv-book/ — 内核版等待队列（sleep/wake up）与锁的真实实现，作「条件变量的底层机制」延伸参照 — 访问 2026-08-09

## 摘录与要点
- （来源 1）核心可核事实：**「条件变量必须始终关联一个 mutex，以避免一线程准备等待、另一线程恰在其真正进入等待前发信号的竞态」**——这就是「丢唤醒」问题的规范表述。pthread_cond_wait 原子地「解锁 mutex + 挂起等待」，返回前重新加锁；若所有线程都持锁后才发信号，则保证不会在「持锁→进入等待」窗口内丢唤醒。EXAMPLE 节给出教科书模式：`pthread_mutex_lock(&mut); while (x <= y) { pthread_cond_wait(&cond, &mut); } /* operate */ unlock` ——**while 而非 if** 正是虚假唤醒（spurious wakeup）与竞争窗口的防线，man page 原文即示范此写法。signal 只唤醒一个（不确定是谁）等待者、broadcast 唤醒全部；官方选择准则：能证明只需唤醒一个才用 signal，**拿不准就用 broadcast**。timedwait 的 ETIMEDOUT 处理示例亦完整可用。生产者-消费者两种实现均可由此骨架展开。
- （来源 2）信号量语义：sem_init(sem, pshared, value)——value 是资源计数初值；pshared=0 用于同进程线程（放全局/堆上），非 0 放共享内存跨进程使用（fork 子进程亦可访问）。配套 sem_wait/sem_post 即 P/V。对照书 Ch.31 两类用法：二进制信号量当锁（互斥），计数信号量做顺序控制（barrier、生产者-消费者的 full/empty 两个信号量）。
- （来源 3/4）死锁实验素材：HW-Threads-RealDeadlock 的 vector-*.c 系列演示两把数组锁按不同获取顺序 → 死锁可复现；修复即书 Ch.32 三条对策（检测循环等待并 abort、破坏持有并等待一次性拿全锁、全局锁排序）。Events 章作业为单线程事件循环改写（Ch.33），作「线程替代方案」的最小实践。
- （来源 5）xv6 sleep/wake up 提供比 glibc 更透明的等待队列实现（按 wchan 地址睡眠/唤醒），讲义用作「条件变量里面是什么」的黑盒打开图，属延伸不占主线。
- 死锁四必要条件（互斥、持有并等待、不可剥夺、循环等待，Coffman 条件）为教材通识，本次未核验独立一手网页源；讲义依书 Ch.32 叙述即可，不虚构引用。

## 本章仍缺的缺口
- monitor 原语与 Java synchronized/Python asyncio 对照：按大纲定位为主线略讲、学习者自取，本次未检索专门材料（书末附录 threads-monitors.pdf 存在，见官网目录）。
- Hoare vs Mesa 语义的严格定义无可靠网络一手源被核验；讲义以 man page 的工程口径（signal 不确定唤醒谁 + while 检查）为主，历史语义仅作旁注。
