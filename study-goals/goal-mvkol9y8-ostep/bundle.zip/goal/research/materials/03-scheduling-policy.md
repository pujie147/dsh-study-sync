# 第 3 章 CPU 虚拟化 II：调度策略（FIFO/SJF/MLQ/MLF/彩票/多核）

## 来源清单
1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 本章四个模拟器权威入口：scheduler.py、mlfq.py、lottery.py、multi.py（对应 Ch.7–10），tgz 直链均在页内 — 访问 2026-08-09
2. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework — 模拟器源码与 README 的官方仓库；工程章「自写 SJF/MLF 策略」即基于 scheduler.py 框架 — 访问 2026-08-09
3. CFS Scheduler — The Linux Kernel documentation — https://www.kernel.org/doc/html/latest/scheduler/sched-design-CFS.html — Linux 真实调度器 CFS 的官方设计文档（vruntime、红黑树、base_slice_ns），大纲缺口「CFS 概念对照」的一手来源 — 访问 2026-08-09
4. EEVDF Scheduler — The Linux Kernel documentation — https://www.kernel.org/doc/html/latest/scheduler/sched-eevdf.html — 内核 6.6 起取代 CFS 的 EEVDF 官方文档（lag、虚拟截止期），保证对照节不过时 — 访问 2026-08-09
5. sched_setaffinity(2) — Linux manual page — https://man7.org/linux/man-pages/man2/sched_setaffinity.2.html — 多核调度「cache 亲和」的权威描述与实测示例（同 CPU/同核/异核三组 time 对比数据） — 访问 2026-08-09

## 摘录与要点
- （来源 1/2）作业运行方式统一约定：`git clone ostep-homework`，进对应目录读 README；随机种子出题、`-c` 求解。scheduler.py 支持 `-p FIFO|SJF|STCF -i jobfile` 计算周转/响应时间——正是本章「手工计算 vs 模拟输出一致」验证点的工具。
- （来源 3）CFS 官方概述：CFS 由 Ingo Molnar 实现、合入 Linux 2.6.23，核心思想一句话——**在真实硬件上建模「理想的精确多任务 CPU」**；引入 **virtual runtime（vruntime，纳秒计）**：实际运行时间按可运行任务数归一化；总是选 vruntime 最小的任务（时间序红黑树最左节点）执行；无固定时间片概念，唯一中心可调参数 `base_slice_ns`；nice 等级与 SCHED_BATCH/SCHED_IDLE 通过权重处理；SCHED_FIFO/SCHED_RR 在 sched/rt.c 按 POSIX 实现。与 MLFQ「用启发式猜 I/O-bound」形成鲜明对照，讲义可写成「教学模型 → Linux 工程答案」的桥梁小节。
- （来源 4）EEVDF：Linux 6.6 开始转向 EEVDF（Peter Zijlstra 2023 提案，源自 1995 年论文）。给每任务算 **lag**（应得份额与实际所得之差），挑 lag≥0 中**虚拟截止期最早**者运行；短片延迟敏感任务天然占优；睡眠任务的 lag 按 VRT「衰减」防作弊（deferred dequeue）；可用 sched_setattr() 申请特定时间片。文档回链 CFS 页（来源 3）。
- （来源 5）亲和性权威定义：线程的 CPU affinity mask 决定其可在哪些 CPU 上运行；限制到单一 CPU 可**避免迁移导致的 cache 失效代价**；fork 子进程继承父掩码、execve 保留。页内示例程序实测数据：两进程绑同一 CPU real≈14.75s，同核不同 CPU≈11.52s，不同核≈7.89s——可直接引用作「迁移/共享缓存代价」的量化例证。
- 学习路径参照（非一手权威，仅指路）：一份被检索命中的 CS-537 自学课表将 Ch.7–9 列为 Scheduling 单元并配 lecture 视频（https://jakegut.com/posts/sg-os ）；该页本会话未全文核验，讲义引用前需复核，不列入来源清单。

## 本章仍缺的缺口
- 彩票调度（lottery.py）与 MLFQ（mlfq.py）两个模拟器 README 的具体命令行未逐一打开核验（仓库页已核验存在）；讲义落实时按仓库 README 抄录。
- 「SJF/STCF 最优性的交换论证」为书 Ch.7 正文内容，网上无独立可靠替代源，讲义直接依书展开并标注章节。
