# 第 2 章 CPU 虚拟化 I：进程与直接执行机制

## 来源清单
1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — Process Intro 作业即 `process-run.py` 模拟器（对应 Ch.4），Process API 与 Direct Execution 作业为「写代码」型；本章实验骨架来源 — 访问 2026-08-09
2. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework — process-run.py 等模拟器的官方仓库入口（git clone 获取） — 访问 2026-08-09
3. fork(2) — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man2/fork.2.html — fork 语义权威规范：父子返回值、继承与不继承属性清单、Linux 下 CoW 实现注记，页内完整 C 示例 — 访问 2026-08-09
4. execve(2) — Linux manual page — https://man7.org/linux/man-pages/man2/execve.2.html — exec 语义权威页：替换地址空间、PID 不变、「不是新进程」的正名、#! 脚本解释器 — 访问 2026-08-09
5. wait(2)/waitpid — Linux manual page — https://man7.org/linux/man-pages/man2/wait.2.html — WIFEXITED/WEXITSTATUS 等宏、僵尸进程定义与回收机制——mini-init 项目所需 — 访问 2026-08-09
6. xv6 book 目录（mit-pdos.github.io） — https://mit-pdos.github.io/xv6-riscv-book/ — Ch.4「Traps and system calls」给出 trap→内核→返回的真实代码路径，可作定时器中断→上下文切换时序图的实证参照 — 访问 2026-08-09

## 摘录与要点
- （来源 3）fork 权威语义：子进程是调用进程的复制，拥有唯一 PID；**父进程中返回子 PID、子进程中返回 0、失败返回 -1**——大纲所说「返回值双份的坑」的一手出处。子进程不继承内存锁/挂起信号/计时器等，但**继承打开文件描述符的副本（共享 open file description）**。NOTES 明确：Linux 下 fork 以 **copy-on-write pages** 实现，代价只是复制页表与创建 task 结构（与第 5 章 CoW 呼应）。页内最小示例（fork 后 switch(pid) 分支）可直接用作 hello-os demo。
- （来源 4）execve 正名："executing a *new* process" 的说法高度误导——**没有新进程，PID 等许多属性不变，只是让现有进程执行新程序**；成功时不返回，text/data/bss/stack 被新程序覆盖；信号处置重置、mmap 映射不保留、fd 默认跨 exec 保留（除非 O_CLOEXEC）。argv/envp 传给 main(argc, argv, envp)。页内 myecho.c + execve.c 双程序示例可演示 exec 链与 #! 脚本。
- （来源 5）wait 家族：终止而未被等待的子进程成为 **zombie**，内核保留其 PID/退出状态/资源用量直至父进程 wait；僵尸占进程表槽位，填满将无法再建进程；父先死则僵尸被 init(1) 收养并自动回收。WIFEXITED/WEXITSTATUS/WIFSIGNALED/WTERMSIG 宏用法与完整 fork+waitpid 监控示例可核。SIGCHLD 设 SIG_IGN 可免僵尸（POSIX 行为，Linux 2.6 起遵循）。
- （来源 1）本章配套作业：Ch.4 跑 `process-run.py`（模拟指令交错与上下文切换，直观呈现 PCB 中 PC/寄存器的作用）；Ch.5/6 作业为写代码型（fork/exec/wait 小程序）。
- （来源 6）xv6 book 第 4 章 Traps and system calls：用户程序 ecall → 硬件保存 PC 到特殊寄存器并跳入内核向量 → 内核把寄存器存入 proc 结构（PCB 的真实版）→ 处理 syscall → sret 返回。为「定时器中断→trap→上下文切换」mermaid 时序图提供真实系统对照。

## 本章仍缺的缺口
- 「crash 工具 + x86 汇编看 PC 保存恢复」的书内实操（cpu-mechanisms.pdf 的 crash 会话）未能以网页形式核验（书正文仅 PDF）；讲义需从官网 cpu-mechanisms.pdf 原文摘录 gdb/crash 步骤，或改用 gdb disassemble 现场演示替代。
- 受限运行（limited run mode）的 x86 ring 0/3 细节未找到可核的中文权威页；可用 Intel SDM 或书 Ch.6 原文补充，讲义标注出处即可。
