# 第 5 章 内存虚拟化 II：分页、TLB 与超越物理内存

## 来源清单
1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 本章模拟器权威入口：paging-linear-translate.py（Ch.18）、paging-multilevel-translate.py（Ch.20 多级页表）、mem.c（Ch.21 真实地址翻译实验）、paging-policy.py（Ch.22 置换策略）— 访问 2026-08-09
2. Linux MM Concepts overview（kernel docs） — https://www.kernel.org/doc/html/latest/admin-guide/mm/concepts.html — 层级页表、TLB 动机、huge pages 减压 TLB、匿名页缺页流程、Reclaim/OOM——书 Ch.18–23 的内核实现对照 — 访问 2026-08-09
3. mmap(2) — Linux manual page — https://man7.org/linux/man-pages/man2/mmap.2.html — MAP_SHARED vs **MAP_PRIVATE（copy-on-write 私有映射）** 的官方语义定义；MAP_NORESERVE 与 overcommit——mmap 两种模式知识点的规范出处 — 访问 2026-08-09
4. fork(2) — Linux manual page — https://man7.org/linux/man-pages/man2/fork.2.html — NOTES 权威句：Linux 的 fork 以 **copy-on-write pages** 实现，代价仅为复制页表+建 task 结构——CoW 与 fork 关系的官方注脚 — 访问 2026-08-09
5. MIT 6.1810 Labs（tools.html 导航） — https://pdos.csail.mit.edu/6.828/2023/tools.html — Lab Page tables / Lab Copy on-write / Lab mmap 三个 xv6 实验，作本章工程延伸的权威指路 — 访问 2026-08-09

## 摘录与要点
- （来源 2）内核文档对分页体系的表述可与书对齐：页表层级化，顶层指针驻寄存器（x86 即 CR3），高位索引逐级查表、低位为页内偏移；**TLB 是翻译缓存、属稀缺资源**，工作集大的应用受 TLB miss 拖累；x86 允许用二/三级页表项直接映射 2M/1G 大页（Linux 称 huge pages，hugetlbfs 与 THP 两机制）。匿名内存一节给出缺页流程：读触发映射到共享零页，写才分配实体页并标 dirty——书 Ch.21「机制」的真实系统版。Reclaim/OOM 段对应 Ch.21–22 swap 与 thrashing 的工程延伸。
- （来源 3）MAP_PRIVATE 定义原文：**"Create a private copy-on-write mapping. Updates to the mapping are not visible to other processes ... and are not carried through to the underlying file."**；MAP_SHARED 则更新互相可见且回写文件（精确控制需 msync）。NOTES：**mmap 的内存跨 fork 保留、属性不变**——组合起来即可严谨讲 fork+CoW+mmap 三角关系。MAP_NORESERVE 段解释 swap 预留与 overcommit_memory（呼应第 4 章 malloc 页的乐观分配）。
- （来源 4）fork CoW 注脚 + 「父子运行在分离的内存空间，一方写入不影响另一方」的 DESCRIPTION 首段，是「CoW 让复制变懒」的最短权威论证。
- （来源 1）四个模拟器的用法差异：linear-translate 练 VPN/PPN 拼接手算；multilevel-translate 模拟带 TLB 的多级查表（含 PTE 位操作）；mem.c 是真机上打印虚拟/物理地址的小 C 程序（需 root 权限读 pagemap）；paging-policy.py 跑 LRU/Clock/FIFO/OPT 等策略对比命中率——覆盖大纲全部实验点，README 均在 ostep-homework 仓库内（https://github.com/remzi-arpacidusseau/ostep-homework ，本会话已核验存在）。

## 本章仍缺的缺口
- x86-64 四级页表 PGD/PUD/PMD/PTE 的具体位数切分（48-bit VA、9+9+9+12、canonical address）本次未核验到可直接引用的网页源（kernel x86 mm 专页 404，Wikipedia 抓取连接被重置）；讲义自绘图并注明「依据 Intel SDM Vol.3A §4.5」。
- 反置页表（Ch.23）无网络一手材料需求，依书正文即可，不另列来源。
