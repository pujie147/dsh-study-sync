# 第 9 章 合拢与展望：三大件在一个真实内核里 + 虚拟机与安全概览

## 来源清单
1. MIT PDOS xv6 页（6.828/6.1810） — https://pdos.csail.mit.edu/6.828/xv6 — xv6 官方介绍：源码 mit-pdos/xv6-riscv、配套书 xv6-riscv-book 的 git clone 命令，及 v6/Lions Commentary 历史脉络 — 访问 2026-08-09
2. xv6 book 在线目录 — https://mit-pdos.github.io/xv6-riscv-book/ — 全书 13 章目录（interfaces/organization/page tables/traps/page faults/interrupts/locking/scheduling/sleep-wakeup/file system/logging/concurrency revisited/summary），本章「五处代码定位」的导航图 — 访问 2026-08-09
3. MIT 6.1810 Tools 安装文档 — https://pdos.csail.mit.edu/6.828/2023/tools.html — riscv 工具链权威安装：Ubuntu apt 一行命令、WSL2 路线、macOS brew 路线、Linux VM(VirtualBox) 路线与版本自检命令——大纲缺口「环境搭建两条路径」的官方答案 — 访问 2026-08-09
4. remzi-arpacidusseau/ostep-projects（GitHub） — https://github.com/remzi-arpacidusseau/ostep-projects — 官方项目仓库总入口（initial-xv6「Intro to Kernel Hacking」、processes-shell、scheduling-xv6-lottery、vm-xv6-intro、concurrency-xv6-threads、filesystems-checker 等），本章 initial-xv6 与进阶路线选做清单的来源 — 访问 2026-08-09
5. OSTEP 官网目录页 — https://pages.cs.wisc.edu/~remzi/OSTEP/ — Security 章（Ch.52–57: intro/authentication/access control/crypto/distributed）与附录 Virtual Machines（vmm-intro.pdf）、Monitors、Lab Tutorial/xv6 Labs 的定位确认 — 访问 2026-08-09
6. MIT 6.1810 Labs 列表（tools.html 同页导航） — https://pdos.csail.mit.edu/6.828/2023/tools.html — 八个 lab（util/syscall/pgtbl/traps/cow/lock/net/fs/mmap）即结课后最自然的进阶实验清单 — 访问 2026-08-09

## 摘录与要点
- （来源 1）xv6 官方定位：2006 年夏为教学创建的简单类 Unix 内核，受 Unix V6 与 Lions Commentary 启发，ANSI C 实现于**多核 RISC-V**；正文文本与源码互为超链接。这正是「教科书抽象 vs 真系统」的收官载体：进程(proc.c)、页表(vm.c)、锁(spinlock.c/kthread.c)、文件系统(fs.c/log.c) 各对应前面一章。
- （来源 2）xv6 book 章节映射建议（讲义用）：Ch.4 Traps and system calls ↔ 本课程第 2 章机制层（ecall→kernel_vec→saved registers）；Ch.3 Page tables ↔ 第 5 章；Ch.7 Locking + Ch.9 Sleep and Wakeup ↔ 第 6/7 章（spinlock 关中断实现、sleep/wake up 队列即条件变量内核版）；Ch.10 File system + Ch.11 Logging ↔ 第 8 章（超级块/inode bitmap/log 结构体在 fs.c、log.c 中皆有行级定位点）。fork 交叉点（来源 2 的 Ch.5 page fault CoW + Ch.10 文件表引用计数 dup 语义）可作收官串讲的例题。
- （来源 3）环境两条路径官方化：**路径 A（Ubuntu/Debian 或 WSL2-Ubuntu）** `sudo apt-get install git build-essential gdb-multiarch qemu-system-misc gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu`，要求 QEMU 5.1+ / GDB 8.3+，自检 `qemu-system-riscv64 --version`；Windows 学生官方建议即 WSL2（并强调必须 v2）。**路径 B（macOS）** xcode-select + Homebrew riscv-tools + qemu。讲义再补一条 Docker 镜像路线（如社区 xv6 开发镜像）时须注明非官方。
- （来源 4）initial-xv6 项目（"Intro to Kernel Hacking"）就是本章工程验证点的载体：clone xv6-riscv → make qemu → 加一个 syscall 跟踪打印；ostep-projects 全清单同时构成「进阶路线规划」的选做池；配合来源 6 的 6.1810 labs 是更深的下一站。
- （来源 5）安全概览边界确认：OSTEP v1.10 新增 Peter Reiher (UCLA) 撰写的 Security 五章（intro/authentication/access control/cryptography/distributed security），附录另有 Virtual Machines dialogue + vmm-intro.pdf（经典/翻译两型 VMM 的教材口径）。本章只需带读者读 Ch.53 intro + 附录 vmm-intro 建立地图，不展开。
- 虚拟机 Type-1/Type-2 分类与硬件辅助虚拟化（VT-x/AMD-V）为一句话认知级别，本次未核验独立一手网页源；讲义以书附录 vmm-intro.pdf 为准并注明。

## 本章仍缺的缺口
- xv6 源码五处定位点的具体行号随 commit 漂移，无法预先固定；讲义应教「用 grep -n 定位函数名」的方法而非写死行号。
- 社区 Docker 化的 xv6 riscv 环境本次未核验到稳定仓库页，若讲义要写 Docker 路线需另行验证后再列。
