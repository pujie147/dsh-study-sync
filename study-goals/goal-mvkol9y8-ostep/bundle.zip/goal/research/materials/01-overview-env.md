# 第 1 章 第0篇·总览与环境：操作系统是什么 + C/工具链基线

## 来源清单
1. OSTEP 官方网站（v1.10，免费章节 PDF、作业与项目入口） — https://pages.cs.wisc.edu/~remzi/OSTEP/ — 全课程主教材权威页面，三大件目录即本章「地图感」的来源 — 访问 2026-08-09
2. OSTEP 中文版《致所有读者》（ostep.shigures.dev） — https://ostep.shigures.dev/ — 官方组织的中译本；序言完整说明「虚拟化/并发/持久性」三主题与抽象→机制→策略的组织方式，中文对照首选 — 访问 2026-08-09
3. 《操作系统导论》中文版开源镜像（iTanken/ostep-chinese） — https://itanken.github.io/ostep-chinese/ — 人民邮电出版社中译本的在线阅读镜像，另一份中文对照入口 — 访问 2026-08-09
4. OSTEP Homework 页（模拟器总表） — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 各章配套模拟器清单与用法约定（随机种子出题、-c 求解），本章先建立「跑模拟器做作业」的工作流 — 访问 2026-08-09
5. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework — 官方作业仓库，指引 git clone 后按章运行 — 访问 2026-08-09
6. GDB: The GNU Project Debugger 官网 — https://sourceware.org/gdb/ — gdb 官方主页（当前 18.1），四大调试能力描述可直接用于本章工具链速览 — 访问 2026-08-09
7. MIT 6.1810 Tools 页（xv6 RISC-V 环境安装文档） — https://pdos.csail.mit.edu/6.828/2023/tools.html — Ubuntu/WSL2/macOS 安装 gcc-riscv64/qemu/gdb-multiarch 的权威 apt 命令清单，本章 env_baseline 直接采用其 Ubuntu 路线 — 访问 2026-08-09

## 摘录与要点
- （来源 1）OSTEP v1.10 围绕三个概念件组织：**virtualization、concurrency、persistence**；目录含 Intro(Ch.1–2)、Virtualization(Ch.3–24)、Concurrency(Ch.25–34)、Persistence(Ch.35–51)、Security(Ch.52–57) 及附录（虚拟机、Monitors、labs）。带学习者按此目录走一遍即可建立全课程地图。
- （来源 2）中文版序言原文要点：每个主要部分先介绍 OS 提供的**抽象（abstraction）**，再讨论实现它所需的**机制（mechanisms）、策略（policies）**——这正是「机制+策略分离」的官方表述；书中反复出现 **crux of the problem（关键点）** 叙述手法；强调用**真实代码**而非伪代码，代码托管在 ostep-code 仓库；两类项目：systems programming projects 与 xv6 projects。
- （来源 4/5）作业模拟器使用约定：给定不同随机种子可生成几乎无限题目，`-c` 参数直接给出解答；各模拟器 README 说明具体命令行。建议本章就把 `git clone https://github.com/remzi-arpacidusseau/ostep-homework/` 纳入环境步骤。
- （来源 6）GDB 官方定位四件事：启动程序并控制其行为、在指定条件停住、检查停住时发生了什么、修改程序以试验修复——可作为讲义「gdb 断点/单步」小节的骨架。
- （来源 7）Ubuntu/Debian 一键安装：`sudo apt-get install git build-essential gdb-multiarch qemu-system-misc gcc-riscv64-linux-gnu binutils-riscv64-linux-gnu`；Windows 学生推荐 WSL2 + Ubuntu（须确认 `wsl -l -v` 为版本 2）；macOS 走 xcode-select + Homebrew + riscv-tools + qemu。验证：`qemu-system-riscv64 --version` 与 `riscv64-linux-gnu-gcc --version`。这套命令同时覆盖本章 gcc/gdb/git 基线与第 9 章 xv6 前置。
- （来源 1）书假定读者会 C（K&R），官网亦推荐 APUE（Advanced Programming in the UNIX Environment）——C 零基础补课指向 K&R/APUE 这类正式出版物，比零散网页教程可靠。

## 本章仍缺的缺口
- 「历史脉络：批处理→多道程序→分时→保护」在 OSTEP 正文分散于 Ch.2 Introduction 与各 Dialogue 章，本次未检索到独立可靠的中文历史长文（候选中文源抓取失败），讲义以书 Ch.2 为主展开。
- strace/ps/top 的 man page 本次未逐一打开核验（属常规 Linux 知识），讲义引用时以本机 `man strace` 为准。
- GNU make 官方手册 URL 本次未核验，列入缺口。
