# 第 6 章 并发 I：线程与互斥锁

## 来源清单
1. OSTEP Homework 页 — https://pages.cs.wisc.edu/~remzi/OSTEP/Homework/homework.html — 本章模拟器权威入口：x86.py（Ch.26 线程入门、Ch.28 锁，同一模拟器的两组作业）、main-*.c（Ch.27 真实线程 API、Ch.29 加锁数据结构）— 访问 2026-08-09
2. pthread_create(3) — Linux manual page (man7.org) — https://man7.org/linux/man-pages/man3/pthread_create.3.html — 线程 API 规范：创建/终止四途径、joinable vs detached、栈大小默认规则——「线程共享什么」的官方口径 — 访问 2026-08-09
3. pthread_mutex_lock(3)/pthread_mutex_init — Linux manual page — https://man7.org/linux/man-pages/man3/pthread_mutex_lock.3.html — mutex 定义原文（两状态、单所有者）、fast/recursive/error-checking 三种 kind、trylock 语义、自锁死锁行为 — 访问 2026-08-09
4. wait(2) — Linux manual page — https://man7.org/linux/man-pages/man2/wait.2.html — NOTES「Linux 内核中线程即用 clone(2) 创建的进程；pthread_create 由 clone 实现」——进程/线程关系的一手佐证 — 访问 2026-08-09
5. remzi-arpacidusseau/ostep-homework（GitHub） — https://github.com/remzi-arpacidusseau/ostep-homework — x86.py 等模拟器所在官方仓库 — 访问 2026-08-09

## 摘录与要点
- （来源 2）pthread_create 语义可核点：新线程从 start_routine 起跑并接收唯一 void* 参数；终止方式四种（pthread_exit、return、被 cancel、任一线程 exit(3)/主线程 return main——**最后一种会带走全进程所有线程**，经典坑）；默认 joinable，未 join 的已终止 joinable 线程资源不释放（类似僵尸，呼应第 2 章）；NPTL 下新线程栈大小由 RLIMIT_STACK 决定，unlimited 时多数架构 2MB。注意返回值是错误码而非 -1（与多数 libc 函数不同）。页内完整 create/join 示例程序可改造为「buggy counter → mutex 修复」工程起点。
- （来源 3）mutex 权威描述：**A mutex is a MUTual EXclusion device**，用于保护共享数据结构免受并发修改、实现临界区与 monitor；两状态 unlocked/locked，**永远至多一个所有者**；他线程持锁时 lock 挂起等待；fast kind 下自锁 = 自我死锁（EDEADLK 仅 error-checking kind 报告）；recursive kind 记录加锁计数、需等次 unlock；trylock 不阻塞返回 EBUSY。页尾示例即「全局变量 x 用 lock/unlock 包裹」的标准临界区模式。两条工程告诫：mutex 函数**非 async-signal-safe**（别在信号处理器里调用）；deferred cancellation 场景不要长期持锁。
- （来源 4）「Linux 内核里内核调度的线程不是独立于进程构造：线程就是用 clone(2) 创建的进程，pthread_create(3) 亦由 clone 实现」——讲「线程 vs 进程：共享地址空间、独立栈与 TID」时的最硬出处。
- （来源 1/5）x86.py 用法精髓（依书 Ch.26–28）：以微指令级交错模拟多线程，`-a` 指定汇编、`-t` 线程数、`-P/-i` 控制穿插时机复现 race；配 stress 循环脚本跑一万次验证「加锁后结果恒正确」——本章工程验证点的工具链（脚本名以仓库 README 为准）。锁实现层级（disable interrupts → test-and-set → 带等待队列的锁）为书 Ch.28 正文，网络无等价一手源，讲义依书展开。

## 本章仍缺的缺口
- 原子指令（test-and-set / compare-and-swap / fetch-and-add）的硬件语义本次未核验到独立权威网页（Intel SDM 相关章节未抓取）；讲义依书 Ch.28 叙述并注明参考 Intel SDM Vol.2 XCHG/CMPXCHG。
- GCC `__atomic` / C11 atomics 现代替代写法未检索核验，列为可选延伸。
